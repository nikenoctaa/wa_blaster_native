-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2020 at 07:11 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wa-blaster`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2020_02_09_054517_create_user_form_', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ms_administrasi`
--

CREATE TABLE `ms_administrasi` (
  `no` int(100) NOT NULL,
  `id_project` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `versi` varchar(3) NOT NULL,
  `client_id` int(11) NOT NULL,
  `domain` varchar(100) NOT NULL,
  `register` date NOT NULL,
  `expired` date NOT NULL,
  `folder` text NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` text NOT NULL,
  `Hosting` varchar(20) NOT NULL,
  `Keterangan` text NOT NULL,
  `description` varchar(50) NOT NULL,
  `pj` varchar(10) NOT NULL,
  `dilihat` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ms_asettype`
--

CREATE TABLE `ms_asettype` (
  `id_astpe` int(11) NOT NULL,
  `nma_astpe` varchar(50) NOT NULL,
  `des_astpe` text NOT NULL,
  `masa_astpe` int(11) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_asettype`
--

INSERT INTO `ms_asettype` (`id_astpe`, `nma_astpe`, `des_astpe`, `masa_astpe`, `create_at`, `update_at`) VALUES
(1, 'Kelompok 1 (25%)', '– Meja & kursi kayu\r\n– Telepon, fax, handphone\r\n– Mesin photocopy\r\n– Komputer, printer, modem\r\n– Tool kit\r\n– Sepeda motor\r\n– Cangkul\r\n– Alat peternakan', 4, '2019-04-16 09:52:39', '0000-00-00 00:00:00'),
(2, 'Kelompok 2 (12,5%)', '– Meja & kursi logam\r\n– AC, Kipas angin\r\n– Mobil, Truck\r\n– Mesin bajak\r\n– Mesin jahit\r\n– Mesin pompa\r\n– Mesin perah susu\r\n– Mesin pengalengan ikan\r\n– Mesin penggiling kopi', 8, '2019-04-18 01:59:31', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ms_branch`
--

CREATE TABLE `ms_branch` (
  `kdbrn_brn` char(3) NOT NULL,
  `name_brn` varchar(50) NOT NULL,
  `addrs_brn` varchar(100) NOT NULL,
  `phone_brn` varchar(30) NOT NULL,
  `email_brn` varchar(50) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_branch`
--

INSERT INTO `ms_branch` (`kdbrn_brn`, `name_brn`, `addrs_brn`, `phone_brn`, `email_brn`, `create_at`, `update_at`) VALUES
('SMG', 'Semarang', 'Jalan Stonen Timur No. 7A, Bendan Ngisor, Gajah Mungkur', '08812469577', 'info@sevenmediatech.coms', '2017-07-20 15:04:36', '2017-07-24 08:12:53');

-- --------------------------------------------------------

--
-- Table structure for table `ms_client`
--

CREATE TABLE `ms_client` (
  `idclt_clt` int(11) NOT NULL,
  `type_clt` char(1) NOT NULL,
  `prshan_clt` varchar(50) NOT NULL,
  `almat_clt` mediumtext NOT NULL,
  `cname_clt` varchar(50) NOT NULL,
  `nohp_clt` varchar(50) NOT NULL,
  `email_clt` varchar(50) NOT NULL,
  `ktrgn_clt` mediumtext NOT NULL,
  `usrpw_clt` varchar(50) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_client`
--

INSERT INTO `ms_client` (`idclt_clt`, `type_clt`, `prshan_clt`, `almat_clt`, `cname_clt`, `nohp_clt`, `email_clt`, `ktrgn_clt`, `usrpw_clt`, `create_at`, `update_at`) VALUES
(4, 'C', 'Global Media Website', 'Gedawang, Banyumanik', 'Arief Eka Atmaja', '081326044457', 'atmajayagroup@gmail.com', '', 'aant', '2017-07-14 04:32:14', '2017-07-26 10:15:06'),
(6, 'C', 'SMK Texmaco Semarang', '-', 'Nur Alimah, S.Pd, MT', '085326918499', '', '-', 'aant', '2017-07-26 07:54:20', '2017-07-27 07:35:34'),
(7, 'C', 'Access Architect', 'Kembang Arum', 'Dhani Khasan', '085727047825', 'dani.khasan@gmail.com', 'PIN BBM : 57E37F35', 'pungkyst', '2017-07-26 10:10:58', '2017-07-27 04:46:17'),
(8, 'C', 'Dinas Kesehatan Kota Salatiga', '-', 'Victor', '085640886683', '', '083842000815', 'pungkyst', '2017-07-26 10:14:30', '0000-00-00 00:00:00'),
(11, 'C', 'Yayasan Bina Amal', '-', 'Pimpinan', '089528989123', 'humas2binaamal@gmail.com', 'Pak Usman, dan Bu Muntafingah', 'pungkyst', '2017-07-26 10:24:10', '2017-11-23 04:31:05'),
(12, 'C', 'Batam College', '-', 'Suwandi', '082169690077', '', '', 'aant', '2017-07-26 11:29:46', '0000-00-00 00:00:00'),
(20, 'C', 'RS Puri Asih Salatiga', '-', 'Utami', '081548686313', '', '', 'pungkyst', '2017-07-27 07:49:56', '2017-07-27 07:50:33'),
(25, 'C', 'Gildan Store Semarang', '-', 'Yohan', '085727104735', '', '57AA053E', 'pungkyst', '2017-07-27 07:57:15', '0000-00-00 00:00:00'),
(32, 'C', 'Phone Mart', '-', 'Ajib', '085876247118', '', '', 'pungkyst', '2017-07-27 08:07:29', '0000-00-00 00:00:00'),
(36, 'C', 'ESERBA', '-', 'Abbi', '082220943587', '', '', 'pungkyst', '2017-07-27 08:12:10', '0000-00-00 00:00:00'),
(38, 'C', 'King Data Group', '-', 'Ngatorik', '085741080390', '', '', 'pungkyst', '2017-07-27 08:27:41', '0000-00-00 00:00:00'),
(40, 'C', 'Rainbows House', '-', 'Andre Sulistyo', '+6281390811600', 'kusumajayapersada@gmail.com', '', 'pungkyst', '2017-07-27 08:29:15', '2017-09-12 05:23:32'),
(42, 'C', 'Damore Cafe Semarang', '-', 'Ayik', '085865171961', '', '', 'pungkyst', '2017-07-27 08:30:32', '0000-00-00 00:00:00'),
(43, 'C', 'HIPMI PT Jawa Tengah', '-', 'AAN', '085747747725', '', '', 'pungkyst', '2017-07-27 08:31:04', '2017-07-28 03:17:04'),
(44, 'C', 'Zulindo Tour and Travel', '-', 'Bu Peni', '081325422349', '', '', 'pungkyst', '2017-07-27 08:31:45', '2018-09-03 14:42:19'),
(45, 'C', 'Seventeen Plus', '-', 'Galih', '082226124618', '', '', 'pungkyst', '2017-07-27 08:32:46', '0000-00-00 00:00:00'),
(47, 'C', 'Agung Teknik Rental', '-', 'Avira', '085641292392', '', '', 'pungkyst', '2017-07-27 08:34:39', '0000-00-00 00:00:00'),
(48, 'C', 'SMA Integral Hidayatullah Batam', 'asdasd', 'Kepala', '081283922142', '', 'Heri', 'pungkyst', '2017-07-27 08:35:29', '2018-03-27 02:48:51'),
(50, 'C', 'Potret Jateng', '-', 'Agus Humas Udinus', '081325214996', '', '', 'pungkyst', '2017-07-27 08:40:24', '0000-00-00 00:00:00'),
(51, 'C', 'Sinergi Internasional', '-', 'Yama Fresidan', '+6282243303353', 'fds.yama@gmail.com', '', 'pungkyst', '2017-07-27 08:41:03', '2017-07-28 03:14:09'),
(52, 'C', 'Engineers Asgard', 'Jl. Setuk II No.9, Pudakpayung, Banyumanik, Kota Semarang, Jawa Tengah 50265, Indonesia ', 'Endang Dzulkarnaen', '085799889948', 'engineers.asgard@gmail.com', '', 'aant', '2017-07-28 04:17:47', '0000-00-00 00:00:00'),
(53, 'C', 'Toko Aidan Sport', 'Jl. Ngresep Timur v gg. sahabat no 17 RT03 RW03 Sumurboto Banyumanik', 'Wahyu Fajarrini Azzayinah, S.T', '082222203199', 'wahyu.fajarrini75@gmail.com', 'website : aidansport.co.id', 'pungkyst', '2017-07-28 05:22:52', '2019-08-18 08:32:36'),
(54, 'C', 'Frozen Food', 'Jl. Ngresep Timur v gg. sahabat no 17 RT03 RW03 Sumurboto Banyumanik', 'Havik Martoyo', '0811298272', 'havikmartoyo70@gmail.com', 'website : frozenfood.web.id', 'pungkyst', '2017-07-28 05:24:44', '2019-08-18 09:25:58'),
(55, 'C', 'Samir', 'Gondosari 1/4 Gebog Kudus', 'M Hamam Masrukh', '081325551238', 'mhammasrukh@gmail.com', 'website : samir.co.id', 'pungkyst', '2017-07-28 05:25:51', '2019-08-18 09:26:03'),
(56, 'C', 'Batik Batik Batik', 'Jl. TPI baru rt 01/07 kel. Buko  kec. Wedung  Kab. Demak', 'Mahmudah', '082134088024', 'hakimatulmahmudah@gmail.com', 'website : batikbatikbatik.co.id', 'pungkyst', '2017-07-28 05:27:07', '2019-08-18 09:26:08'),
(57, 'C', 'Chiclicks Gallery', 'gg. Alpukat rt 11 rw 03', 'Lilik', '085727722266', 'lilik168@gmail.com', 'website : chicliks.co.id', 'pungkyst', '2017-07-28 05:28:07', '2019-08-18 09:26:13'),
(58, 'C', 'Daffa', 'Suko Baru Rt 07/09 Patosan Sedayu Muntilan', 'Yulianto', '081914429090', '', 'website :  krupuklele.co.id', 'pungkyst', '2017-07-28 05:28:58', '2019-08-18 09:26:18'),
(59, 'C', 'Gracia', 'Jl. Karang Kebon Selatan 250', 'Wahyu Sienta w w', '085865707749', 'wahyusinta51@gmail.com', 'website : mochigracia.co.id', 'pungkyst', '2017-07-28 05:30:08', '2019-08-18 08:32:41'),
(60, 'C', 'Keripik Picasa', 'Jl. Jrabang Raya No. 66 Kel. Ngesrep Kec. Banyumanik', 'Ari Prasetiyo', '085692050770', 'keripikpicasa@gmail.com', 'website : keripikpicasa.co.id', 'pungkyst', '2017-07-28 05:31:05', '2019-08-18 09:26:23'),
(61, 'C', 'Omah Stik Margo Mulyo', 'Plalangan Rt 03/01 Gunung Pati', 'Evening Haryanti', '085740210381', 'omahstikmargomulyo@gmail.com', 'website : omahstikmargomulyo.co.id', 'pungkyst', '2017-07-28 05:32:12', '2019-08-18 08:32:46'),
(62, 'C', 'Yunis Kukis Dapur Mak Otim', 'Jl. Tegal Mulya 2 No.11A Ledug  Kembaran', 'Kus Hardiyanto', '08112918400', 'hardiyantoku@yahoo.com', 'website : yuniskukis.co.id', 'pungkyst', '2017-07-28 05:33:15', '2019-08-18 08:32:51'),
(63, 'C', 'Grifa', 'Jl. Aliwijayan No. 277 Rt 01/05 Togaten Kel. Mangunsari Kec. Sidomukti', 'Tan De Costa', '0895327000000', 'grifadecosta@gmail.com', 'website : grifacirengsalju.co.id', 'pungkyst', '2017-07-28 05:34:08', '2019-08-18 09:26:28'),
(64, 'C', 'Lestari', 'Purwodadi Grobogan', 'Kridho Handoyo', '082243670800', '', 'website : lestarisnack.co.id', 'pungkyst', '2017-07-28 05:34:53', '2019-08-18 09:26:34'),
(65, 'C', 'Karya Sejahtera', 'Tunggulsari Kaliori', 'Khilatul Laila', '085290095294', '', 'website : krupokikan.co.id', 'pungkyst', '2017-07-28 05:35:55', '2019-08-18 09:26:39'),
(66, 'C', 'Puspita', 'Jl. Kumpulsari 1 No. 6 Rt 04/V Kel. Gendangan Tingkir', 'Melani Catur Wulandari', '08164245697', 'wulann784@gmail.com', 'website : puspitasalatiga.co.id', 'pungkyst', '2017-07-28 05:36:50', '2019-08-18 09:26:44'),
(67, 'C', 'Al-Kautsar', 'Glagah Kulon Rt.2/4 Dawe', 'M Zainal Ari', '+6285640559925', '', 'website : ajaban.co.id', 'pungkyst', '2017-07-28 05:37:41', '2019-08-18 09:26:49'),
(68, 'C', 'Zahtan', 'Desa Papringan Rt.4/2 Kaliwungu', 'Nor Azizah', '082136310518', '', 'zahtanproduct.co.id', 'pungkyst', '2017-07-28 05:39:53', '2019-08-18 08:32:56'),
(69, 'C', 'Hijab Yasmin', 'Desa Terbari Rt.2/1', 'Roofi Try Yasminingrum', '085799880010', '', 'website : hijabyasmin.co.id', 'pungkyst', '2017-07-28 05:40:40', '2019-08-18 09:26:54'),
(70, 'C', 'UD Hasil Logam', 'Hadipolo Rt.2/1 Jekulo', 'M.Sahri Baedlowi', '082226847274', '', 'website : hasillogam.co.id', 'pungkyst', '2017-07-28 05:41:30', '2019-08-18 08:33:01'),
(71, 'C', 'Ghaida Collection', 'Bakalan Krapyak Rt.2/4 Kaliwungu', 'Kurniati Setyaningsih ', '082328221223', '', 'website : produsensarunginstan.co.id', 'pungkyst', '2017-07-28 05:42:34', '2019-08-18 09:26:59'),
(72, 'C', 'Sekar Muria', 'Jl.Hadipolo I/134 Jekulo', 'M.Sofyan Hadi', '081249494898', '', 'website : sekarmuria.co.id', 'pungkyst', '2017-07-28 05:43:26', '2019-08-18 08:33:06'),
(73, 'C', 'Asri Jaya', 'Tenggeles Rt.2/1 Tenggeles Mejobo', 'Sri Sutarsih', '089669600437', '', 'website : asrijaya.co.id', 'pungkyst', '2017-07-28 05:44:13', '2019-08-18 08:33:11'),
(74, 'C', 'Seruni Handmade', 'Jl. R. Agil Kusumadya Gg III Rt.3/2 Desa Jati Kulon', 'Sri Setuni', '081390974301', '', 'website : serunihandmade.co.id', 'pungkyst', '2017-07-28 05:45:03', '2019-08-18 08:33:16'),
(75, 'C', 'Elsanieta', 'Jln. KH Muhammad Arwani Desa Singocandi Rt.3/2', 'Elsanita Rofayani N', '085647128633', '', 'website: elsanieta.co.id', 'pungkyst', '2017-07-28 05:45:55', '2019-08-18 08:33:21'),
(76, 'C', 'Prima Pradnadita', 'Perum Puri Kanoman Rt.7/3 Desa Bakalan Krapyak Kec.Kaliwungu', 'N.Anik Sulastri', '085226440400', '', 'website : saqinanokudus.co.id', 'pungkyst', '2017-07-28 05:46:56', '2019-08-18 08:33:26'),
(77, 'C', 'Aila', 'Ds. Janggalan 237-L Rt 06/i', 'Arief Bakhtiar', '085640342411', '', 'website : ailaproduk.co.id', 'pungkyst', '2017-07-28 05:48:22', '2019-08-18 09:27:04'),
(78, 'C', 'MTs Qudsiyyah', 'Jl. KHR. Asnawi Gang Kerjasan Kudus', 'MTs Qudsiyyah', '08562722385', '', '', 'pungkyst', '2017-07-28 05:50:41', '2019-08-18 09:27:09'),
(79, 'C', 'SMP Islam Integral Luqman Al Hakim Kudus', 'Jl. Raya Kudus-Jepara Km.5 Kedungdowo Kaliwungu Kudus', 'SMP Islam Integral Luqman Al Hakim Kudus', '085727121595', '', '', 'pungkyst', '2017-07-28 05:52:40', '2019-08-18 09:27:14'),
(80, 'C', 'SMP MASEHI', 'JL. KH. Wahid Hasyim No 31', 'SMP MASEHI', '085692177005', '', '', 'pungkyst', '2017-07-28 05:53:14', '2019-08-18 09:27:19'),
(81, 'C', 'SMP Negeri 4 Bae Kudus', 'Desa Karangbener Kecamatan Bae Kudus', 'SMP Negeri 4 Bae Kudus', '081225173235', '', '', 'pungkyst', '2017-07-28 05:54:33', '2019-08-18 09:27:24'),
(82, 'C', 'SMPIT Al Kautsar Kudus', 'Jepang RT 4 RW 12', 'SMPIT Al Kautsar Kudus', '-', '', '', 'pungkyst', '2017-07-28 05:55:54', '2019-08-18 09:27:29'),
(83, 'C', 'SMP 1 Dawe', 'Jl. Colo KM.11', 'SMP 1 Dawe', '-', '', '', 'pungkyst', '2017-07-28 05:56:33', '2019-08-18 08:33:31'),
(84, 'C', 'SMP Bhakti Praja Kaliwungu', 'Jl. Jepara 148 B Kaliwungu Kudus', 'SMP Bhakti Praja Kaliwungu', '085692034175', '', '', 'pungkyst', '2017-07-28 05:57:46', '2019-08-18 08:33:36'),
(85, 'C', 'SMP IT Rohmatul Ummah Kudus', 'Jl. Pandean No.230 Jekulo Kudus 59382', 'SMP IT Rohmatul Ummah Kudus', '085640872989', '', '', 'pungkyst', '2017-07-28 05:58:48', '2019-08-18 08:33:41'),
(86, 'C', 'SMP 1 Bae Kudus', 'Jln. Colo Km.5 Kec.Bae Kudus', 'SMP 1 Bae Kudus', '087733796698', '', '', 'pungkyst', '2017-07-28 05:59:37', '2019-08-18 09:27:34'),
(87, 'C', 'SMP PGRI Jekulo Kudus', 'Jln. KH. Ali Sanusi Tambakjaya Jekulo Kudus', 'SMP PGRI Jekulo Kudus', '085640865566', '', '', 'pungkyst', '2017-07-28 06:00:28', '2019-08-18 08:33:46'),
(88, 'C', 'SMP 2 Mejobo', 'Jl. Raya Mejobo', 'SMP 2 Mejobo', '-', '', '', 'pungkyst', '2017-07-28 06:01:00', '2019-08-18 09:27:39'),
(89, 'C', 'SMP 1 Jati Kudus', 'Jl. Getas Pejaten Jati Kudus', 'SMP 1 Jati Kudus', '085290540771', '', '', 'pungkyst', '2017-07-28 06:01:32', '2019-08-18 08:33:51'),
(90, 'C', 'SMP Bhakti', 'Jl. Mejobo Mlati Kidul Kec. Kota Kab. Kudus', 'SMP Bhakti', '085740512189', '', '', 'pungkyst', '2017-07-28 06:03:08', '2019-08-18 08:33:56'),
(91, 'C', 'SMP N 2 Dawe', 'Ds. Rejosari Kec. Dawe Kudus', 'SMP N 2 Dawe', '085865520335', '', '', 'pungkyst', '2017-07-28 06:03:47', '2019-08-18 08:34:02'),
(92, 'C', 'SMP Negeri 2 Undaan', 'Jl. Purwodadi KM 7 Wates Undaan', 'SMP Negeri 2 Undaan', '081326332126', '', '', 'pungkyst', '2017-07-28 06:05:06', '2019-08-18 09:27:44'),
(93, 'C', 'Sma Pgri 1 Kudus', 'Jl. Mejobo 73 Mlatinorowito Kudus', 'Adhi', '085740971850', '', '', 'pungkyst', '2017-07-28 06:06:37', '2019-08-18 08:34:06'),
(94, 'C', 'SMK Kristen Nusantara', 'Jl. Mejobo-Mlatinorowito', 'SMK Kristen Nusantara', '085290092867', '', '', 'pungkyst', '2017-07-28 06:07:20', '2019-08-18 08:34:11'),
(95, 'C', 'SMP Negeri 5 Tegal', 'Debong Selatan', 'SMP Negeri 5 Tegal', '081902557574', '', '', 'pungkyst', '2017-07-28 06:08:07', '2019-08-18 09:27:49'),
(96, 'C', 'Atmaja Wacana', 'Jl. Kapten Ismail No. 92-94 Kelurahan Kraton', 'Atmaja Wacana', '085741816487', '', '', 'pungkyst', '2017-07-28 06:09:07', '2019-08-18 09:27:54'),
(97, 'C', 'SMP Muhammadiyah 1 Kota Tegal', 'Jl. Perintis Kemerdekaan No.95', 'SMP Muhammadiyah 1 Kota Tegal', '085226901630', '', '', 'pungkyst', '2017-07-28 06:09:59', '2019-08-18 09:27:59'),
(98, 'C', 'MTsN Margadana', 'JL. Pendidikan Pesurungan Lor', 'MTsN Margadana', '085385951028', '', '', 'pungkyst', '2017-07-28 06:10:57', '2019-08-18 08:34:16'),
(99, 'C', 'SMK ISTEK TEGAL', 'Jl. Cipto Mangunkusumo No.51 Kaligangsa', 'SMK ISTEK TEGAL', '085842198117', '', '', 'pungkyst', '2017-07-28 06:12:08', '2019-08-18 09:28:04'),
(100, 'C', 'SMK Assalafiyah Tegal', 'Jl. Ar Hakim No. 10 Kel. Randugunting Tegal', 'SMK Assalafiyah Tegal', '+6285642671255', 'haiattha@gmail.com', '', 'pungkyst', '2017-07-28 06:13:12', '2019-08-18 09:14:01'),
(101, 'C', 'SDN Debong Lor Tegal', 'Jl. Dewi Sartika No.149 Tegal', 'SDN Debong Lor Tegal', '085711320519', '', '', 'pungkyst', '2017-07-28 06:14:06', '2019-08-18 08:20:38'),
(102, 'C', 'SDN Pesurungan Kidul 2 Tegal', 'Pesurungan Kidul', 'SDN Pesurungan Kidul 2 Tegal', '081542144879', '', '', 'pungkyst', '2017-07-28 06:14:59', '2019-08-18 08:20:43'),
(103, 'C', 'SDN Tegalsari 10', 'Jl. Blanak I/30 Tegal ', 'SDN Tegalsari 10', '081802873859', '', '', 'pungkyst', '2017-07-28 06:15:55', '2019-08-18 09:14:06'),
(104, 'C', 'SDN Tegalsari 12 ', 'Jl. Lumba-lumba No. 33 Tegal', 'SDN Tegalsari 12 ', '081391980999', '', '', 'pungkyst', '2017-07-28 06:28:48', '2019-08-18 08:20:48'),
(105, 'C', 'SDN Bandung 2', 'Jl. Teuku Cik Ditiro No.155 Kel. Bandungan ', 'SDN Bandung 2', '085624680435', 'haiayopiknik@gmail.com', '', 'pungkyst', '2017-07-28 06:29:55', '2019-08-18 09:14:11'),
(106, 'C', 'SDN Randugunting 2', 'Jl. Ketilang Rt.08 Rw.01 Randugunting', 'SDN Randugunting 2', '081578486355', '', '', 'pungkyst', '2017-07-28 06:30:55', '2019-08-18 08:20:53'),
(107, 'C', 'SDN Kaliyamat Kulon 2 Tegal', 'Jl. Lektor Pol.Sutaryo Kaliyamat Kulon', 'SDN Kaliyamat Kulon 2 Tegal', '085740048203', '', '', 'pungkyst', '2017-07-28 06:32:02', '2019-08-18 09:14:16'),
(108, 'C', 'SDN Kejambon 7', 'Jl, Nakula Utara No.50 Kel.Kejambon ', 'SDN Kejambon 7', '08886611980', '', '', 'pungkyst', '2017-07-28 06:33:06', '2019-08-18 09:14:21'),
(109, 'C', 'SDN Krandon 2', 'Jl. Bukit Tinggi I Rt.04 Rw.02 Krandon', 'SDN Krandon 2', '085742255174', '', '', 'pungkyst', '2017-07-28 06:34:15', '2019-08-18 08:20:58'),
(110, 'C', 'SDN Kejambon 10', 'Jl. Nakula Utara No.50 Kejambon', 'SDN Kejambon 10', '085600743332', '', '', 'pungkyst', '2017-07-28 06:35:01', '2019-08-18 08:21:03'),
(111, 'C', 'SDN Kemandungan 2 Tegal', 'Jl. Kompol Suprapto No.1 Kel. Kemandungan', 'SDN Kemandungan 2 Tegal', '085642579724', '', '', 'pungkyst', '2017-07-28 06:35:57', '2019-08-18 08:21:08'),
(112, 'C', 'SDN Kaligangsa 04', 'Jl. Moh Hatta No. 120 Rt.001 Rw.005 Kaligangsa Kota Tegal', 'SDN Kaligangsa 04', '085640298845', '', '', 'pungkyst', '2017-07-28 06:37:25', '2019-08-18 09:14:26'),
(113, 'C', 'SD PIUS Kota Tegal', 'Jl. Kapten Ismail No.120 Kota Tegal 52112', 'SD PIUS Kota Tegal', '081911514695', '', '', 'pungkyst', '2017-07-28 06:38:57', '2019-08-18 09:14:31'),
(114, 'C', 'SDN Mintaragen 3 Tegal', 'Jl. Serayu No.68 Tegal', 'SDN Mintaragen 3 Tegal', '08975606803', '', '', 'pungkyst', '2017-07-28 06:39:42', '2019-08-18 09:14:36'),
(115, 'C', 'SDN Pesurungan Kidul 1 Tegal', 'Jl. H.Abdul Ghoni No. 53 Rt.007 Rw.001 Pesurungan Kidul 52116', 'SDN Pesurungan Kidul 1 Tegal', '081542159496', '', '', 'pungkyst', '2017-07-28 06:41:05', '2019-08-18 09:14:41'),
(116, 'C', 'SDN Adiwerna 02', 'Jl. Ringin Ireng No.49 Rt.21 Rw.05 Adiwerna', 'SDN Adiwerna 02', '085693599023', '', '', 'pungkyst', '2017-07-28 06:42:12', '2019-08-18 09:14:46'),
(117, 'C', 'SDN Adiwerna 01', 'Jl. Singkil No.24 Adiwerna - Tegal', 'SDN Adiwerna 01', '085727545589', '', '', 'pungkyst', '2017-07-28 06:43:03', '2019-08-18 09:14:51'),
(118, 'C', 'SD Muhammadiyah Pesaren', 'Jl. Lembah Manah Rt.05 Rw.02 Pesaren Kec. Adiwerna', 'SD Muhammadiyah Pesaren', '085726671445', '', '', 'pungkyst', '2017-07-28 06:44:12', '2019-08-18 09:14:56'),
(119, 'C', 'SD Islam Pelangi ', 'Jl. Angrek Rt.30 Rw.03 Ujungrusi Adiwerna', 'SD Islam Pelangi ', '085741151987', '', '', 'pungkyst', '2017-07-28 06:45:26', '2019-08-18 08:21:13'),
(120, 'C', 'SD Budi Mulia Muhammadiyah ', 'Jl. Katesan III Tembok Banjaran', 'SD Budi Mulia Muhammadiyah ', '085229577970', '', '', 'pungkyst', '2017-07-28 06:46:18', '2019-08-18 09:15:01'),
(121, 'C', 'SDN Warureja 02', 'Jl. Belimbing Rt.07 Rw.04 Desa Warureja Kab. Tegal 52183', 'SDN Warureja 02', '085827889022', '', '', 'pungkyst', '2017-07-28 06:47:36', '2019-08-18 09:15:06'),
(122, 'C', 'SDN Warureja 01', 'Jl. Belimbing No.32 Desa Warureja Kec. Warureja Kab. Tegal', 'SDN Warureja 01', '081584033340', '', '', 'pungkyst', '2017-07-28 06:48:56', '2019-08-18 09:15:11'),
(123, 'C', 'SDN Sukareja 04', 'Jl. Amd Rt.02 Rw.08 Desa Sukareja Kec. Warureja Kab. Tegal', 'SDN Sukareja 04', '085293280283', '', '', 'pungkyst', '2017-07-28 06:50:50', '2019-08-18 09:15:17'),
(124, 'C', 'SDN Sukareja 03', 'Sukareja', 'SDN Sukareja 03', '082326706488', '', '', 'pungkyst', '2017-07-28 06:51:29', '2019-08-18 08:21:18'),
(125, 'C', 'SDN Sukareja 02', 'Jl. Raya Babadan - Kedungjati Km.6 Kec. Warureja Kab. Tegal', 'SDN Sukareja 02', '081902431662', '', '', 'pungkyst', '2017-07-28 06:52:47', '2019-08-18 08:21:23'),
(126, 'C', 'SDN Sukareja 01 ', 'Jl. Babadan Kedungjati Rt.002 Rw.001 Sukalila Sukareja 52183', 'SDN Sukareja 01 ', '085642823064', '', '', 'pungkyst', '2017-07-28 06:54:38', '2019-08-18 09:15:22'),
(127, 'C', 'SDN Sigentong ', 'Jl. Kertamana-Sigentong Desa Sigentong Kec. Warureja Kab. Tegal ', 'SDN Sigentong', '085867611984', '', '', 'pungkyst', '2017-07-28 06:55:43', '2019-08-18 08:21:28'),
(128, 'C', 'SDN Sidamulya 02', 'Jln. Binagraha No. 35 Desa Sidamulya Kec. Warureja Kab. Tegal', 'SDN Sidamulya 02', '083865701482', '', '', 'pungkyst', '2017-07-28 06:56:54', '2019-08-18 08:21:33'),
(129, 'C', 'SDN Kreman 02', 'Jln.Dukuh Wanagopa Desa Kreman Kec.Warureja Kab. Tegal', 'SDN Kreman 02', '087730801464', '', '', 'pungkyst', '2017-07-28 06:57:44', '2019-08-18 08:21:38'),
(130, 'C', 'SDN Kreman 01', 'Jl. Wotgalih Desa Kreman Kec. Warureja ', 'SDN Kreman 01', '085643012003', '', '', 'pungkyst', '2017-07-28 06:58:40', '2019-08-18 08:21:43'),
(131, 'C', 'SDN Kendayakan 03', 'Dukuh Kebandingan Rt.01 Rw.03 Desa Kendayakan Kec. Warureja Kab. Tegal', 'SDN Kendayakan 03', '0818240247', '', '', 'pungkyst', '2017-07-28 07:00:10', '2019-08-18 08:21:48'),
(132, 'C', 'SDN Kendayakan 02', 'Dukuh Bandung Rt.01 Rw.04 Desa Kendayakan Kec. Warureja Kab. Tegal', 'SDN Kendayakan 02', '085743622267', '', '', 'pungkyst', '2017-07-28 07:01:15', '2019-08-18 08:21:53'),
(133, 'C', 'SDN Kendayakan 01', 'Jl. Raya Babadan - Kedungjati Km.07 Kec. Warureja Kab. Tegal 52183', 'SDN Kendayakan 01', '085741115026', '', '', 'pungkyst', '2017-07-28 07:02:37', '2019-08-18 08:21:58'),
(134, 'C', 'SDN Kedungkelor 02', 'Jln. Raya Pantura Tegal-Pemalang KM. 25 Kec. Warurejo Kab. Tegal ', 'SDN Kedungkelor 02', '085640385152', '', '', 'pungkyst', '2017-07-28 07:03:41', '2019-08-18 09:15:27'),
(135, 'C', 'SDN Kedungkelor 01 ', 'Jl. Raya Tegal - Pemalang Km. 23 Warureja Tegal', 'SDN Kedungkelor 01 ', '083837233164', '', '', 'pungkyst', '2017-07-28 07:05:04', '2019-08-18 09:15:32'),
(136, 'C', 'SDN Kedungjati 04', 'Dukuh Cipero Rt.02 / Rw.06  Ds. Kedungjati  Kec. Warureja Kab. Tegal 52183', 'SDN Kedungjati 04', '081803997743', '', '', 'pungkyst', '2017-07-28 07:05:50', '2019-08-18 08:22:03'),
(137, 'C', 'SDN Kedungjati 03', 'Jl. Flamboyan Desa Kedungjati Kec. Warureja Kab. Tegal', 'SDN Kedungjati 03', '085842293164', '', '', 'pungkyst', '2017-07-28 07:07:11', '2019-08-18 08:22:08'),
(138, 'C', 'SDN Kedungjati 02', 'Jl. Raya Kedungjati - Balamoa Km. 01 Desa Kedungjati RT.01/04 Kec. Warureja Kab. Tegal', 'SDN Kedungjati 02', '087730491133', '', '', 'pungkyst', '2017-07-28 07:09:35', '2019-08-18 09:15:37'),
(139, 'C', 'SDN Kedungjati 01', 'Jl. Kalpataru Desa Kedungjati Rt 02 Rw 05 Kec. Warureja Kab. Tegal 52183', 'SDN Kedungjati 01', '081802871526', '', '', 'pungkyst', '2017-07-28 07:10:14', '2019-08-18 08:22:13'),
(140, 'C', 'SDN Demangharjo 03', 'Jl. Abdurrahman Desa Demangharjo Kec. Warureja Kab. Tegal 52183', 'SDN Demangharjo 03', '085642741227', '', '', 'pungkyst', '2017-07-28 07:11:21', '2019-08-18 08:22:18'),
(141, 'C', 'SDN Demangharjo 02', 'Jl. Raya Demangharjo Km.20 ', 'SDN Demangharjo 02', '085741218780', '', '', 'pungkyst', '2017-07-28 07:14:04', '2019-08-18 09:15:42'),
(142, 'C', 'SDN Demangharjo 01', 'Jl. Raya Tegal-Pemalang Km. 18 Desa Demangharjo', 'SDN Demangharjo 01', '085729995607', '', '', 'pungkyst', '2017-07-28 07:14:46', '2019-08-18 09:15:47'),
(143, 'C', 'SDN Banjarturi 02', 'Dukuh Banjarharjo Rt.02 Rw.05 Desa Banjarturi Kec. Warureja Kab. Tegal', 'SDN Banjarturi 02', '082323933007', '', '', 'pungkyst', '2017-07-28 07:16:06', '2019-08-18 08:22:24'),
(144, 'C', 'SDN Banjarturi 01', 'Desa Banjarsari Kec. Warureja Kab. Tegal', 'SDN Banjarturi 01', '085786066489', '', '', 'pungkyst', '2017-07-28 07:17:05', '2019-08-18 08:22:28'),
(145, 'C', 'SDN Banjaragung 04', 'Dukuh Buyut Desa Banjaragung Kec. Warureja 52183', 'SDN Banjaragung 04', '085786878505', '', '', 'pungkyst', '2017-07-28 07:18:17', '2019-08-18 08:22:33'),
(146, 'C', 'SDN Banjaragung 03', 'Dukuh Banjaranyar Desa Banjaragung Kec. Warureja Kab. Tegal', 'SDN Banjaragung 03', '085742045511', '', '', 'pungkyst', '2017-07-28 07:19:24', '2019-08-18 09:15:52'),
(147, 'C', 'SDN Banjaragung 01', 'Jl. Beringin No. 1 Warureja Tegal', 'SDN Banjaragung 01', '085726040908', '', '', 'pungkyst', '2017-07-28 07:20:10', '2019-08-18 09:15:57'),
(148, 'C', 'SDN Tarub 02', 'Jl.Jakatingkir No.01', 'SDN Tarub 02', '085742336357', '', '', 'pungkyst', '2017-07-28 07:20:53', '2019-08-18 08:22:38'),
(149, 'C', 'SDN Tarub 01', 'Jl. Joko Tarub Rt 07/03 Desa Tarub', 'SDN Tarub 01', '081548028714', '', '', 'pungkyst', '2017-07-28 07:21:33', '2019-08-18 08:22:43'),
(150, 'C', 'SDN Setu 02', 'Jl. Pendididkan Desa Setu', 'SDN Setu 02', '085742898880', '', '', 'pungkyst', '2017-07-28 07:22:17', '2019-08-18 08:22:49'),
(151, 'C', 'SDN Setu 01', 'JL. Pendidikan Desa Setu Kec. Tarub', 'SDN Setu 01', '085786118746', '', '', 'pungkyst', '2017-07-28 07:22:56', '2019-08-18 09:16:02'),
(152, 'C', 'SDN Purbasana 01', 'Jl. Ciptalaksana Desa Purbasana', 'SDN Purbasana 01', '081542247664', '', '', 'pungkyst', '2017-07-28 07:23:38', '2019-08-18 08:22:54'),
(153, 'C', 'SDN Mindaka 02', 'Jl.Raya Tangkil Mindaka', 'SDN Mindaka 02', '08157675824', '', '', 'pungkyst', '2017-07-28 07:24:25', '2019-08-18 08:22:59'),
(154, 'C', 'SDN Mindaka 01', 'Jl.Projosumarto II Mindaka', 'SDN Mindaka 01', '085868433487', '', '', 'pungkyst', '2017-07-28 07:25:15', '2019-08-18 09:16:07'),
(155, 'C', 'SDN Margapadang 02', 'Jl. Wanabhakti Margapadang Kec. Tarub Kab. Tegal', 'SDN Margapadang 02', '085868744520', '', '', 'pungkyst', '2017-07-28 07:26:01', '2019-08-18 08:23:04'),
(156, 'C', 'SDN Margapadang 01', 'Jl.Wanabakti Margapadang', 'SDN Margapadang 01', '085642925669', '', '', 'pungkyst', '2017-07-28 07:26:47', '2019-08-18 09:16:12'),
(157, 'C', 'SDN Mangunsaren 01', 'Jl. Kemajengan Desa Mangunsaren', 'SDN Mangunsaren 01', '085713886628', '', '', 'pungkyst', '2017-07-28 07:27:24', '2019-08-18 08:23:09'),
(158, 'C', 'SDN MAngunsaren 02', 'Jalan Rahayu Desa Mangunsaren', 'SDN MAngunsaren 02', '085640047625', '', '', 'pungkyst', '2017-07-28 07:27:59', '2019-08-18 09:16:17'),
(159, 'C', 'SDN Lebeteng 02', 'Desa Lebeteng Kec.Tarub', 'SDN Lebeteng 02', '085867393236', '', '', 'pungkyst', '2017-07-28 07:28:43', '2019-08-18 09:16:22'),
(160, 'C', 'SDN Lebeteng 01', 'Jalan Jaya Sumita Lebeteng', 'SDN Lebeteng 01', '085290543710', '', '', 'pungkyst', '2017-07-28 07:29:13', '2019-08-18 09:16:27'),
(161, 'C', 'SDN Kesamiran 02', 'Jl. Wanabhakti ', 'SDN Kesamiran 02', '087730990710', '', '', 'pungkyst', '2017-07-28 07:29:50', '2019-08-18 08:23:14'),
(162, 'C', 'SDN Kesamiran 01', 'Jl.Wanabakti Kesamiran', 'SDN Kesamiran 01', '081575611732', '', '', 'pungkyst', '2017-07-28 07:30:33', '2019-08-18 08:23:19'),
(163, 'C', 'SDN Kesadikan 01', 'Jl.Wanabakti II Kesamiran', 'SDN Kesadikan 01', '085742903037', '', '', 'pungkyst', '2017-07-28 07:31:20', '2019-08-18 09:16:32'),
(164, 'C', 'SDN Kemanggugan', 'Jl. Projosumarto II Kemanggungan', 'SDN Kemanggugan', '085870130032', '', '', 'pungkyst', '2017-07-28 07:32:16', '2019-08-18 08:23:24'),
(165, 'C', 'SDN Kedungbungkus 02', 'Jl. Pendidikan II Desa Kedungbungkus', 'SDN Kedungbungkus 02', '085642826156', '', '', 'pungkyst', '2017-07-28 07:33:45', '2019-08-18 08:23:29'),
(166, 'C', 'SDN Kedungbungkus 01', 'Jl. Pendidikan I', 'SDN Kedungbungkus 01', '082324452248', '', '', 'pungkyst', '2017-07-28 07:34:55', '2019-08-18 09:16:37'),
(167, 'C', 'SDN Kedokansayang 03', 'Jl. Desa Kedokansayang', 'SDN Kedokansayang 03', '08567664026', '', '', 'pungkyst', '2017-07-28 07:35:47', '2019-08-18 08:23:34'),
(168, 'C', 'SDN Kedokansayang 02', 'Jl. Desa Kedokansayang', 'SDN Kedokansayang 02', '085786665646', '', '', 'pungkyst', '2017-07-28 07:36:29', '2019-08-18 08:23:39'),
(169, 'C', 'SDN Kedokansayang 01', 'Jl. Desa Kedokansayang', 'SDN Kedokansayang 01', '085878292058', '', '', 'pungkyst', '2017-07-28 07:37:10', '2019-08-18 09:16:42'),
(170, 'C', 'SDN Karangmangu 02', 'Jl. Pramuka No 1 Desa Karangmangu', 'SDN Karangmangu 02', '085664664385', '', '', 'pungkyst', '2017-07-28 07:37:51', '2019-08-18 09:16:47'),
(171, 'C', 'SDN Karangmangu 01', 'Jl. Loka Jaya Karangmangu', 'SDN Karangmangu 01', '081548136700', '', '', 'pungkyst', '2017-07-28 07:38:26', '2019-08-18 08:23:44'),
(172, 'C', 'SDN Karangjati 02', 'Jl. Balti No.49 Karangjati', 'SDN Karangjati 02', '085642988200', '', '', 'pungkyst', '2017-07-28 07:39:02', '2019-08-18 09:16:52'),
(173, 'C', 'SDN Karangjati 01', 'Jl. Raya Utara Balamoa', 'SDN Karangjati 01', '085727516860', '', '', 'pungkyst', '2017-07-28 07:39:39', '2019-08-18 09:16:57'),
(174, 'C', 'SDN Kalijambe 02', 'Jl. Wanabhakti Kalijambe', 'SDN Kalijambe 02', '085640024329', '', '', 'pungkyst', '2017-07-28 07:40:23', '2019-08-18 09:17:02'),
(175, 'C', 'SDN Kalijambe 01', 'Jl. Wanabakti', 'SDN Kalijambe 01', '085719659086', '', '', 'pungkyst', '2017-07-28 07:41:06', '2019-08-18 09:17:07'),
(176, 'C', 'SDN Kabukan 02', 'Desa Kabukan Kec.Tarub', 'SDN Kabukan 02', '085642741321', '', '', 'pungkyst', '2017-07-28 07:41:51', '2019-08-18 08:23:49'),
(177, 'C', 'SDN Jatirawa 03', 'Jl. Raya Balamoa - Banjaran', 'SDN Jatirawa 03', '081511830784', '', '', 'pungkyst', '2017-07-28 07:42:43', '2019-08-18 09:17:12'),
(178, 'C', 'SDN Jatirawa 02', 'Jl. Banjaran - Balamoa Jatirawa', 'SDN Jatirawa 02', '85642673103', '', '', 'pungkyst', '2017-07-28 07:43:53', '2019-08-18 08:23:54'),
(179, 'C', 'SDN Jatirawa 01', 'Jl. Merak Jatirawa', 'SDN Jatirawa 01', '085742866677', '', '', 'pungkyst', '2017-07-28 07:44:41', '2019-08-18 09:17:17'),
(180, 'C', 'SDN Bumiharja 02', 'Jl. Pendidikan No.4', 'SDN Bumiharja 02', '087730217719', '', '', 'pungkyst', '2017-07-28 07:46:50', '2019-08-18 08:23:59'),
(181, 'C', 'SDN Bulakwaru 03', 'Jl. Melati Bulakwaru', 'SDN Bulakwaru 03', '08164222583', '', '', 'pungkyst', '2017-07-28 07:47:46', '2019-08-18 08:24:04'),
(182, 'C', 'SDN Bulakwaru 02', 'Jl. Melati Bulakwaru', 'SDN Bulakwaru 02', '085878440142', '', '', 'pungkyst', '2017-07-28 07:48:29', '2019-08-18 09:17:22'),
(183, 'C', 'SDN Bulakwaru 01', 'Jl. Anggrek Desa Bulakwaru ', 'SDN Bulakwaru 01', '083837117528', '', '', 'pungkyst', '2017-07-28 07:49:18', '2019-08-18 08:24:09'),
(184, 'C', 'SDN Brekat 02', 'Jl. Raya Utara Pasar Balamoa Km 1 Desa Brekat', 'SDN Brekat 02', '085775776348', '', '', 'pungkyst', '2017-07-28 07:53:58', '2019-08-18 09:17:27'),
(185, 'C', 'SDN Brekat 01', 'Jl. Raya Kwayuan Brekat', 'SDN Brekat 01', '085729015239', '', '', 'pungkyst', '2017-07-28 07:54:38', '2019-08-18 08:24:14'),
(186, 'C', 'SDN Pekiringan 01', 'Jl. Protokol Desa Pekiringan', 'SDN Pekiringan 01', '085659707497', '', '', 'pungkyst', '2017-07-28 07:55:32', '2019-08-18 09:17:32'),
(187, 'C', 'SD Muhammadiyah Pesayangan', 'Jl. Logam Rt. 14 / rw. III Pesayangan - Talang - Tegal', 'SD Muhammadiyah Pesayangan', '083861611699', '', '', 'pungkyst', '2017-07-28 07:56:24', '2019-08-18 09:17:37'),
(188, 'C', 'SD Penawaja Kajen', 'Jl. Taman Penawaja', 'SD Penawaja Kajen', '085740422048', '', '', 'pungkyst', '2017-07-28 07:57:09', '2019-08-18 08:24:19'),
(189, 'C', 'SDN Getaskerep 02', 'Jl.Projosumarto 1 Getaskerep', 'SDN Getaskerep 02', '085786021168', '', '', 'pungkyst', '2017-07-28 08:18:26', '2019-08-18 09:17:42'),
(190, 'C', 'SDN Wangandawa 01', 'Jl. Hasyim Dirjosubroto Wangandawa Kec. Talang Kab. Tegal', 'SDN Wangandawa 01', '085642713731', '', '', 'pungkyst', '2017-07-28 08:19:37', '2019-08-18 09:17:47'),
(191, 'C', 'SDN Kaligayam 01', 'Jl. Projosumarto I Kaligayam Talang Tegal', 'SDN Kaligayam 01', '085642985662', '', '', 'pungkyst', '2017-07-28 08:20:42', '2019-08-18 09:17:52'),
(192, 'C', 'SDN Kaligayam 02', 'Jl.Duwet No.5 Kaligayam Kec. Talang', 'SDN Kaligayam 02', '085786924015', '', '', 'pungkyst', '2017-07-28 08:22:55', '2019-08-18 09:17:57'),
(193, 'C', 'SDN Langgen', ';Jl. Kaligawe Langgen-Talang', 'SDN Langgen', '085869322268', '', '', 'pungkyst', '2017-07-28 08:23:36', '2019-08-18 09:18:02'),
(194, 'C', 'SDN Pasangan 02', 'Desa Pasangan kec.Talang', 'SDN Pasangan 02', '085842146788', '', '', 'pungkyst', '2017-07-28 08:24:30', '2019-08-18 08:24:24'),
(195, 'C', 'SDN Pesayangan 01', 'Jl. Logam No.99 Pesayangan', 'SDN Pesayangan 01', '085742847504', '', '', 'pungkyst', '2017-07-28 08:25:43', '2019-08-18 09:18:07'),
(196, 'C', 'SDN Tegalwangi 01', 'Jl. Raya Tegalwangi  Kec. Talang Kab. Tegal', 'SDN Tegalwangi 01', '085742931118', '', '', 'pungkyst', '2017-07-28 08:27:02', '2019-08-18 08:24:29'),
(197, 'C', 'SDN Talang 01', 'Jl. Raya Utara Talang ', 'SDN Talang 01', '085328042458', '', '', 'pungkyst', '2017-07-28 08:27:59', '2019-08-18 08:24:34'),
(198, 'C', 'SDN Dawuhan ', 'Jl. Kemuning 2016 Dawuhan', 'SDN Dawuhan ', '085742153126', '', '', 'pungkyst', '2017-07-28 08:28:50', '2019-08-18 09:18:12'),
(199, 'C', 'SDN Kebasen 01', 'Jl. KH. Umar Asnawi III Kebasen -  Talang - Tegal', 'SDN Kebasen 01', '085742708372', '', '', 'pungkyst', '2017-07-28 08:29:31', '2019-08-18 08:24:39'),
(200, 'C', 'SDN Dukuhmalang 01', 'Jl. Projosumarto II Desa Dukuhmalang ', 'SDN Dukuhmalang 01', '085642977775', '', '', 'pungkyst', '2017-07-28 08:30:31', '2019-08-18 08:24:44'),
(201, 'C', 'SDN Kaligayam 03', 'Jl. Duwet Kaligayam', 'SDN Kaligayam 03', '082134655552', '', '', 'pungkyst', '2017-07-28 08:31:23', '2019-08-18 09:18:17'),
(202, 'C', 'SDN Kajen 02', 'Jl. Narawisan - Desa Kajen ', 'SDN Kajen 02', '085640030816', '', '', 'pungkyst', '2017-07-28 08:32:09', '2019-08-18 08:24:49'),
(203, 'C', 'SDN Gembong 02', 'Jl. Wareng ', 'SDN Gembong 02', '085786623053', '', '', 'pungkyst', '2017-07-28 08:33:00', '2019-08-18 09:18:22'),
(204, 'C', 'SDN Pacul 02', 'Jl Raya Timur Balai Desa Pacul ', 'SDN Pacul 02', '085742318017', '', '', 'pungkyst', '2017-07-28 08:33:47', '2019-08-18 08:24:54'),
(205, 'C', 'SDN Pasangan 01', 'Jl. Pecakran Ds. Pasangan', 'SDN Pasangan 01', '085742999838', '', '', 'pungkyst', '2017-07-28 08:34:31', '2019-08-18 09:18:27'),
(206, 'C', 'SDN Kaladawa 01', 'Kaladawa', 'SDN Kaladawa 01', '085888885819', '', '', 'pungkyst', '2017-07-28 08:35:29', '2019-08-18 09:18:32'),
(207, 'C', 'SDN Getaskerep 01', 'Jl. Projosumarto I Getaskerep', 'SDN Getaskerep 01', '085727309333', '', '', 'pungkyst', '2017-07-28 08:36:35', '2019-08-18 09:18:37'),
(208, 'C', 'SD Islam Fitra Bhakti', 'Jl. Raya Perum Kopkar - Rinenggo Asri - Pudakpayung', 'SD Islam Fitra Bhakti', '089669077957', '', '', 'pungkyst', '2017-07-28 08:37:58', '2019-08-18 09:18:42'),
(209, 'C', 'SDN Tinjomoyo 03', 'Jl. Gombel Lama No.36 Semarang', 'SDN Tinjomoyo 03', '081390090036', '', '', 'pungkyst', '2017-07-28 08:38:53', '2019-08-18 09:18:47'),
(210, 'C', 'SDN Tinjomoyo 01', 'Jl. Taman Teuku Umar No.2 Semarang', 'SDN Tinjomoyo 01', '085641884990', '', '', 'pungkyst', '2017-07-28 08:39:58', '2019-08-18 08:24:59'),
(211, 'C', 'SDN Srondol Wetan 06', 'Jl. Jend Pol Anton Sujarwo No. 218', 'SDN Srondol Wetan 06', '085727311811', '', '', 'pungkyst', '2017-07-28 08:41:17', '2019-08-18 09:18:52'),
(212, 'C', 'SDN Srondol Wetan 05', 'Jl. Keruing Raya ', 'SDN Srondol Wetan 05', '087731327862', '', '', 'pungkyst', '2017-07-28 08:45:24', '2019-08-18 09:18:57'),
(213, 'C', 'SDN Srondol Wetan 04', 'Jl. Rasamala Raya Srondol Wetan Banyumanik Semarang', 'SDN Srondol Wetan 04', '085641610383', '', '', 'pungkyst', '2017-07-28 08:46:39', '2019-08-18 09:19:02'),
(214, 'C', 'SDN Srondol Wetan 01', 'Jl. Ace No.41 ', 'SDN Srondol Wetan 01', '085799938957', '', '', 'pungkyst', '2017-07-28 08:47:37', '2019-08-18 08:25:04'),
(215, 'C', 'SDN Srondol Kulon 03', 'Jl. Srondol Kulon No. 10 Rt. 05 / Rw. 07 Banyumanik', 'SDN Srondol Kulon 03', '085647996699', '', '', 'pungkyst', '2017-07-28 08:49:46', '2019-08-18 08:25:10'),
(216, 'C', 'SDN Srondol Kulon 02', 'Jl. Setiabudi No. 145 Rt.01 Rw.05 Kel. Srondol Kulon Kec. Banyumanik Kota Semarang', 'SDN Srondol Kulon 02', '085796228415', '', '', 'pungkyst', '2017-07-28 08:51:58', '2019-08-18 08:25:15'),
(217, 'C', 'SDN Pudakpayung 03', 'Jl. Grogol III Rt. 06 / Rw. 03 Pudakpayung', 'SDN Pudakpayung 03', '085727146065', '', '', 'pungkyst', '2017-07-28 08:53:13', '2019-08-18 08:25:20'),
(218, 'C', 'SDN Pudakpayung 02', 'Jl Payung Asri Rt.02/Rw.01 Pudakpayung Semarang', 'SDN Pudakpayung 02', '085740106478', '', '', 'pungkyst', '2017-07-28 08:54:05', '2019-08-18 08:25:25'),
(219, 'C', 'SDN Pudakpayung 01', 'Jl. Perintis Kemerdekaan No. 159A ', 'SDN Pudakpayung 01', '085743414331', '', '', 'pungkyst', '2017-07-28 08:55:16', '2019-08-18 09:19:07'),
(220, 'C', 'SDN Pedalangan 02', 'Jl.Jatimulyo no 4b kel. Pedalangan Kec. Banyumanik Semarang', 'SDN Pedalangan 02', '085727180766', '', '', 'pungkyst', '2017-07-28 08:55:59', '2019-08-18 09:19:12'),
(221, 'C', 'SDN Pedalangan 01', 'Jl.Durian Raya no.8', 'SDN Pedalangan 01', '085726726583', '', '', 'pungkyst', '2017-07-28 09:00:58', '2019-08-18 09:19:17'),
(223, 'C', 'SDN Padangsari 02', 'Jl. Merbau Rt.05 Rw.09 Banyumanik Semarang', 'SDN Padangsari 02', '085640060744', '', '', 'pungkyst', '2017-07-31 07:26:23', '2019-08-18 08:25:30'),
(224, 'C', 'SDN Ngesrep 03', 'Jl. Tamtama Barat VI ', 'SDN Ngesrep 03', '082220870776', '', '', 'pungkyst', '2017-07-31 07:27:40', '2019-08-18 08:25:35'),
(225, 'C', 'SDN Ngesrep 02', 'Jl. Jatiluhur I Rt.04 Rw.05', 'SDN Ngesrep 02', '081228062762', '', '', 'pungkyst', '2017-07-31 07:28:30', '2019-08-18 09:19:22'),
(226, 'C', 'SDN Ngesrep 01', 'Jl. Trangkil No.117', 'SDN Ngesrep 01', '085640744546', '', '', 'pungkyst', '2017-07-31 07:29:26', '2019-08-18 08:25:40'),
(227, 'C', 'SDN Jabungan', 'Jl. Ringin Bhakti Jabungan Banyumanik Semarang ', 'SDN Jabungan', '085740895620', '', '', 'pungkyst', '2017-07-31 07:30:25', '2019-08-18 09:19:27'),
(228, 'C', 'SDN Gedawang 01', 'Jl. Tejosari Raya Rt.05 Rw.05 Gedawang', 'SDN Gedawang 01', '085713097508', '', '', 'pungkyst', '2017-07-31 07:31:26', '2019-08-18 09:19:32'),
(229, 'C', 'SDN Sumurrejo 02', 'Jl. Sumurgunung No.3 Rt.01 Rw.05 Kel. Sumurrejo', 'SDN Sumurrejo 02', '08886510900', '', '', 'pungkyst', '2017-07-31 07:33:05', '2019-08-18 08:25:45'),
(230, 'C', 'SMA Islam Pekalongan', 'Jl. Surabaya No.1 Pekalongan', 'SMA Islam Pekalongan', '085601011221', '', '', 'pungkyst', '2017-07-31 07:34:02', '2019-08-18 08:25:50'),
(231, 'C', 'SDN Panjang Wetan 04', 'Jl. Pantaisari 2 No.8', 'SDN Panjang Wetan 04', '085642637931', '', '', 'pungkyst', '2017-07-31 07:34:56', '2019-08-18 08:25:55'),
(232, 'C', 'SDN 04 Gendowang ', 'Dukuh Cikalong Desa Gendowang Kec.Moga', 'SDN 04 Gendowang ', '081903359273', '', '', 'pungkyst', '2017-07-31 07:36:10', '2019-08-18 08:26:00'),
(233, 'C', 'SDN 04 Walangsanga', 'Jl. Pelampean Walangsanga Moga', 'SDN 04 Walangsanga', '085642661567', '', '', 'pungkyst', '2017-07-31 07:37:09', '2019-08-18 08:26:05'),
(234, 'C', 'SMP Plus Salafiyah Kauman Pemalang', 'Jl. Kauman No.17 Kebondalem Pemalang', 'SMP Plus Salafiyah Kauman Pemalang ', '085742264987', '', '', 'pungkyst', '2017-07-31 07:38:32', '2019-08-18 09:19:37'),
(235, 'C', 'SMP Nurul Islam Tanahbaya', 'Desa Tanahbaya Kec. Randudongkal Kab. Pemalang', 'SMP Nurul Islam Tanahbaya', '087700773616', '', '', 'pungkyst', '2017-07-31 07:39:44', '2019-08-18 09:19:42'),
(236, 'C', 'SMPN 4 Taman', 'Jl. Raya Sitemu ', 'SMPN 4 Taman', '085742127999', '', '', 'pungkyst', '2017-07-31 07:40:26', '2019-08-18 08:26:10'),
(237, 'C', 'SMP Al Manshuriyah Pemalang', 'Jl. Raya Mengori Rt.06 Rw.03 Desa Mengori Kec. Pemalang Kab. Pemalang', 'SMP Al Manshuriyah Pemalang', '085640320015', '', '', 'pungkyst', '2017-07-31 07:41:43', '2019-08-18 09:19:48'),
(238, 'C', 'SDN Sambeng', 'Jl. Raya Sambeng - Kalitorong Km 3', 'SDN Sambeng', '082326115013', '', '', 'pungkyst', '2017-07-31 07:42:44', '2019-08-18 09:19:53'),
(239, 'C', 'SDN Pabuaran', 'Jl. Raya Desa Pabuaran', 'SDN Pabuaran', '081325543984', '', '', 'pungkyst', '2017-07-31 07:43:25', '2019-08-18 09:19:58'),
(240, 'C', 'SDN Karangdawa', 'Karangdawa - Warungpring', 'SDN Karangdawa', '085201111797', '', '', 'pungkyst', '2017-07-31 07:44:16', '2019-08-18 09:20:03'),
(241, 'C', 'SDN Datar', 'Datar - Warungpring', 'SDN Datar', '081903696143', '', '', 'pungkyst', '2017-07-31 07:44:54', '2019-08-18 09:20:09'),
(242, 'C', 'SDN 08 Warungpring ', 'Warungpring', 'SDN 08 Warungpring ', '087700834921', '', '', 'pungkyst', '2017-07-31 07:45:37', '2019-08-18 09:20:14'),
(243, 'C', 'SDN 07 Warungpring', 'Warungpring', 'SDN 07 Warungpring', '08773356270', '', '', 'pungkyst', '2017-07-31 07:46:37', '2019-08-18 09:20:19'),
(244, 'C', 'SDN 07 Bantarbolang', 'Jl. Pancasakti No.01 Bantarbolang ', 'SDN 07 Bantarbolang', '081325048404', '', '', 'pungkyst', '2017-07-31 07:47:31', '2019-08-18 09:20:24'),
(245, 'C', 'SDN 06 Sima', 'Desa Sima Kec.Moga', 'SDN 06 Sima', '085742242575', '', '', 'pungkyst', '2017-07-31 07:48:27', '2019-08-18 08:26:15'),
(246, 'C', 'SDN 06 Sikasur', 'Sikasur', 'SDN 06 Sikasur', '087730046969', '', '', 'pungkyst', '2017-07-31 07:49:02', '2019-08-18 08:26:20'),
(247, 'C', 'SDN 06 Gombong', 'Jl. Kandang Gotong - Tepus Km 1', 'SDN 06 Gombong', '0817431396', '', '', 'pungkyst', '2017-07-31 07:49:46', '2019-08-18 08:26:25'),
(248, 'C', 'SDN 05 Warungpring', 'Warungpring', 'SDN 05 Warungpring', '085742746466', '', '', 'pungkyst', '2017-07-31 07:50:26', '2019-08-18 08:26:30'),
(249, 'C', 'SDN 05 Wanarata', 'Jl. Benteng - Wanarata', 'SDN 05 Wanarata', '085742439396', '', '', 'pungkyst', '2017-07-31 07:51:10', '2019-08-18 08:26:35'),
(250, 'C', 'SDN 05 Moga', 'Jl. Manggar No. 10 Moga', 'SDN 05 Moga', '087733441110', '', '', 'pungkyst', '2017-07-31 07:51:53', '2019-08-18 09:20:29'),
(251, 'C', 'SDN 05 Mereng', 'Mereng - Warungpring', 'SDN 05 Mereng', '081902733334', '', '', 'pungkyst', '2017-07-31 07:52:33', '2019-08-18 09:20:34'),
(252, 'C', 'SDN 05 Gunungjaya', 'Desa Gunungjaya', 'SDN 05 Gunungjaya', '085328016444', '', '', 'pungkyst', '2017-07-31 07:53:13', '2019-08-18 08:26:40'),
(253, 'C', 'SDN 05 Cibuyur', 'Cibuyur - Warungpring', 'SDN 05 Cibuyur', '085201611997', '', '', 'pungkyst', '2017-07-31 07:53:49', '2019-08-18 09:20:39'),
(254, 'C', 'SDN 05 Bantarbolang', 'Jl. Raya Bantarbolang', 'SDN 05 Bantarbolang', '085786983124', '', '', 'pungkyst', '2017-07-31 07:54:30', '2019-08-18 08:26:45'),
(255, 'C', 'SDN 04 Warungpring', 'Warungpring', 'SDN 04 Warungpring', '087711723622', '', '', 'pungkyst', '2017-07-31 07:55:04', '2019-08-18 08:26:50'),
(256, 'C', 'SDN 04 Wanarata', 'Jl. Sutomo Timur - Wanarata', 'SDN 04 Wanarata', '087830538636', '', '', 'pungkyst', '2017-07-31 07:55:49', '2019-08-18 08:26:55'),
(257, 'C', 'SDN 04 Pengiringan', 'Jl. Sipedang No.07 Pengiringan', 'SDN 04 Pengiringan', '089615581751', '', '', 'pungkyst', '2017-07-31 07:56:33', '2019-08-18 09:20:44'),
(258, 'C', 'SDN 04 Mereng', 'Mereng - Warungpring', 'SDN 04 Mereng', '087710217898', '', '', 'pungkyst', '2017-07-31 07:57:06', '2019-08-18 08:27:00'),
(259, 'C', 'SDN 04 Kuta', 'Jl. Gunung Wangi Kuta', 'SDN 04 Kuta', '085225645344', '', '', 'pungkyst', '2017-07-31 07:57:56', '2019-08-18 08:27:05'),
(260, 'C', 'SDN 04 Kuta Belik', 'Utara Pasar Desa Kuta Rt.05 Rw.02 ', 'SDN 04 Kuta Belik', '087733441147', '', '', 'pungkyst', '2017-07-31 07:58:49', '2019-08-18 08:27:11'),
(261, 'C', 'SDN 04 Cibuyur', 'Cibuyur - Warungpring', 'SDN 04 Cibuyur', '087711992536', '', '', 'pungkyst', '2017-07-31 07:59:35', '2019-08-18 08:27:15'),
(262, 'C', 'SDN 03 Warungpring', 'Warungpring', 'SDN 03 Warungpring', '087710201987', '', '', 'pungkyst', '2017-07-31 08:00:14', '2019-08-18 08:27:20'),
(263, 'C', 'SDN 03 Tasikrejo', 'Jl. Desa Tasikrejo', 'SDN 03 Tasikrejo', '085642502365', '', '', 'pungkyst', '2017-07-31 08:01:04', '2019-08-18 09:20:52'),
(264, 'C', 'SDN 03 Sima', 'Jl. Moga Karangsari Km 03', 'SDN 03 Sima', '081326978557', '', '', 'pungkyst', '2017-07-31 08:01:43', '2019-08-18 09:20:57'),
(265, 'C', 'SDN 03 Sikasur', 'Jl. Raya Sikasur - Simpur', 'SDN 03 Sikasur', '085640479891', '', '', 'pungkyst', '2017-07-31 08:02:33', '2019-08-18 09:21:02'),
(266, 'C', 'SDN 03 Pengiringan', 'Jl. Sutomo No.179 Pengiringan', 'SDN 03 Pengiringan', '082325413223', '', '', 'pungkyst', '2017-07-31 08:03:23', '2019-08-18 09:21:07'),
(267, 'C', 'SDN 03 Pamutih', 'Jl. Beringin No.2 Desa Pamutih Kec. Ulujami Kab. Pemalang', 'SDN 03 Pamutih', '085778809914', '', '', 'pungkyst', '2017-07-31 08:04:57', '2019-08-18 09:21:12'),
(268, 'C', 'SDN 03 Pagergunung', 'Jl. Desa Pagergunung Rt.04 Rw.03 Kec.Ulujami', 'SDN 03 Pagergunung', '082326637576', '', '', 'pungkyst', '2017-07-31 08:06:11', '2019-08-18 08:27:25'),
(269, 'C', 'SDN 03 Mojo', 'Desa Mojo', 'SDN 03 Mojo', '085842293023', '', '', 'pungkyst', '2017-07-31 08:06:44', '2019-08-18 09:21:17'),
(270, 'C', 'SDN 03 Mereng', 'Mereng - Warungpring', 'SDN 03 Mereng', '085642584896', '', '', 'pungkyst', '2017-07-31 08:07:26', '2019-08-18 08:27:30'),
(271, 'C', 'SDN 03 Limbang', 'Jl.Desa Limbangan Kec. Uljami Kab. Pemalang', 'SDN 03 Limbang', '085742742615', '', '', 'pungkyst', '2017-07-31 08:08:27', '2019-08-18 08:27:35'),
(272, 'C', 'SDN 03 Kuta', 'Jl. Lingkar Selatan Desa Kuta ', 'SDN 03 Kuta', '081914141619', '', '', 'pungkyst', '2017-07-31 08:09:22', '2019-08-18 09:21:22'),
(273, 'C', 'SDN 03 Kaliprau', 'Jl. Lamaran Desa Kaliprau Kec. Ulujami', 'SDN 03 Kaliprau', '087832501525', '', '', 'pungkyst', '2017-07-31 08:10:04', '2019-08-18 08:27:40'),
(274, 'C', 'SDN 03 Gombong', 'Jl. Raya Gombong - Pratin Km 1 Belik', 'SDN 03 Gombong', '085200262060', '', '', 'pungkyst', '2017-07-31 08:10:53', '2019-08-18 09:21:27'),
(275, 'C', 'SDN 03 Cibuyur', 'Cibuyur - Warungpring', 'SDN 03 Cibuyur', '081315359073', '', '', 'pungkyst', '2017-07-31 08:11:34', '2019-08-18 09:21:32'),
(276, 'C', 'SDN 03 Bulakan', 'Jl. Raya Randudongkal - Belik Km.7', 'SDN 03 Bulakan', '085228937892', '', '', 'pungkyst', '2017-07-31 08:12:25', '2019-08-18 09:21:37'),
(277, 'C', 'SDN 03 Banyumudal', 'Jl. Balapulang Timur Tumanggal Banyumudal', 'SDN 03 Banyumudal', '085726232123', '', '', 'pungkyst', '2017-07-31 08:13:18', '2019-08-18 08:27:45'),
(278, 'C', 'SDN 03 Bantarbolang', 'Jl. Raya Bantarbolang', 'SDN 03 Bantarbolang', '087733530613', '', '', 'pungkyst', '2017-07-31 08:13:59', '2019-08-18 08:27:50'),
(279, 'C', 'SDN 02 Wiyorowetan', 'Jl. Desa Wiyorowetan', 'SDN 02 Wiyorowetan', '085600299811', '', '', 'pungkyst', '2017-08-02 09:14:13', '2019-08-18 08:27:55'),
(280, 'C', 'SDN 02 Warungpring', 'Warungpring', 'SDN 02 Warungpring', '082324021374', '', '', 'pungkyst', '2017-08-02 09:31:29', '2019-08-18 09:21:42'),
(281, 'C', 'SDN 02 Wanarata', 'Jl. Sutomo Timur - Wanarata', 'SDN 02 Wanarata', '087830523866', '', '', 'pungkyst', '2017-08-02 09:34:03', '2019-08-18 08:28:01'),
(282, 'C', 'SDN 02 Taikrejo', 'Jl. Desa Tasikrejo Kec. Ulujami Kab. Pemalang', 'SDN 02 Taikrejo', '085742047316', '', '', 'pungkyst', '2017-08-02 09:35:27', '2019-08-18 08:28:06'),
(283, 'C', 'SDN 02 Suru', 'Jl. Sutomo Timur - Wanarata', 'SDN 02 Suru', '085226770103', '', '', 'pungkyst', '2017-08-02 09:36:45', '2019-08-18 09:21:47'),
(284, 'C', 'SDN 02 Sukorejo', 'Dukuh Sumur Lembu', 'SDN 02 Sukorejo', '085641844798', '', '', 'pungkyst', '2017-08-02 09:37:39', '2019-08-18 08:28:11'),
(285, 'C', 'SDN 02 Pesantren', 'Jl. PTP Nusantara IX Desa Pesantren', 'SDN 02 Pesantren', '085747840545', '', '', 'pungkyst', '2017-08-02 09:42:26', '2019-08-18 08:28:16'),
(286, 'C', 'SDN 02 Peguyangan', 'Jl. Desa Peguyungan - Lenggerong No. 2', 'SDN 02 Peguyangan', '085786382226', '', '', 'pungkyst', '2017-08-02 09:43:25', '2019-08-18 09:21:52'),
(287, 'C', 'SDN 02 Pengiringan', 'Jl. Raya Pemalang - Moga Km 23', 'SDN 02 Pengiringan', '081903334967', '', '', 'pungkyst', '2017-08-02 09:49:15', '2019-08-18 08:28:21'),
(288, 'C', 'SDN 02 Pakembaran', 'Pakembaran - Warungpring', 'SDN 02 Pakembaran', '085786035379', '', '', 'pungkyst', '2017-08-02 09:50:18', '2019-08-18 09:21:57'),
(289, 'C', 'SDN 02 Mereng', 'Mereng - Warungpring', 'SDN 02 Mereng', '085642654937', '', '', 'pungkyst', '2017-08-02 09:52:06', '2019-08-18 09:22:02'),
(290, 'C', 'SDN 02 Kebon Gede', 'Jl. Manunggal No. 180', 'SDN 02 Kebon Gede', '081345571486', '', '', 'pungkyst', '2017-08-02 09:53:07', '2019-08-18 08:28:26'),
(291, 'C', 'SDN 02 Gombong', 'Jl. Goa Lawa', 'SDN 02 Gombong', '085642993369', '', '', 'pungkyst', '2017-08-02 09:53:53', '2019-08-18 08:28:31'),
(292, 'C', 'SDN 02 Cibuyur', 'Cibuyur - Warungpring', 'SDN 02 Cibuyur', '085743644815', '', '', 'pungkyst', '2017-08-02 09:55:36', '2019-08-18 08:28:36'),
(293, 'C', 'SDN 02 Blendung', 'Blendung', 'SDN 02 Blendung', '085640794491', '', '', 'pungkyst', '2017-08-02 09:56:36', '2019-08-18 09:22:07'),
(294, 'C', 'SDN 02 Banyumudal', 'Jl. Balimbing Dukuh Gumuk', 'SDN 02 Banyumudal', '081572517407', '', '', 'pungkyst', '2017-08-02 09:59:13', '2019-08-18 08:28:41'),
(295, 'C', 'SDN 02 Bantarbolang', 'Jl. Raya Bantarbolang No. 177', 'SDN 02 Bantarbolang', '08985876952', '', '', 'pungkyst', '2017-08-02 10:04:56', '2019-08-18 09:22:12'),
(296, 'C', 'SDN 02 Banjarsari', 'Jl. H. Hasyim - Banjarsari ', 'SDN 02 Banjarsari', '081390178366', '', '', 'pungkyst', '2017-08-02 10:07:04', '2019-08-18 09:22:17'),
(297, 'C', 'SD N Rpoyonanggan 05', 'Jl. Brigjend Katamso No. 29 Batang', 'SD N Rpoyonanggan 05', '081542063126', '', '', 'pungkyst', '2017-08-02 10:07:31', '2019-08-18 09:22:22'),
(298, 'C', 'SMK PGRI Batang', 'Jl. Ki Mangunsarkoro No 25 Batang', 'SMK PGRI Batang', '089624655247', '', '', 'pungkyst', '2017-08-02 10:08:48', '2019-08-18 09:22:27'),
(299, 'C', 'SDN 01 Warungpring', 'Warungpring', 'SDN 01 Warungpring', '085200087315', '', '', 'pungkyst', '2017-08-02 10:09:22', '2019-08-18 08:28:46'),
(300, 'C', 'SMP N 1 Bawang', 'Desa Pangempon', 'SMP N 1 Bawang', '-', '', '', 'pungkyst', '2017-08-02 10:10:12', '2019-08-18 09:22:32'),
(301, 'C', 'SDN 01 Suru', 'Jl. Karang Suru No. 1 Suru', 'SDN 01 Suru', '087764642544', '', '', 'pungkyst', '2017-08-02 10:11:15', '2019-08-18 08:28:51'),
(302, 'C', 'SMK Muhammadiyah Batang', 'Jl.Pemuda Gg.Talangan Cepoko Kuning Batang', 'SMK Muhammadiyah Batang', '085842188266', '', '', 'pungkyst', '2017-08-02 10:11:45', '2019-08-18 09:22:37'),
(303, 'C', 'SDN 01 Sukorejo', 'Desa Sukorejo', 'SDN 01 Sukorejo', '085875801825', '', '', 'pungkyst', '2017-08-02 10:12:08', '2019-08-18 09:22:42'),
(304, 'C', 'SMA Islam Ahmad Yani Batang', 'Jl. Kyaisurgi Proyonanggan Selatan Batang', 'SMA Islam Ahmad Yani Batang', '085786355744', '', '', 'pungkyst', '2017-08-02 10:13:15', '2019-08-18 09:22:47'),
(305, 'C', 'SMP Negeri 3 Tersono', 'Jl. Ds. Sidalang  Kec. Tersono  Kab. Batang\r\n\r\n', 'SMP Negeri 3 Tersono', '081326896900', '', '', 'pungkyst', '2017-08-02 10:15:05', '2019-08-18 08:28:56'),
(306, 'C', 'SMP Negeri 2 Subah', 'Jalan Raya Kalimanggis No. 2 Subah - Batang', 'SMP Negeri 2 Subah', '085640652008', '', '', 'pungkyst', '2017-08-02 10:16:20', '2019-08-18 09:22:52'),
(307, 'C', 'SMP Negeri 3 Gringsing', 'Jl. Raya Krengseng no. 107 A Gringsing Batang', 'SMP Negeri 3 Gringsing', '085866274636', '', '', 'pungkyst', '2017-08-02 10:17:19', '2019-08-18 08:29:01'),
(308, 'C', 'SMP Negeri 2 Kandeman', 'Desa Karanggeneng RT 14/02 Kandeman Batang', 'SMP Negeri 2 Kandeman', '085878672090', '', '', 'pungkyst', '2017-08-02 10:18:19', '2019-08-18 08:29:06'),
(309, 'C', 'SDN 01 Simpur', 'Desa Simpur Kec. Belik Kab. Pemalang 52356', 'SDN 01 Simpur', '087733446638', '', 'No.Hp lain 085257252407', 'pungkyst', '2017-08-02 10:20:09', '2019-08-18 08:29:11'),
(310, 'C', 'SMP N 1 Tersono', 'Jl. Raya Tersono  Kec. Tersono Kab. Batang\r\n', 'SMP N 1 Tersono', '085640000760', '', '', 'pungkyst', '2017-08-02 10:20:59', '2019-08-18 08:29:16'),
(311, 'C', 'SMP N 2 Blado', 'Desa Kembangan ', 'SMP N 2 Blado', '085600580111', '', '', 'pungkyst', '2017-08-02 10:22:38', '2019-08-18 08:29:21'),
(312, 'C', 'SDN 01 Sikasur', 'Jl. Sikasur - Simpur Rt. 01 Rw. 06 Kec. Belik - Pemalang Jawa Tengah 52356', 'SDN 01 Sikasur', '085640180551', '', '', 'pungkyst', '2017-08-02 10:22:51', '2019-08-18 09:22:57'),
(313, 'C', 'SMP N 2 Gringsing', 'Jl. Raya Surodadi - Gringsing - Batang', 'SMP N 2 Gringsing', '0817275663', '', '', 'pungkyst', '2017-08-02 10:24:05', '2019-08-18 09:23:02'),
(314, 'C', 'SMP N Reban', 'Desa Kumesu Kecamatan Reban', 'SMP N 2 Reban', '081391727627', '', '', 'pungkyst', '2017-08-02 10:25:20', '2019-08-18 08:29:26'),
(315, 'C', 'SDN 01 Samong', 'Jl. Desa Samong', 'SDN 01 Samong', '085842071652', '', '', 'pungkyst', '2017-08-02 10:25:37', '2019-08-18 08:29:31'),
(316, 'C', 'SMP N 2 Limpung', 'Jl. Raya Limpung-Banyuputih Kabupaten Batang', 'SMP N 2 Limpung', '085642525505', '', '', 'pungkyst', '2017-08-02 10:26:36', '2019-08-18 08:29:36'),
(317, 'C', 'SD N Tenggulangharjo', 'Krajan I RT02 RW 03', 'SD N Tenggulangharjo', '085226852445', '', '', 'pungkyst', '2017-08-02 10:27:41', '2019-08-18 08:29:42'),
(318, 'C', 'SDN 01 Rowosari', 'Jl. Raya Ulujami Barat No. 114', 'SDN 01 Rowosari', '085865258805', '', '', 'pungkyst', '2017-08-02 10:28:36', '2019-08-18 08:29:46'),
(319, 'C', 'SD Negeri Subah 01', 'Jalan Raya Subah No.59', 'SD Negeri Subah 01', '085866432748', '', '', 'pungkyst', '2017-08-02 10:28:58', '2019-08-18 08:29:51'),
(320, 'C', 'SDN 01 Pegiringan ', 'Jl. Raya Pegiringan Km. 23', 'SDN 01 Pegiringan ', '085201087206', '', '', 'pungkyst', '2017-08-02 10:29:33', '2019-08-18 08:29:56'),
(321, 'C', 'SD N Ujungnegoro 01', 'Jl. Syeh Maulana Maghribi Ujungnegoro', 'SD N Ujungnegoro 01', '08973518143', '', '', 'pungkyst', '2017-08-02 10:30:17', '2019-08-18 08:30:01'),
(322, 'C', 'SDN 01 Pamutih', 'Desa Pamutih', 'SDN 01 Pamutih', '081542421514', '', '', 'pungkyst', '2017-08-02 10:30:19', '2019-08-18 08:30:06'),
(323, 'C', 'SDN 01 Glandang', 'Jl. A. Yani No. 74', 'SDN 01 Glandang', '085881329499', '', '', 'pungkyst', '2017-08-02 10:31:16', '2019-08-18 09:23:07');
INSERT INTO `ms_client` (`idclt_clt`, `type_clt`, `prshan_clt`, `almat_clt`, `cname_clt`, `nohp_clt`, `email_clt`, `ktrgn_clt`, `usrpw_clt`, `create_at`, `update_at`) VALUES
(324, 'C', 'SDN 01 Pakembaran', 'Pakembaran - Warungpring', 'SDN 01 Pakembaran', '087730135061', '', '', 'pungkyst', '2017-08-02 10:31:18', '2019-08-18 09:23:12'),
(325, 'C', 'SDN 01 Kaliprau', 'Jl. Desa Kaliprau', 'SDN 01 Kaliprau', '085742862556', '', '', 'pungkyst', '2017-08-02 10:32:18', '2019-08-18 08:30:11'),
(326, 'C', 'SDN 01 Mereng', 'Mereng - Warungpring', 'SDN 01 Mereng', '081914104284', '', '', 'pungkyst', '2017-08-02 10:32:25', '2019-08-18 08:30:16'),
(327, 'C', 'SDN 01 Kebon Gede', 'Jl. Cagar Alam No. 51 Kebon Gede', 'SDN 01 Kebon Gede', '085741180221', '', '', 'pungkyst', '2017-08-02 10:33:23', '2019-08-18 08:30:21'),
(328, 'C', 'SDN 01 Kertosari', 'Jl. Poncol', 'SDN 01 Kertosari', '085642642019', '', '', 'pungkyst', '2017-08-02 10:34:19', '2019-08-18 08:30:26'),
(329, 'C', 'SDN 01 Kuta', 'Jl. Raya Belik - Watukumpul Km. 5', 'SDN 01 Kuta', '085642817464', '', '', 'pungkyst', '2017-08-02 10:35:46', '2019-08-18 09:23:17'),
(330, 'C', 'Siscabutikirana Shop', 'Solo', 'Sisca', '085725319354', '', '', 'aant', '2017-08-16 04:00:09', '0000-00-00 00:00:00'),
(334, 'C', 'Awansome', 'Salatiga', 'Aditya', '081228276609', '', 'E-commerce Jurnal : Wikiwrite', 'cds', '2017-08-16 06:52:35', '2019-08-18 09:23:22'),
(335, 'C', 'Puri Furniture Semarang', 'Ruko PRPP', 'Paul', '08122911888', '', 'Onlineshop full cart budget 3jt', 'cds', '2017-08-16 06:53:56', '2017-10-13 02:16:52'),
(336, 'C', 'Semedomanise', 'Wonosobo', 'Bp. Sobirin', '081327221055', '', '', 'pungkyst', '2017-08-28 03:54:10', '2018-04-13 06:05:55'),
(337, 'C', 'Kuala Lumpur', 'Malaysia', 'Panitia Pemilu Luar Negeri', '+6282138074117', 'masduki.k@gmail.com', '-', 'aant', '2017-08-29 14:16:59', '2018-11-06 12:50:23'),
(338, 'C', 'Awansome', 'Salatiga', 'Aditya', '-', '', '', 'aant', '2017-09-05 11:30:11', '0000-00-00 00:00:00'),
(339, 'C', 'Apotek Ihsan Farma 2', 'Jl. Puri Mediterania G17 Semarang', 'Andre Garcia', '08xxx', '', '', 'cds', '2017-09-08 09:38:26', '0000-00-00 00:00:00'),
(340, 'C', 'Badan Pertanahan Kota Wonogiri', 'Wonogiri', 'Pak Wiwin', '081392257127', 'atrbpnwonogiri@gmail.com', '', 'cds', '2017-09-11 04:21:53', '0000-00-00 00:00:00'),
(341, 'C', 'Suzuki Mobil', 'Jl. Jenderal Sudirman (samping toyota)', 'Tino', '081226428273', '', '', 'cds', '2017-10-06 04:16:06', '2017-10-09 19:18:03'),
(342, 'C', 'Polres Kota Tegal', '-', 'Fatwa Muhammad', '+62 812-2641-5159', '', '', 'aant', '2017-10-27 10:30:52', '0000-00-00 00:00:00'),
(343, 'C', 'Samaya Interactive', '-', 'Ricky K', '+6281325009998', 'ricky@samayainteractive.com', '', 'aant', '2017-11-01 08:54:05', '0000-00-00 00:00:00'),
(344, 'C', 'Toko Cerutu', '-', 'Arka Atmaja', '081326044457', '', '', 'pungkyst', '2017-11-06 04:04:33', '0000-00-00 00:00:00'),
(345, 'C', 'Sistem Imigrasi Sorong', '-', 'Arka Atmaja', '081326044457', '', '-', 'pungkyst', '2017-11-06 04:13:35', '0000-00-00 00:00:00'),
(346, 'C', 'Ikatan Alumni Geologi UNPAD', '-', 'Eko Gunoto', '08129059309', '', '08121075627', 'pungkyst', '2017-11-06 04:16:32', '0000-00-00 00:00:00'),
(347, 'C', 'Warta UDINUS', '-', 'Kholid', '087831683704', '', '-', 'pungkyst', '2017-11-06 04:17:37', '0000-00-00 00:00:00'),
(348, 'C', 'SMP N 4 Ungaran', '-', 'Yoan Irawan', '085641029894', '', '-', 'pungkyst', '2017-11-06 04:19:09', '0000-00-00 00:00:00'),
(349, 'C', 'Badan Ketahanan Pangan Jateng', '-', 'Arka Atmaja', '085641029894', '', '-', 'pungkyst', '2017-11-06 04:19:54', '0000-00-00 00:00:00'),
(350, 'C', 'Portal Berita', '-', 'Arka Atmaja', '081326044457', '', '', 'pungkyst', '2017-11-06 04:21:39', '2017-11-06 04:30:33'),
(351, 'C', 'DPRD Kedal', '-', 'Arka Atmaja', '081326044457', '', '', 'pungkyst', '2017-11-06 04:22:42', '2017-11-06 04:25:28'),
(352, 'C', 'Kejaksaan Negeri Lubuk Linggau', '-', 'Arka Atmaja', '081326044457', '', '', 'pungkyst', '2017-11-06 04:25:00', '0000-00-00 00:00:00'),
(353, 'C', 'SMP N 2 Susukan', '-', 'Kepala', '085641029894', '', '', 'pungkyst', '2017-11-06 04:34:10', '2019-01-02 08:07:46'),
(354, 'C', 'DPM KM UDINUS', '-', 'Lutfi', '085728065521', '', '089622052442', 'pungkyst', '2017-11-06 04:35:13', '0000-00-00 00:00:00'),
(355, 'C', 'PT Berkat Manunggal Jaya', '-', 'Firzha', '08886579176', '', '', 'pungkyst', '2017-11-06 04:35:56', '0000-00-00 00:00:00'),
(356, 'C', 'Toko Online Clothing', '-', 'We Clotihing', '085725816647', '', '5235B8CO', 'pungkyst', '2017-11-06 04:36:58', '0000-00-00 00:00:00'),
(357, 'C', 'BPN Kota Semarang', '-', 'Agung', '081226008189', '', 'Niko - 5A518BF5', 'pungkyst', '2017-11-06 08:16:45', '0000-00-00 00:00:00'),
(358, 'C', 'Perlengkapan Bayi Semarang', '-', 'Arka Atmaja', '081326044457', '', '-', 'pungkyst', '2017-11-06 08:17:56', '0000-00-00 00:00:00'),
(359, 'C', 'Bio Activa Semarang', '-', 'Arka Atmaja', '081326044457', '', '', 'pungkyst', '2017-11-06 08:18:54', '0000-00-00 00:00:00'),
(360, 'C', 'Website Resmi Kecamatan Banyu Biru', '-', 'BEM KM UDINUS', '-', '', '', 'pungkyst', '2017-11-06 08:19:57', '0000-00-00 00:00:00'),
(361, 'C', 'Lab Kes Jateng', '-', 'Arka Atmaja', '081326044457', '', '', 'pungkyst', '2017-11-06 08:21:14', '0000-00-00 00:00:00'),
(362, 'C', 'HKI UDINUS', '-', 'Rindra', '-', '', '', 'pungkyst', '2017-11-06 08:23:16', '0000-00-00 00:00:00'),
(363, 'C', 'Lia Wedding', '-', 'Daniel', '-', '', '', 'pungkyst', '2017-11-06 08:24:35', '0000-00-00 00:00:00'),
(364, 'C', 'Swadaya Digital Printing', 'Stonen', 'Fajar', '08122561676', '', '', 'pungkyst', '2017-11-06 08:25:08', '2018-02-08 09:32:28'),
(365, 'C', 'Nusantara Peduli', '-', 'Arif Eka Atmaja', '081326044457 ', '', '', 'pungkyst', '2017-11-06 08:32:43', '2018-04-26 03:41:17'),
(366, 'C', 'Maudy Wedding Organizer', '-', 'Yusuf', '085640009498', '', '', 'pungkyst', '2017-11-06 08:36:28', '0000-00-00 00:00:00'),
(367, 'C', 'Black Orchid', '-', 'Eko Gunoto', '08121075627', '', '08129059309', 'pungkyst', '2017-11-06 08:38:37', '0000-00-00 00:00:00'),
(369, 'C', 'Rental Alat Berat', '-', 'Irsyad', '08122509102', '', '085976849167', 'pungkyst', '2017-11-07 04:28:18', '0000-00-00 00:00:00'),
(370, 'C', 'Warung Halal 99', '-', 'M. Reza Tarmizi', '+628122895555', '', '', 'aant', '2017-11-09 09:11:57', '0000-00-00 00:00:00'),
(371, 'C', 'PT. RODA PASIFIK MANDIRI', 'Jl. Terboyo Industri Blok III No. 7\r\nKawasan Industri Terboyo Megah\r\nGenuk, Semarang 50112\r\nJawa Tengah - Indonesia', 'Andika Yulianto', '024 6584591', 'andi230807@gmail.com', '', 'nra', '2017-12-11 05:08:46', '0000-00-00 00:00:00'),
(372, 'C', 'SMP Insitut Indonesia', 'Jl. Taman Maluku 19 Semarang', 'Kepala', '0857-2715-0756', '', 'CP Lain : Wahyu Texmaco - +62 856-8519-684 atau Kepsek II +62 856-0028-7976', 'aant', '2018-01-26 04:24:14', '2019-01-07 02:58:33'),
(373, 'C', 'Indra Group', 'Telaga Bodas', 'Tino Indrawan', '082220111183', '', '', 'aant', '2018-02-25 03:24:30', '0000-00-00 00:00:00'),
(374, 'C', 'banyusumbergroup.com', '-', '-', '-', '', '', 'nra', '2018-03-02 06:17:54', '0000-00-00 00:00:00'),
(375, 'C', 'BPN Kabupaten Wonogiri', 'Jl. Dr. Wahidin No.1 ', 'Keuangan', '0273321027', 'atrbpnwonogiri@gmail.com', '', 'cds', '2018-03-07 02:32:34', '0000-00-00 00:00:00'),
(376, 'C', 'Triangle Production', 'Jl. Suratmo, Gisikdrono, Semarang Bar., Kota Semarang, Jawa Tengah 50147', 'Bobby Chandra Irawan', '08156565231', 'irenesandraa@gmail.com', 'Irene sebagai Humas, Bosnya Bobby', 'cds', '2018-03-19 03:39:20', '2018-05-17 06:05:43'),
(377, 'C', 'PT. Kurnia Farma Mandiri', 'Jl. Sriwijaya No. 112 Wonodri Semarang Selatan Kota Semarang', 'Bp. M. Arief Rachmat Putra, S. TP.', '08122890906', 'ariefkfm@gmail.com', '', 'cds', '2018-03-22 01:53:24', '2019-01-07 02:59:52'),
(378, 'C', 'Kedutaan Besar Republik Indonesia Malaysia', 'Kedutaan Besar Republik Indonesia Malaysia', 'Pimpinan', '-', '', '', 'cds', '2018-04-13 11:41:47', '2018-05-23 07:43:13'),
(379, 'C', 'Yayasan Wahana Bhakti Sejahtera', 'Jl. Untung Suropati', 'Dr. Budi Laksono', '+6281228017060', 'blaksono@yahoo.com', 'email : dokterbudilaksono@gmail.com', 'aant', '2018-04-14 13:44:17', '0000-00-00 00:00:00'),
(380, 'C', 'Persatuan Pelajar Indonesia Malaysia', 'Malaysia', 'Pimpinan', '+60109146119', '', '', 'nra', '2018-04-25 03:33:38', '2018-05-07 08:39:13'),
(381, 'C', 'SMK Muhammadiyah Bligo', '-', 'Kepala', '000', '', 'Arif Yunanto - 0857-4250-9672', 'aant', '2018-07-09 02:35:12', '0000-00-00 00:00:00'),
(382, 'C', 'Sumber Sejahtera', 'Jl. Pedamaran Kp. Sumeneban 157', 'Lie Linardy', '087833846788', '', '', 'cds', '2018-07-30 05:00:34', '0000-00-00 00:00:00'),
(383, 'C', 'TPG Rent Car', '-', 'A. Timur', '+6282138766686', '', '', 'aant', '2018-08-06 06:11:31', '2018-08-06 06:39:12'),
(384, 'C', 'CV. Seven Media Technology', 'Jalan Stonen Timur No. 7A, Bendan Ngisor, Gajah Mungkur', 'Mimin', '+6281234327869', 'info@sevenmediatech.com', '', 'aant', '2018-08-14 05:59:27', '2019-08-18 08:30:31'),
(385, 'C', 'PT. SIS Logistik Group Indonesia', '-', 'Soedarmono', '+628121769914', 'kaderisoedarmono@gmail.com', '', 'aant', '2018-08-16 02:19:25', '2018-08-16 02:38:11'),
(386, 'C', 'The Jawa Café Grandmedia Pandanaran', 'Jl. Pandanaran No.122, Mugassari, Semarang Sel., Kota Semarang, Jawa Tengah 50243\r\n', 'The Jawa Cafe', '+6285641042233', '', '', 'ysh', '2018-08-16 02:49:09', '2019-08-18 09:23:27'),
(387, 'C', 'Dunkin\' Donuts', 'Jalan Pandanaran 1 No.122, Pekunden, Semarang Tengah, Pekunden, Semarang Tengah, Kota Semarang, Jawa Tengah 50241\r\n', 'Dunkin\' Donuts', '+628282808816', '', '', 'ysh', '2018-08-16 02:51:06', '2019-08-18 08:30:36'),
(388, 'C', 'Dunkin\' Donuts', 'Jalan Pandanaran 1 No.122, Pekunden, Semarang Tengah, Pekunden, Semarang Tengah, Kota Semarang, Jawa Tengah 50241\r\n', 'Dunkin\' Donuts', '+628282808816', '', '', 'ysh', '2018-08-16 02:51:12', '2019-08-18 08:30:41'),
(389, 'C', 'Dunkin\' Donuts', 'Jalan Pandanaran 1 No.122, Pekunden, Semarang Tengah, Pekunden, Semarang Tengah, Kota Semarang, Jawa Tengah 50241', 'Donuts', '+628282808816', '', '', 'ysh', '2018-08-16 02:52:02', '2019-08-18 09:23:32'),
(390, 'C', 'CK Cafe', 'Jl. Pandanaran 1 No.32, Pekunden, Semarang Tengah, Kota Semarang, Jawa Tengah 50241\r\n', 'ck', '+6281390256998', '', '', 'ysh', '2018-08-16 02:53:06', '2019-08-18 08:30:46'),
(391, 'C', 'Global Elektronik', 'Jalan Pandanaran No.102, Semarang Selatan, Pekunden, Semarang Tengah, Kota Semarang, Jawa Tengah 80112\r\n', 'Elektronik ', '+628127448831', '', '', 'ysh', '2018-08-16 02:54:35', '2019-08-18 09:23:37'),
(392, 'C', 'BRUN BRUN PARIS', 'Jl. Anggrek X No.2A, Pekunden, Semarang Tengah, Kota Semarang, Jawa Tengah 50134\r\n', 'BRUN PARIS', '+6285777759312', '', '', 'ysh', '2018-08-16 02:56:24', '2019-08-18 09:23:43'),
(393, 'C', 'the cannibal bistroandbar', 'Jl Mulawarman Selatan Raya No 35B Tembalang Semarang Jawa Tengah.\r\n', 'bistroandbar', '+6282133891090', '', '', 'ysh', '2018-08-16 02:58:32', '2019-08-18 09:23:48'),
(394, 'C', 'HOC Café', 'Jl. Anggrek X No.2A, Pekunden, Semarang Tengah, Kota Semarang, Jawa Tengah 50134', 'HOC ', '+6285777759312', '', '', 'ysh', '2018-08-16 03:00:27', '2019-08-18 09:23:53'),
(395, 'C', 'Talisman Rotisserie', ' Jl. Teuku Umar No 18 Gajah Mungkur, Semarang', 'Talisman', '+6287855930795', 'basiliarestogroup@gmail.com', '', 'ysh', '2018-08-16 03:05:09', '2019-08-18 08:30:51'),
(396, 'C', 'One Press Motorcycle Repair Shop', 'Jl. Barito Utara 112, Rejosari, Semarang Tim., Kota Semarang, Jawa Tengah 50125\r\n', ' Motorcycle', '+6285102126355', '', '', 'ysh', '2018-08-16 03:06:54', '2019-08-18 09:23:58'),
(397, 'C', 'Orchid Florist Semarang', 'none', 'Orchid Florist', '+6281225225988', '', 'http://www.semarangorchidflorist.com/', 'ysh', '2018-08-16 03:08:55', '2019-08-18 09:24:03'),
(398, 'C', 'SARANA DIESEL', 'Jl. Batik No.406, Rejomulyo, Semarang Tim., Kota Semarang, Jawa Tengah 50278', 'SARANA DIESEL', '+628990010011', '', 'https://saranadiesel.business.site/', 'ysh', '2018-08-16 03:11:45', '2019-08-18 09:24:08'),
(399, 'C', 'CV Eterna Garment', 'Jl. Fatmawati No.100, Pedurungan Kidul, \r\n', 'Etena Mera', '+6285876692449', '', 'https://bengkelbubutsemarang.business.site/', 'ysh', '2018-08-16 03:14:40', '2019-08-18 09:24:13'),
(400, 'C', 'CV. Media Inovasi', 'Jl. Mangga Raya No.35, Lamper Kidul, Semarang Sel., Kota Semarang, Jawa Tengah 50262', 'Media Inovasi', '+6281805812994', '', '', 'ysh', '2018-08-16 03:18:52', '2019-08-18 09:24:18'),
(401, 'C', 'Bengkel Bubut Semarang', 'Puspowarno X / 6, Salamanmloyo, West Semarang, Semarang City, Central Java 50143', 'Bekel Bubut', '+6281327447023', '', '', 'ysh', '2018-08-16 03:20:49', '2019-08-18 08:30:56'),
(402, 'C', 'CV SARNU UNTUNG', 'Jalan R. Suprapto, Gg. Pringgodani, RT.07/RW.21, Purwodadi, Jetis Timur, Purwodadi, Kabupaten Grobogan, ', 'Sarnu Untung', '085726280111', '', '', 'ysh', '2018-08-16 03:22:47', '2019-08-18 09:24:23'),
(403, 'C', 'CV GROBOGAN BERSEMI', 'Jl. Hayam Wuruk No.74, Kwarungan, Kalongan, Purwodadi, Kabupaten Grobogan, Jawa Tengah 58114\r\n', 'GROBOGAN BERSEMI', '+6285729209190', '', '', 'ysh', '2018-08-16 03:25:36', '2019-08-18 09:24:28'),
(404, 'C', 'CV INTI BUMI', 'JL. Hayam Wuruk, No. 1 B, Kebondalem, Purwodadi, Kabupaten Grobogan, Jawa Tengah 58111\r\n', 'INTI BUMI', '+628122883688', '', '', 'ysh', '2018-08-16 03:26:56', '2019-08-18 08:31:01'),
(405, 'C', 'CV ANANTA', 'JL. R Suprapto, No. 126, Purwodadi, Purwodadigrobogan, Kabupaten Grobogan, Jawa Tengah 58111\r\n', 'CV ANANTA', '(024) 3544501', '', '(024) 3544501\r\n', 'ysh', '2018-08-16 03:29:03', '2019-08-18 09:24:34'),
(406, 'C', 'CV SETIA PRATAMA', 'Jl. Jend. A Yani No.131, Kuripan Timur, Kuripan, Purwodadi, Kabupaten Grobogan, Jawa Tengah 58111', 'CV SETIA PRATAMA', '(0292) 421675', 'SANTAAJI@YAHOO.CO.ID', '', 'ysh', '2018-08-16 03:30:15', '2019-08-18 08:31:06'),
(407, 'C', 'CV BANGKIT JAYA', 'Jalan Kartini No.12 A , Rt.3 Rw.12, Purwodadi, Kabupaten Grobogan, Jawa Tengah 58111\r\n', 'CV BANGKIT JAYA', '+6281910798690', '', '', 'ysh', '2018-08-16 03:31:36', '2019-08-18 09:24:38'),
(408, 'C', 'CV DIAN REKA CIPTA', 'Dusun Sambak, RT 003/RW 05, Purwodadi, Sambak, Danyang, Purwodadi, Kabupaten Grobogan, Jawa Tengah 58113\r\n', 'CV DIAN REKA CIPTA', '+6285293327722', '', '', 'ysh', '2018-08-16 03:32:41', '2019-08-18 09:24:43'),
(409, 'C', 'cv eterna garment', 'Jl. Fatmawati 100 Pedurungan Kidul Semarang, Jawa Tengah, Indonesia. \r\n\r\n', 'cv eterna garment', '085741275678', 'eternagarment@gmail.com', 'http://www.vendorkonveksi.com/\r\n0878 9894 4006, 0857 4127 5678', 'ysh', '2018-08-16 03:34:48', '2019-08-18 08:31:11'),
(410, 'C', 'cv jeruk', 'Jl. Jeruk IV No. 34, Lamper Lor, Semarang 50249\r\n', 'cv jeruk', '+6285225005888', 'priyadi.jrk@gmail.com', 'http://www.jerukoffset.com/\r\n0852 2500 5888\r\n(024) 8317968\r\n\r\n', 'ysh', '2018-08-16 03:36:40', '2019-08-18 08:31:16'),
(411, 'C', 'cv kembang jati funiture', 'Jl. Soekarno Hatta No. 1, Telogosari Kulon\r\n', 'cv kembang jati funiture', '+6281390840100', 'kembangdjati@gmail.com', 'http://www.kembangdjati.com/\r\n62246701677\r\n', 'ysh', '2018-08-16 03:39:03', '2019-08-18 09:24:48'),
(412, 'C', 'syauqi press', 'Kh. Tohir II No.2 Ppedurungan semrang Jawa tengah 50192\r\n', 'syauqi press', '+628122900108', 'syauqipress@gmail.com', 'http://syauqipress.com/\r\n', 'ysh', '2018-08-16 03:40:54', '2019-08-18 08:31:21'),
(413, 'C', 'cv anugrah mandiri', 'Jln. Sendangguwo Raya 39 Semarang 50191\r\n', 'cv anugrah mandiri', '+6282133144556', 'asadjienatanaek@yahoo.com', 'http://www.papan-data.com/\r\nanugrahmandiri2016@gmail.com, asadjienatanaek@yahoo.com, asadjienatanael@gmail.com', 'ysh', '2018-08-16 03:44:35', '2019-08-18 09:24:53'),
(414, 'C', 'cv lancar manunggal', 'jl puspowarno x no.6 semarang \r\n', 'cv lancar manunggal', '+6281327447023', '', 'https://bengkelbubutsemarang.business.site/', 'ysh', '2018-08-16 03:48:35', '2019-08-18 08:31:26'),
(415, 'C', 'jordan plastic', 'Jl. Industri 18 No. 420 LIK Kaligawe, Semarang\r\n', 'jordan plastic', '+6285826052526', '', 'http://jordan-plastics.com/\r\n0858 2605 2526, 0821 3812 0741', 'ysh', '2018-08-16 03:50:29', '2019-08-18 08:31:32'),
(416, 'C', 'cv maju', 'Jl. Industri VII No. 7,Kawasan Industri Terboyo Megah, Semarang Jawa Tengah\r\n', 'cv maju', '+6285713030858', 'cvmajuplastik@yahoo.co.id', 'produk-plastik.com \r\ncv.maju_plastik@yahoo.co.id', 'ysh', '2018-08-16 03:52:31', '2019-08-18 08:31:36'),
(417, 'C', 'Grand indo timber', 'Kawasan industri candi block 8c no 3 kelurahan bambankerep, ngaliyan semarang\r\n', 'Grand indo timber', '+62817241188', 'exim@grandindotimber.com', 'grandindotimber.com', 'ysh', '2018-08-16 03:54:19', '2019-08-18 09:24:58'),
(418, 'C', 'Anugrah karya abadi', 'Jl.Majapahit 571 A - Semarang\r\n', 'Anugrah karya abadi', '+6281228575707', 'admin@papandata.net', 'www.papanabadi.com\r\n081 7956 2083, 0812 2857 5707, 0857 4004 0077, 024 6700 751, \r\nadmin@papandata.net', 'ysh', '2018-08-16 03:57:56', '2019-08-18 08:31:41'),
(419, 'C', 'cv surya indah granmindo', 'kawasan industri h2 krapyak semarang', 'cv surya indah granmindo', '+628976871057', 'sales@baju--anak.com', '\r\n0821 4452 9992, 0896 5466 7963, 0897 6871 057', 'ysh', '2018-08-16 04:00:02', '2019-08-18 08:31:46'),
(420, 'C', 'karagen indonesia', 'Kawasan Industri Terboyo Blok N No. 8-9, Semarang 50118', 'karagen indonesia', '62247628231', '', 'www.karaindo.com', 'ysh', '2018-08-16 04:01:54', '2019-08-18 08:31:52'),
(421, 'C', 'Yanuar Brand', 'Gubug, Grobogan, Jateng', 'Yanuar', '+6289624426525', 'yanuarsuharyanto@gmail.com', '@yshuary', 'ysh', '2018-08-16 04:11:29', '2019-08-18 09:25:03'),
(422, 'C', ' PT Semarang Autocomp Manufacturing', 'JL. Raya Walisongo Km. 9.8, Tugurejo, Semarang, Tugurejo, Tugu, Semarang City, Central Java 50182', 'PT SAMI', '(024) 8665182', 'ABDUL_K@SAMI.CO.ID', '', 'ysh', '2018-08-16 06:16:15', '2019-08-18 09:25:08'),
(423, 'C', 'PT. semarang jaya makmur', 'Ngaliyan, Semarang City, Central Java 50181\r\n', 'PT SJM', '+628113391199', '', '', 'ysh', '2018-08-16 06:17:51', '2019-08-18 09:25:13'),
(424, 'C', 'Seven Media Technology', 'Gajah Mungkur', 'Khaerul Anwar', '+6285747747725', 'khaerul.anwar.07@gmail.com', '', 'ysh', '2018-08-23 02:57:21', '2019-08-18 09:25:18'),
(425, 'C', 'Seven Media Technology', 'Gajah Mungkur', 'Cahyo Dwi Saputro', '+6285740322375', 'cahyomyne@gmail.com', '', 'ysh', '2018-08-23 02:59:21', '2019-08-18 08:31:56'),
(426, 'C', 'Perempuan Pena', '-', 'Meyta Adelianah', '081215586433', '', '', 'aant', '2018-09-23 05:02:10', '0000-00-00 00:00:00'),
(427, 'C', 'Pesta Pelangi Party Organizer', '-', 'Ika Yuli Astari', '+6281333779471', '', '', 'aant', '2018-10-01 02:58:41', '0000-00-00 00:00:00'),
(428, 'C', 'Janur Kuning Wallpaper', '-', 'Herlambamg', '+62 812-1328-0826', '', '', 'aant', '2018-10-05 16:44:45', '0000-00-00 00:00:00'),
(429, 'C', 'Kadin', '-', 'Novi Prasetya', '-', '', '', 'aant', '2018-10-24 07:05:44', '0000-00-00 00:00:00'),
(430, 'C', 'Oase Indonesia', '-', 'Yana Sukmaya', '+6281225700025', 'info@oaseindonesia.com', '', 'aant', '2018-11-05 09:10:45', '0000-00-00 00:00:00'),
(431, 'C', 'Q Interior Semarang', '-', 'Rizky', '081228000799', '', '', 'aant', '2018-11-13 03:19:44', '0000-00-00 00:00:00'),
(432, 'C', 'SMK Texmaco Pemalang', '-', 'Majid Ibrahim, S.Pd', '-', '', '-', 'aant', '2018-12-11 02:27:54', '0000-00-00 00:00:00'),
(433, 'C', 'YPPIT Texmaco', '-', 'Kepala', '-', '', '', 'aant', '2018-12-11 02:30:55', '0000-00-00 00:00:00'),
(434, 'C', 'STT Texmaco Subang', '-', 'Kepala', '-', '', '', 'aant', '2018-12-12 01:54:35', '0000-00-00 00:00:00'),
(435, 'C', 'Sinatrya Photography', '-', 'Sinatrya', '+628985939346', '', 'ARA', 'aant', '2018-12-13 09:19:26', '0000-00-00 00:00:00'),
(436, 'C', 'Dhyanara Video', '-', 'Dhyanara Novi Paramita', '087732001055', 'dhyanaravideo@gmail.com', '', 'aant', '2018-12-14 06:06:30', '0000-00-00 00:00:00'),
(437, 'C', 'Stifinku', '-', 'Anindya Rizqi Fauziyyah', '083842332198', '', '', 'aant', '2018-12-14 16:09:16', '0000-00-00 00:00:00'),
(438, 'C', 'Sumber Bahagia', '-', 'Tommy', '-', '', '', 'aant', '2018-12-27 02:41:34', '0000-00-00 00:00:00'),
(439, 'C', 'Ikatan Guru Indonesia', '-', 'Amin Mungamar', '6285640335006', '', '', 'aant', '2019-01-02 07:15:06', '0000-00-00 00:00:00'),
(440, 'C', 'SMA Kesatrian 1 Semarang', 'Jl. Pamularsih Raya No.116, Gisikdrono, Semarang Bar., Kota Semarang, Jawa Tengah 50149', 'Kepala', '024 7601201', '', 'Tjandra - 08122556167 (Kepala Sekolah)', 'aant', '2019-01-05 16:09:32', '0000-00-00 00:00:00'),
(441, 'C', 'Tri Tjandra Mucharam', '-', 'Tri Tjandra Mucharam', '08122556167', '', '', 'aant', '2019-01-05 16:10:36', '0000-00-00 00:00:00'),
(442, 'C', 'Dinas Koperasi dan UMKM Prov. Jateng', 'Jl. Sisingamangaraja No.3A, Kaliwiru, Candisari, Kota Semarang, Jawa Tengah 50253', 'Emmy', '081554240872', '', '', 'aant', '2019-01-09 04:05:48', '0000-00-00 00:00:00'),
(443, 'C', 'Merbabu Transport', 'Krapyak', 'Rudi', '081222230367', '', 'Link dengan Mas Sinatrya dan Mas Robin', 'cds', '2019-01-15 02:38:35', '0000-00-00 00:00:00'),
(444, 'C', 'YES Indonesia', '-', 'Eko Ariwibowo', '-', '', '', 'aant', '2019-01-17 06:59:06', '0000-00-00 00:00:00'),
(445, 'C', 'Otak Atik Naskah', '-', 'Ummi', '082138552310', 'otakatiknaskah@gmail.com', '', 'aant', '2019-01-18 06:27:10', '0000-00-00 00:00:00'),
(446, 'C', 'Jidea Studio', '-', 'Muh Rizqiyawan', '-', '', '', 'aant', '2019-03-15 01:16:34', '0000-00-00 00:00:00'),
(447, 'C', 'Momplanner Indoneisa', '-', 'Anindya', '-', '', '', 'aant', '2019-03-19 10:42:48', '0000-00-00 00:00:00'),
(448, 'C', 'Keisha Art', '-', 'Nelly Anggraeni', '085640616778', '', '', 'aant', '2019-04-01 03:46:59', '0000-00-00 00:00:00'),
(449, 'C', 'Agri Business Undip', '-', 'Subhan', '-', '', '-', 'aant', '2019-04-05 07:21:47', '2019-04-08 01:59:58'),
(450, 'C', 'Dipotechnology', '-', 'Nova Nur Anisa', '-', '', '', 'aant', '2019-04-11 01:45:25', '0000-00-00 00:00:00'),
(451, 'C', 'Rumah Sunat Dr. Aria', '-', 'Aria Novianto', '-', '', '', 'aant', '2019-04-11 02:09:58', '0000-00-00 00:00:00'),
(452, 'C', 'Ayo Nandur Indonesia', '-', 'Arif Rohman', '085742177270', '', '', 'aant', '2019-05-06 06:15:56', '0000-00-00 00:00:00'),
(453, 'C', 'Ranaa Kreatif', '-', 'Fajar Riski', '-', '', '-', 'aant', '2019-05-08 22:32:15', '0000-00-00 00:00:00'),
(454, 'C', 'PT. Taman Satwa Semarang', 'Jalan Raya Semarang - Kendal Km. 17 Semarang 50155', 'PT. Taman Satwa Semarang', '-', '', '', 'cds', '2019-05-17 04:41:09', '0000-00-00 00:00:00'),
(455, 'C', 'Balai Bahasa Prov. Jawa Tengah', '-', 'Kepala', '-', '', 'Putri - +62 857-1202-0894', 'aant', '2019-05-20 04:21:00', '0000-00-00 00:00:00'),
(456, 'C', 'Kariswisata', '-', 'Karis', '+628562932003', '', '', 'aant', '2019-05-20 10:05:05', '0000-00-00 00:00:00'),
(457, 'C', 'Kusmin Antiek', '-', 'Andre', '-', '', '', 'aant', '2019-05-21 12:59:30', '0000-00-00 00:00:00'),
(458, 'C', 'Biro Hukum Provinsi Jawa Tengah', 'Jl. Pahlawan Gubernuran Provinsi Jawa Tengah', 'Anto', '08973704696', 'bagian3birohukum@gmail.com', 'Bagian Staff IT Biro Hukum Provinsi Jawa Tengah', 'cds', '2019-07-08 03:20:42', '0000-00-00 00:00:00'),
(459, 'C', 'Oceanet Indonesia', '-', 'Cahyo Tri Martanto', '-', '', 'Cahyo Tri Martanto', 'aant', '2019-07-09 05:21:01', '2019-08-28 03:29:57'),
(460, 'C', 'Jurusan Akuntansi Politeknik Negeri Semarang', '-', 'Afiat Sadida, S.Kom., MM', '+6282220164710', '', '', 'aant', '2019-07-11 04:09:23', '2019-11-07 05:46:53'),
(461, 'C', '-', '-', 'Widi', '+628122859754', '', '', 'aant', '2019-07-11 04:16:31', '2019-08-18 09:25:28'),
(462, 'C', 'SMP IT Nur Hidayah', '-', 'Kepala', '-', '', 'Pak Bangun (Waka)', 'aant', '2019-07-11 04:20:34', '2019-09-13 22:24:07'),
(463, 'C', 'Dinas Koperasi dan UMKM Kota Semarang', '-', 'Niken', '+6285726444637', '', '', 'aant', '2019-07-15 03:40:08', '2019-08-18 09:25:33'),
(464, 'C', 'Sinematechnology', '-', 'Fandhi', '+628986544018', '', '', 'aant', '2019-07-15 03:43:19', '2019-08-18 08:32:01'),
(465, 'C', 'Bimbel Airlangga College', '-', 'Yuli', '+6287751043706', '', '', 'aant', '2019-07-16 04:24:05', '2019-08-18 09:25:38'),
(466, 'C', 'Siar Records Surabaya', '-', 'Syifi', '+6285232571405', '', '', 'aant', '2019-07-21 12:35:19', '2019-08-18 08:32:06'),
(467, 'C', 'Biro Hukum SETDA Provinsi Jawa Tengah', 'Jl. Pahlawan Gedung A Lantai 5', 'Kepala Biro Hukum', '085641395537', '', '', 'cds', '2019-07-22 03:49:41', '0000-00-00 00:00:00'),
(468, 'C', '-', '-', 'Serli Anjelita', '+6281326173119', '', '', 'aant', '2019-07-24 04:13:01', '2019-08-18 08:32:11'),
(469, 'C', 'Sekolah Solo', '-', 'Yordan Adi Pratama', '+6285526369062', '', '', 'aant', '2019-07-24 04:15:04', '2019-08-18 09:25:43'),
(470, 'C', 'STIKMAH Tobelo', 'Halmahera Utara, Maluku', 'Pimpinan', '082189670470', 'philipjimmy2017@gmail.com', '', 'aant', '2019-07-30 07:59:19', '2019-08-07 15:19:39'),
(471, 'C', '-', '-', 'Pramudya', '083151581477', '', '', 'aant', '2019-07-30 08:05:09', '2019-08-18 08:32:17'),
(472, 'C', 'BNSP', '-', 'Ghodam Eko Saputro', '-', '', '', 'aant', '2019-08-07 09:23:40', '2019-08-18 08:32:21'),
(473, 'C', 'Jamur Studio', '-', 'Fadli', '-', '', '', 'aant', '2019-08-08 02:49:47', '0000-00-00 00:00:00'),
(474, 'C', 'Personal - Mba Amel Biro Hukum', 'Semarang Timur', 'Amel', '085641395537', '-@email.com', '', 'cds', '2019-08-09 04:29:33', '2019-08-18 08:32:26'),
(475, 'C', 'Madhang', 'Jakarta', 'Bayu', '085701910019', 'bayu@madhang.com', '', 'cds', '2019-08-09 04:43:08', '2019-08-18 09:25:48'),
(476, 'C', 'Telkom', '-', '-', '0816651919', '-@email.com', '', 'cds', '2019-08-09 04:45:46', '2019-08-18 09:25:53'),
(477, 'C', 'Perusahaan Wine (Alkohol)', '-', '-', '081327751123', '-@email.com', '', 'cds', '2019-08-09 07:27:30', '2019-08-18 08:32:31'),
(478, 'C', '-', '-', 'Cemmy Raharjo', '082199058736', '', '', 'aant', '2019-08-20 06:08:28', '2019-10-17 00:25:06'),
(479, 'C', 'PT. Julung Wangi', '-', 'Irpan', '081379883344', 'Irpan_syahril@yahoo.com', '', 'aant', '2019-08-26 03:30:00', '2019-10-16 22:18:08'),
(480, 'C', '-', '-', 'Yadi Alghifari', '+6281313219337', '', '', 'aant', '2019-08-27 07:38:54', '2019-10-16 22:21:15'),
(481, 'C', '?', '-', 'Des Chandra Kusuma', '081265222221', '', '', 'aant', '2019-08-29 06:32:40', '2019-10-16 22:15:12'),
(482, 'C', '?', 'Unimus', 'Pras', '08122886618', '', '', 'aant', '2019-08-29 06:33:16', '2019-10-16 22:19:25'),
(483, 'C', '?', '-', 'Edy Zarman', '+6281266891195', '', '', 'aant', '2019-09-10 03:00:21', '2019-10-16 22:16:33'),
(484, 'C', 'BPN Purworejo', '-', '-', '-', '', '-', 'aant', '2019-09-12 02:03:50', '0000-00-00 00:00:00'),
(485, 'C', '?', '-', 'Heranti Reza D', '+6285381657722', '', '', 'aant', '2019-09-17 02:12:45', '2019-10-16 22:21:30'),
(486, 'C', 'PT. Minoshima Fast Inspection', '-', 'Lela Marina', '+6287731137260', '', '', 'aant', '2019-09-17 02:14:48', '2019-10-16 22:21:20'),
(487, 'C', '?', '-', 'Hanya Maryadi', '+6281389800529', '', '', 'aant', '2019-09-17 02:19:09', '2019-10-17 00:33:36'),
(488, 'C', 'Joie Bakery', 'Jl. Siranda Wungkal', 'Joie', '+6287885638855', '', '', 'aant', '2019-09-17 02:29:53', '2019-10-16 22:21:35'),
(489, 'C', 'Dinas Pendidikan dan Kebudayaan Kab. Demak', '-', 'Pimpinan', '0', '', 'Dwi Isnaini : +62 812-2506-604, Pribadi : +62 822-2170-2225', 'aant', '2019-09-17 02:34:42', '2019-09-20 00:49:07'),
(490, 'C', '?', '-', 'Yuhyi', '+62816651919', '', '', 'aant', '2019-09-17 07:51:14', '2019-10-16 22:17:13'),
(491, 'C', 'Tata Rias Mutiara - Kebumen', '-', 'Devi', '+6282137963433', '', '', 'aant', '2019-10-01 08:48:13', '2019-10-17 00:34:07'),
(492, 'C', '?', '-', 'Jefri Alamsyah', '+6281325056308', '', '', 'aant', '2019-10-07 03:50:17', '2019-10-16 22:12:31'),
(493, 'C', '?', '-', 'Denay', '+6285640469700', '', 'Temennya Mas Apri', 'aant', '2019-10-07 03:50:55', '2019-10-16 22:20:07'),
(494, 'C', 'Edukasi Karya Indonesia', '-', 'Radityo F', '-', '', '', 'aant', '2019-10-18 14:21:02', '2019-11-16 00:36:30'),
(495, 'C', '-', '-', 'Laila DNCC', '-', '', '', 'aant', '2019-10-18 14:33:22', '2019-11-16 00:38:05'),
(496, 'C', 'Stifar Semarang', '-', 'Ririn', '-', '', '', 'aant', '2019-10-18 14:36:18', '2019-11-16 00:32:46'),
(497, 'C', 'Software House Solo', '-', 'Adi Prihannato', '-', '', '', 'aant', '2019-10-29 04:11:16', '2019-11-16 00:23:40'),
(498, 'C', 'OJK Jawa Tengah', 'Kyai Saleh', 'Bayu Ariawan', '+6285643704849', '', '', 'aant', '2019-10-29 04:11:58', '2019-11-16 00:41:56'),
(499, 'C', 'Pluie Craft', '-', 'Aditya Roosandy', '+628995551084', '', '', 'aant', '2019-10-29 04:15:34', '2019-11-16 00:18:21'),
(500, 'C', 'Bendjaart', '-', 'Bendjaart', '0895360949899', '', '', 'aant', '2019-10-29 09:03:47', '2019-11-16 00:25:16'),
(501, 'C', '?', 'Unnes\r\nPasar Tanah Abang Blok B, Lt. 2, Los G, No. 93', 'Ari', '081919868226', '', '', 'aant', '2019-10-29 09:06:29', '2019-11-16 00:15:26'),
(502, 'C', '?', '-', 'Nana - Nadya', '0895412100662', '', '', 'aant', '2019-11-03 15:49:36', '2019-11-16 00:14:21'),
(503, 'C', '?', '-', 'We Prakoso', '082231182563', '', '', 'aant', '2019-11-05 02:19:28', '2019-11-16 00:36:20'),
(504, 'C', 'Kelurahan Kedungwuni Timur', 'Jl. Raya Kedungwuni No.238, Kedungwuni Timur, Kec. Kedungwuni, Pekalongan, Jawa Tengah 51173\r\n', 'Kepala', '-', '', '', 'aant', '2019-11-05 04:16:52', '0000-00-00 00:00:00'),
(505, 'C', '?', 'Jepara', 'Upil - Aura', '-', '', '', 'aant', '2019-11-19 07:48:41', '2019-12-16 17:21:29'),
(506, 'C', 'TVKU', '-', 'Siswo', '-', '', '', 'aant', '2019-11-27 06:53:48', '2019-12-16 17:21:54'),
(507, 'C', 'Graha Teknik', 'Jl. Puri Mediterania Blog G/30, Semarang', 'Winarjo Kusnadi', '081229600038', '', '', 'aant', '2019-11-28 07:17:43', '2020-01-29 11:49:27'),
(508, 'C', 'Kopi Selatan Salatiga', '-', 'Fadly Doni', '081233660813', 'nanangarif.and@gmail.com', 'email', 'aant', '2019-12-01 09:09:14', '2019-12-16 17:21:34'),
(509, 'C', 'Pandawa LED', 'Jl. Alteri Soekarno Hatta no 66, Semarang', 'Sekarini Pitaloka', '+6288238069602', 'sekarinipitaloka07@gmail.com', '', 'aant', '2019-12-04 08:38:41', '2019-12-16 17:19:49'),
(510, 'C', '-', 'Tangerang', 'Shabrina', '+6285697776917', 'thebabyjournal.id@gmail.com', '', 'aant', '2019-12-26 09:26:30', '2020-01-23 08:57:24'),
(511, 'C', '-', 'Ungaran', 'Shofa Pratama', '+6281390518900', '', '', 'aant', '2019-12-26 09:27:47', '2020-01-22 17:38:24'),
(512, 'C', '-', 'Yogyakarta', 'Irmanda Irawati', '+6282136987715', 'Irmanda.mandanii@gmail.com', '', 'aant', '2019-12-26 09:30:39', '2020-01-23 08:50:55'),
(513, 'C', 'OJK KR3', '-', 'Tegusti Muhammad Waly', '+6281286599981', 'gustiwaly555@gmail.com', '', 'aant', '2020-01-02 07:54:08', '2020-01-21 19:11:11'),
(514, 'C', 'YPPIT Texmaco', '-', 'Pimpinan', '-', '', '-', 'aant', '2020-01-28 09:36:47', '0000-00-00 00:00:00'),
(515, 'C', 'SMK N 1 Semarang', '-', 'Kepala', '-', '', '', 'aant', '2020-01-29 06:37:12', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ms_employee`
--

CREATE TABLE `ms_employee` (
  `kdpgw_pgw` char(3) NOT NULL,
  `kdbrn_pgw` char(3) NOT NULL,
  `nama_pgw` varchar(50) NOT NULL,
  `almat_pgw` mediumtext NOT NULL,
  `nohp_pgw` varchar(30) NOT NULL,
  `email_pgw` varchar(30) NOT NULL,
  `tgllahir_pgw` date NOT NULL,
  `dateentry_pgw` date NOT NULL,
  `status_pgw` char(1) NOT NULL,
  `level_pgw` char(2) NOT NULL,
  `foto_pgw` char(37) DEFAULT NULL,
  `intern_pgw` int(11) NOT NULL DEFAULT 1,
  `kontawal_pgw` date DEFAULT NULL,
  `kontakhir_pgw` date DEFAULT NULL,
  `kontnum_pgw` int(1) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_employee`
--

INSERT INTO `ms_employee` (`kdpgw_pgw`, `kdbrn_pgw`, `nama_pgw`, `almat_pgw`, `nohp_pgw`, `email_pgw`, `tgllahir_pgw`, `dateentry_pgw`, `status_pgw`, `level_pgw`, `foto_pgw`, `intern_pgw`, `kontawal_pgw`, `kontakhir_pgw`, `kontnum_pgw`, `create_at`, `update_at`) VALUES
('AAN', 'SMG', 'A. Khaerul Anwar, S.Kom', 'Kalikangkung RT 01 RW 01, Gondoriyo, Ngaliyan, Semarang', '085747747725', 'khaerul@sevenmediatech.com', '1993-06-10', '2013-06-23', '1', '01', '6025abe535eef78ca5d94d0f5bd10e37.JPG', 0, '0000-00-00', '0000-00-00', 0, '2017-07-13 21:06:41', '2019-11-07 12:47:18'),
('AHY', 'SMG', 'Ahmad Yusuf Abdillah', '-', '081225808585', 'ahmadyusuf.sj@gmail.com', '1999-05-27', '2019-07-05', '1', '05', '804389f9cf26397f69c441f8926f7f17.jpg', 0, '0000-00-00', '0000-00-00', 0, '2019-07-05 01:59:18', '2019-07-05 08:59:33'),
('ARD', 'SMG', 'Ardika Santosa', 'Ds.Kelet 03/01, Keling, Jepara, Jawa Tengah, Indonesia', '085868192422', 'sardika4@gmail.com', '1999-08-17', '2018-03-12', '1', '08', '1559d92daa9bac5b06f607cce81b06ea.jpg', 0, '2019-02-04', '2019-10-31', 2, '2018-03-12 08:48:04', '2019-04-16 09:50:29'),
('ATH', 'SMG', 'MUHAMMAD ATHO\'IL MAULA', 'Jl. Karya Bhakti no. 130 Medono Pekalongan', '085642766247', 'athoil286@gmail.com', '0000-00-00', '2018-02-07', '0', '05', 'cf40fb2ff99f0bb4d7fe94054b71fa25.png', 1, '2018-11-01', '2019-10-31', 2, '2018-02-07 02:01:29', '2019-10-01 14:39:46'),
('CDS', 'SMG', 'Cahyo Dwi Saputro, S.Kom', 'Jl. Palagan no.19 Sumowono Kab.Semarang', '085740322375', 'cahyo@sevenmediatech.com', '1992-12-12', '2013-06-23', '0', '02', NULL, 1, '0000-00-00', '0000-00-00', 0, '2017-07-13 14:11:54', '2019-10-21 08:50:08'),
('FMZ', 'SMG', 'Fatkhul Majid Zubizarreta', '-', '01', 'fatkhul@sevenmediatech.co.id', '0000-00-00', '2020-02-03', '1', '05', NULL, 0, NULL, NULL, 0, '2020-02-03 06:31:17', '2020-02-03 13:31:17'),
('FNM', 'SMG', 'Fadhil Nur Mahardi', '-', '08989701439', 'fadhil@sevenmediatech.com', '0000-00-00', '2015-05-01', '0', '05', '19deaf4fd4d79b7e0cb5ecd2df127734.jpg', 1, '0000-00-00', '0000-00-00', 0, '2017-07-13 14:11:35', '2019-08-12 08:52:12'),
('HMM', 'SMG', 'Hamimah', 'Wahyu Kos, Jl. Cempakasari 3, Sekaran ', '082120162498', 'hamimahbachdim00@gmail.com', '1997-03-01', '2019-07-01', '1', '09', '3cb2c73ad34e2b4cc5394ac4f79e0fe3.jpg', 0, '0000-00-00', '0000-00-00', 0, '2019-07-01 02:00:38', '2019-07-01 09:01:05'),
('KRM', 'SMG', 'Karisma Putri Miranti', 'Brebes', '085759260983', 'rismrismaaa@gmail.com', '0000-00-00', '2018-07-02', '0', '09', NULL, 1, '2019-04-01', '2020-03-31', 1, '2018-06-29 03:27:51', '2019-07-01 08:56:18'),
('MBS', 'SMG', 'Maulana Bayu Samudro', '-', '085701910019', 'bayu@sevenmediatech.com', '0000-00-00', '2015-12-01', '0', '05', 'ea7ffb4d193969036148322aa925be01.jpg', 1, NULL, NULL, 0, '2017-07-13 21:14:02', '2018-06-29 16:55:16'),
('MHI', 'SMG', 'Muhammad Helmi Ilman Fakhmi', 'Tegal', '085842031357', 'helmiathaya@gmail.com', '0000-00-00', '2017-11-08', '0', '05', '7d0655e2e70a13baaa9eee1b05a71695.jpg', 1, '2018-08-01', '2019-07-31', 2, '2017-11-16 07:11:11', '2019-06-27 12:37:21'),
('MIL', 'SMG', 'Mila Kistiana', 'Jl. Sidorejo RT 07 RW VII Kel. Sambirejo', '0855-2625-1959', 'milakistiana@email.com', '0000-00-00', '2019-10-01', '0', '05', NULL, 1, '0000-00-00', '0000-00-00', 0, '2019-10-01 07:39:16', '2020-01-24 10:01:37'),
('NRA', 'SMG', 'Nindy Riska Amalia', 'Purwokerto', '085647787774', 'nindyriskaamalia@gmail.com', '0000-00-00', '2017-12-04', '0', '06', '850d6e9fd537a01ef18aada982632e9e.jpg', 1, NULL, NULL, 0, '2017-12-04 01:51:13', '2018-08-28 15:57:19'),
('PUN', 'SMG', 'Pungky Septiana Tirajani, S.Kom', '-', '085799979396', 'pungky@sevenmediatech.com', '0000-00-00', '2017-02-01', '0', '06', NULL, 1, NULL, NULL, 0, '2017-07-13 14:12:32', '2018-06-29 16:55:34'),
('ROB', 'SMG', 'Robby Birham', 'Talunkacang RT 05 RW 03 , Kelurahan Kandri, Kecamatan Gunungpati, Kota Semarang', '087700551716', 'robby@sevenmediatech.com', '1999-05-31', '2017-08-01', '2', '05', '187d531f7f646a2abcbe036d2ae01b7d.png', 0, '2018-07-02', '2019-06-30', 1, '2017-07-13 21:14:25', '2019-10-01 14:34:08'),
('YSH', 'SMG', 'Yanuar Suharyanto', 'Ds Kemiri Kec Gubug Kab Grobogan', '089624426525', 'yanuar@sevenmediatech.com', '0000-00-00', '2018-07-16', '0', '07', NULL, 1, NULL, NULL, 0, '2018-07-16 01:39:27', '2018-11-01 13:14:46');

-- --------------------------------------------------------

--
-- Table structure for table `ms_kpi`
--

CREATE TABLE `ms_kpi` (
  `id_kpi` int(11) NOT NULL,
  `jbt_kpi` char(2) NOT NULL,
  `ind_kpi` varchar(40) NOT NULL,
  `stn_kpi` varchar(10) NOT NULL,
  `skr_kpi` double NOT NULL,
  `tme_kpi` int(11) NOT NULL,
  `tgt_kpi` int(11) NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_kpi`
--

INSERT INTO `ms_kpi` (`id_kpi`, `jbt_kpi`, `ind_kpi`, `stn_kpi`, `skr_kpi`, `tme_kpi`, `tgt_kpi`, `create_at`, `update_at`) VALUES
(2, '05', 'DPPL : Pendahuluan  per Apps/Sistem', 'apps/siste', 3, 30, 6, '2018-07-13 11:24:41', '2018-07-30 18:30:06'),
(4, '05', 'DPPL : RLI dan CD  per Apps/Sistem', 'apps/siste', 3, 30, 6, '2018-07-27 17:31:01', '2018-07-27 18:52:40'),
(5, '05', 'DPPL : Flowchart  per Apps/Sistem', 'apps/siste', 12, 120, 24, '2018-07-30 14:28:51', '2018-07-30 14:28:51'),
(6, '05', 'DPPL : ERD  per Apps/Sistem', 'apps/siste', 9, 90, 18, '2018-07-30 14:29:35', '2018-07-30 14:29:35'),
(7, '05', 'DPPL : Struktur Module  per Apps/Sistem', 'app/sistem', 3, 30, 6, '2018-07-30 14:32:10', '2018-07-30 14:32:10'),
(8, '08', 'DPPL : Mockup per Apps/Sistem', 'apps/siste', 24, 240, 168, '2018-07-30 14:33:01', '2018-07-30 14:33:01'),
(9, '05', '(MSD) Master Data', 'module', 1, 10, 20, '2018-07-30 14:35:11', '2018-07-30 14:47:38'),
(10, '05', '(RPT) Reporting', 'module', 4.5, 40, 90, '2018-07-30 14:36:52', '2018-07-30 14:47:16'),
(11, '05', '(MDL) Main Module', 'module', 15, 150, 450, '2018-07-30 14:41:37', '2018-07-30 14:46:16'),
(12, '08', '(DIF) Desain Antarmuka Web - Standar', 'interface', 1, 10, 25, '2018-07-30 14:42:57', '2018-07-30 14:42:57'),
(13, '08', '(DIF) Desain Antarmuka Web - Custom', 'interface', 6, 60, 150, '2018-07-30 14:44:07', '2018-07-30 14:45:50'),
(14, '08', '(CNT) Finishing Content', 'web', 24, 240, 120, '2018-07-30 14:45:12', '2018-07-30 14:45:12'),
(15, '09', '(DSN) Desain (Ucapan, Portoflio)', 'desain', 1.5, 15, 15, '2018-07-30 14:49:37', '2018-07-30 14:49:37'),
(16, '09', '(DSN) Desain Artikel', 'desain', 3, 30, 60, '2018-07-30 14:51:38', '2018-07-30 14:51:38'),
(17, '09', '(DSN) Plan & Create Content', 'desain', 6, 60, 120, '2018-07-30 14:52:49', '2018-07-30 14:52:49'),
(18, '09', '(MTR) Monitoring Performa Socmed dan Web', 'event', 6, 60, 24, '2018-07-30 14:53:39', '2018-07-30 14:53:39'),
(19, '09', '(PSC) Posting Content', 'post', 3, 30, 60, '2018-07-30 14:54:30', '2018-07-30 14:54:30'),
(20, '00', '(MNC) Revisi Medium', 'module', 30, 30, 10, '2018-08-02 13:16:21', '2019-04-11 10:27:29'),
(21, '00', '(MNB) Manual Book', 'apps/siste', 12, 120, 24, '2018-08-06 11:45:17', '2019-04-11 10:24:36'),
(23, '00', '(MRPT) Manager Report', 'Report', 80, 120, 4, '2018-10-11 10:46:36', '2019-04-11 10:21:40'),
(24, '00', '(MJB) Pekerjaan Manager Umum', 'entertainm', 50, 120, 1, '2018-10-11 10:50:01', '2019-04-11 10:26:43'),
(26, '00', '(SOP) Standar Operasional Produksi', 'lesson', 70, 120, 4, '2018-10-11 10:55:57', '2019-04-11 10:30:39'),
(29, '00', '(MNC) Revisi Ringan', 'Modul', 10, 15, 10, '2018-11-08 10:41:43', '2019-04-11 10:27:43'),
(31, '00', '(MNC) Revisi Berat', 'Modul', 60, 60, 5, '2018-11-08 10:42:42', '2019-04-11 10:25:16'),
(32, '00', '(DIF) Konsep Frontend', 'konsep', 20, 60, 2, '2018-11-08 10:44:17', '2019-04-11 10:29:09'),
(33, '00', 'Rapat (Evaluasi dan Koordinasi)', 'koordinasi', 50, 120, 3, '2018-11-08 10:46:00', '2018-11-08 10:46:00'),
(34, '04', 'Accounting', 'report', 0, 0, 0, '2018-12-03 00:00:00', '2019-11-01 09:11:54'),
(35, '04', 'Head of Finance', 'event', 0, 0, 0, '2018-12-03 00:00:00', '2019-11-01 09:27:21'),
(36, '00', 'Marketing Umum', '0', 0, 0, 0, '2018-12-04 09:54:04', '2019-07-04 15:00:44'),
(37, '01', 'Public Relation', '0', 0, 0, 0, '2018-12-05 10:38:11', '2018-12-05 10:38:11'),
(38, '01', 'Optimasi/Ads Marketing', '0', 0, 0, 0, '2018-12-07 10:54:54', '2018-12-07 10:54:54'),
(39, '00', '(RU) Research Umum', '0', 0, 0, 0, '2018-12-10 16:51:59', '2019-04-11 10:24:14'),
(40, '00', '(ADM) Administrasi Umum', '0', 0, 0, 0, '2018-12-13 10:59:27', '2019-04-11 10:31:29'),
(41, '00', 'Projek Umum', '0', 0, 0, 0, '2018-12-17 09:38:12', '2018-12-17 09:38:12'),
(42, '09', 'Create, Design & Post Content', '', 0, 120, 50, '2019-01-31 13:23:42', '2019-01-31 13:23:42'),
(43, '09', 'Planning Content Bulanan', 'item', 0, 150, 3, '2019-01-31 13:26:19', '2019-01-31 13:26:19'),
(44, '00', '(DIF) Template Ara', 'template', 10, 240, 8, '2019-02-01 08:56:04', '2019-04-11 10:29:22'),
(45, '00', '(PSN) Belajar Magang ', 'pertemuan', 50, 120, 4, '2019-04-18 10:08:04', '2019-04-18 10:08:04'),
(46, '00', 'Mar : Gali Requirements Klien', 'kali', 0, 0, 5, '2019-07-04 15:02:07', '2019-07-04 15:04:02'),
(47, '07', 'Mar : Buat Penawaran', 'Kali', 0, 0, 5, '2019-07-04 15:02:59', '2019-07-04 15:02:59'),
(48, '07', 'Mar : Negosiasi Penawaran', 'kali', 0, 0, 5, '2019-07-04 15:03:30', '2019-07-04 15:03:30'),
(49, '07', 'Mar : Pengajuan Penawaran Produk', 'kali', 0, 0, 10, '2019-07-04 15:04:23', '2019-07-04 15:04:23'),
(50, '04', 'Tax', 'Times', 0, 0, 0, '2019-07-22 14:19:01', '2019-07-22 14:19:01'),
(51, '00', 'Testing', '1', 1, 120, 4, '2019-09-05 08:54:37', '2019-09-05 08:54:37'),
(52, '05', 'Database', 'Package', 0, 0, 0, '2020-01-06 14:00:12', '2020-01-06 14:00:12');

-- --------------------------------------------------------

--
-- Table structure for table `ms_pos`
--

CREATE TABLE `ms_pos` (
  `kdpos_pos` char(6) NOT NULL,
  `nama_pos` varchar(30) NOT NULL,
  `anggr_pos` double NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_pos`
--

INSERT INTO `ms_pos` (`kdpos_pos`, `nama_pos`, `anggr_pos`, `create_at`, `update_at`) VALUES
('O-02-A', 'Biaya Gaji Direktur', 108000000, '2017-07-20 16:43:12', '2017-09-22 23:34:44'),
('O-02-C', 'Biaya Pemasaran', 6000000, '2017-07-20 16:43:55', '2017-09-22 23:35:01'),
('O', 'Pengeluaran', 0, '2017-07-20 16:46:20', '2017-07-20 23:46:20'),
('E', 'Modal', 0, '2017-07-21 03:25:41', '2017-07-21 10:25:41'),
('E-01', 'Modal Awal', 0, '2017-07-21 03:25:58', '2017-07-21 10:25:58'),
('O-02-E', 'Biaya Rumah Tangga', 7800000, '2017-07-21 03:29:37', '2017-09-22 23:35:18'),
('O-01', 'Beban Produksi', 6000000, '2017-07-21 03:29:53', '2017-09-22 23:35:31'),
('O-02-G', 'Biaya Sosial', 4800000, '2017-07-21 03:32:09', '2017-09-22 23:35:46'),
('O-02-I', 'Bonus', 50000000, '2017-07-21 03:32:23', '2017-09-22 23:36:00'),
('O-02-J', 'Pajak', 5000000, '2017-07-21 03:32:38', '2017-09-22 23:36:26'),
('O-02-F', 'Biaya Inventaris', 20000000, '2017-07-21 03:32:59', '2017-09-22 23:36:40'),
('I', 'Pendapatan', 0, '2017-07-21 03:34:31', '2017-07-21 10:34:31'),
('I-01', 'Penjualan', 0, '2017-07-21 03:34:40', '2017-07-21 10:34:40'),
('I-01-A', 'Penjualan Website', 0, '2017-07-21 03:34:54', '2017-07-21 10:34:54'),
('I-01-B', 'Penjualan Sistem Informasi', 0, '2017-07-21 03:35:05', '2017-07-21 10:35:05'),
('I-01-C', 'Pengelolaan Digital Marketing', 0, '2017-07-21 03:35:18', '2017-07-21 10:35:18'),
('I-02', 'Pendapatan di Luar Usaha', 0, '2017-07-21 03:35:32', '2017-07-21 10:35:32'),
('I-01-D', 'Penjualan Lain', 0, '2018-01-02 03:15:02', '0000-00-00 00:00:00'),
('O-02-H', 'Biaya Entertaint', 8000000, '2017-07-25 07:29:49', '2017-09-22 23:37:12'),
('O-02-K', 'Lain-lain', 1000000, '2017-09-22 16:37:41', '2017-09-22 23:37:41'),
('B', 'Piutang', 0, '2017-12-14 19:47:59', '0000-00-00 00:00:00'),
('I-02-A', 'Bunga Bank', 0, '2018-01-02 03:16:21', '2018-01-02 00:00:00'),
('I-02-B', 'Pendapatan Lain-lain', 0, '2018-01-02 03:16:21', '2018-01-02 00:00:00'),
('O-01-A', 'Sewa Domain', 0, '2018-01-02 03:24:26', '0000-00-00 00:00:00'),
('O-01-B', 'Sewa Hosting', 0, '2018-01-02 03:24:26', '0000-00-00 00:00:00'),
('O-01-C', 'Sewa VPS', 0, '2018-01-02 03:24:38', '0000-00-00 00:00:00'),
('O-02-B', 'Gaji Karyawan', 0, '2018-01-02 03:35:00', '0000-00-00 00:00:00'),
('O-02-D', 'Biaya ATK', 0, '2018-01-02 03:40:54', '0000-00-00 00:00:00'),
('O-03', 'Prive', 0, '2018-01-02 03:47:48', '0000-00-00 00:00:00'),
('O-02', 'Beban Operasional', 0, '2018-01-02 08:06:04', '0000-00-00 00:00:00'),
('O-01-D', 'Belanja Produksi Lainnya', 0, '2018-04-21 11:47:24', '2018-04-21 18:47:24'),
('I-01-E', 'Penjualan Araweb', 0, '2018-12-13 09:23:41', '2018-12-13 16:23:41');

-- --------------------------------------------------------

--
-- Table structure for table `ms_rekening`
--

CREATE TABLE `ms_rekening` (
  `idrek_rek` tinyint(4) NOT NULL,
  `kdbrn_rek` char(3) NOT NULL,
  `nama_rek` varchar(50) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_rekening`
--

INSERT INTO `ms_rekening` (`idrek_rek`, `kdbrn_rek`, `nama_rek`, `create_at`, `update_at`) VALUES
(6, 'SMG', 'Kas Besar', '2017-07-24 07:06:24', '2017-11-29 12:29:32'),
(7, 'SMG', 'BPD JTG - 1.099.001301', '2017-07-24 07:16:19', '2017-11-30 06:09:57'),
(8, 'SMG', 'MANDIRI - 136.00.1075909.7', '2017-07-24 07:16:19', '2017-11-30 06:09:46'),
(9, 'SMG', 'BRI - 1452.01.003333.50.7', '2017-07-24 07:16:35', '2017-07-24 00:00:00'),
(10, 'SMG', 'Kas Kecil', '2017-11-29 05:29:41', '2017-11-29 12:29:41');

-- --------------------------------------------------------

--
-- Table structure for table `ms_services`
--

CREATE TABLE `ms_services` (
  `idsrv_srv` int(11) NOT NULL,
  `code_srv` char(1) NOT NULL,
  `nama_srv` varchar(200) NOT NULL,
  `desc_srv` text NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_services`
--

INSERT INTO `ms_services` (`idsrv_srv`, `code_srv`, `nama_srv`, `desc_srv`, `create_at`, `update_at`) VALUES
(1, 'U', 'Website', '', '2019-08-08 06:53:39', '2019-08-02 00:00:00'),
(2, 'U', 'Sistem Informasi Akademik', '', '2019-08-08 06:53:41', '2019-08-02 00:00:00'),
(3, 'U', 'ERP', '', '2019-08-08 06:53:43', '2019-08-02 00:00:00'),
(4, 'A', 'Araweb', '', '2019-08-08 07:59:34', '2019-08-02 00:00:00'),
(5, 'U', 'Maintenance', '', '2019-08-08 06:53:54', '2019-08-02 00:00:00'),
(6, 'D', 'Domain', '', '2019-08-08 06:53:30', '2019-08-02 00:00:00'),
(7, 'H', 'Hosting', '', '2019-08-08 06:53:27', '2019-08-02 00:00:00'),
(99, 'U', 'Lainnya', '', '2019-08-08 07:24:35', '2019-08-02 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ms_servicesdetail`
--

CREATE TABLE `ms_servicesdetail` (
  `idsrd_srd` int(11) NOT NULL,
  `idsrv_srd` int(11) NOT NULL,
  `nama_srd` varchar(100) NOT NULL,
  `desc_srd` text NOT NULL,
  `price_srd` double NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_servicesdetail`
--

INSERT INTO `ms_servicesdetail` (`idsrd_srd`, `idsrv_srd`, `nama_srd`, `desc_srd`, `price_srd`, `create_at`, `update_at`) VALUES
(1, 4, 'Paket Starter', '', 149000, '2019-08-02 10:01:15', '2019-08-02 00:00:00'),
(2, 4, 'Paket Basic', '', 349000, '2019-08-02 10:01:15', '2019-08-02 00:00:00'),
(3, 4, 'Paket Pro', '', 849000, '2019-08-02 10:01:53', '2019-08-02 00:00:00'),
(4, 4, 'Paket Ultimate', '', 1499000, '2019-08-02 10:01:53', '2019-08-02 00:00:00'),
(5, 7, 'Hosting SM-Small', 'Kapasitas 250MB', 200000, '2019-08-02 10:03:55', '2019-08-02 00:00:00'),
(6, 7, 'Hosting SM-Medium', 'Kapasitas 500MB', 300000, '2019-08-02 10:03:55', '2019-08-02 00:00:00'),
(7, 7, 'Hosting SM-Large', 'Kapasitas 1GB', 450000, '2019-08-02 10:04:37', '2019-08-02 00:00:00'),
(8, 7, 'Hosting SM-Extra Large', 'Kapasitas 2GB', 675000, '2019-08-02 10:04:37', '2019-08-02 00:00:00'),
(9, 7, 'Hosting SM-XXLarge', 'Kapasitas 4GB', 1012500, '2019-08-02 10:19:12', '2019-08-02 00:00:00'),
(10, 6, '.com', '', 137500, '2019-08-09 03:23:24', '0000-00-00 00:00:00'),
(11, 6, '.id', '', 275000, '2019-08-09 03:23:24', '0000-00-00 00:00:00'),
(12, 6, 'co.id', '', 0, '2019-08-14 07:41:39', '0000-00-00 00:00:00'),
(13, 6, 'sch.id', '', 0, '2019-08-14 07:41:39', '0000-00-00 00:00:00'),
(14, 6, 'net', '', 0, '2019-08-14 07:42:09', '0000-00-00 00:00:00'),
(15, 6, 'ac.id', '', 0, '2019-08-14 07:42:09', '0000-00-00 00:00:00'),
(16, 6, 'co', '', 0, '2019-08-14 07:43:12', '0000-00-00 00:00:00'),
(17, 6, 'org', '', 0, '2019-08-14 07:43:12', '0000-00-00 00:00:00'),
(18, 7, 'RW-PRO250', '', 0, '2019-08-14 07:51:40', '0000-00-00 00:00:00'),
(19, 7, 'RW-PRO500', '', 0, '2019-08-14 07:51:40', '0000-00-00 00:00:00'),
(20, 7, 'RW-PRO1GB', '', 0, '2019-08-14 07:51:40', '0000-00-00 00:00:00'),
(21, 7, 'RW-PRO2GB', '', 0, '2019-08-14 07:51:40', '0000-00-00 00:00:00'),
(22, 7, 'Hosting Mandiri', '', 0, '2019-08-14 09:03:56', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ms_supplier`
--

CREATE TABLE `ms_supplier` (
  `idsup_sup` int(11) NOT NULL,
  `nma_sup` varchar(30) NOT NULL,
  `alm_sup` varchar(50) NOT NULL,
  `tlp_sup` varchar(15) NOT NULL,
  `email_sup` varchar(20) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_supplier`
--

INSERT INTO `ms_supplier` (`idsup_sup`, `nma_sup`, `alm_sup`, `tlp_sup`, `email_sup`, `create_at`, `update_at`) VALUES
(2, 'Matahari', 'Simpang Lima Semarang (Pandanaran Pahlawan)', '', '', '2019-04-16 06:19:20', '2019-04-16 13:26:43'),
(3, 'Queen Meubel', 'Ruko Semarang Indah', '', '', '2019-04-16 06:30:18', '2019-04-16 13:30:18'),
(4, 'Java Mall', 'Peterongan', '', '', '2019-04-18 02:00:34', '2019-04-18 09:00:34'),
(5, 'Merbabu Toko Buku', 'Jl. Pandanaran Semarang', '', '', '2019-04-18 02:00:58', '2019-04-18 09:01:10'),
(6, 'Ruko Ngalian', 'Ngalian', '', '', '2019-04-18 02:01:36', '2019-04-18 09:01:36'),
(7, 'Toko Ada', 'Siliwangi. Semarang', '', '', '2019-04-18 02:02:01', '2019-04-18 09:02:01'),
(8, 'Digimax', 'Jl. Sriwijaya Semarang', '', '', '2019-04-18 02:02:39', '2019-04-18 09:02:39'),
(9, 'OLX', 'www.olx.com', '', '', '2019-04-18 02:03:12', '2019-04-18 09:03:12'),
(10, 'Pasar Sampangan', 'Sampangan, Semarang', '', '', '2019-04-18 02:03:38', '2019-04-18 09:03:38'),
(11, 'Smartfren', 'Kaligarang', '', '', '2019-04-18 02:04:03', '2019-04-18 09:04:03'),
(12, 'Tukang Kayu Banjirkanal', 'Banjir Kanal', '', '', '2019-04-18 02:04:29', '2019-04-18 09:04:29'),
(13, 'Jakarta Notebook', 'Jl. Sriwijaya, Semarang', '', '', '2019-04-18 02:05:04', '2019-04-18 09:05:04'),
(14, 'Ruko Pandanaran', 'Pandanaran', '', '', '2019-04-18 02:51:34', '2019-04-18 09:51:34'),
(15, 'Kursi Banowati', 'Banowati ', '085101878953', 'email@email.com', '2019-07-04 07:03:06', '2019-07-04 14:03:06');

-- --------------------------------------------------------

--
-- Table structure for table `ms_tasktype`
--

CREATE TABLE `ms_tasktype` (
  `id_tasktpe` int(11) NOT NULL,
  `nama_tasktpe` varchar(20) NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_tasktype`
--

INSERT INTO `ms_tasktype` (`id_tasktpe`, `nama_tasktpe`, `create_at`, `update_at`) VALUES
(1, 'Research', '2018-05-31 11:46:40', '2018-05-31 11:46:40'),
(2, 'HRD', '2018-07-27 16:35:59', '2018-07-27 16:35:59'),
(3, 'Finance', '2018-07-27 16:36:06', '2018-07-27 16:36:06'),
(4, 'Rumah Tangga', '2018-07-27 16:36:14', '2018-07-27 16:36:14'),
(5, 'Creative Content', '2018-07-27 16:37:07', '2018-07-27 16:37:07'),
(6, 'Marketing', '2018-07-27 16:37:25', '2018-07-27 16:37:25'),
(7, 'Creative Team', '2018-10-11 12:26:06', '2018-10-11 12:26:06'),
(8, 'Administrasi', '2018-12-13 10:59:07', '2018-12-13 10:59:07'),
(9, 'Management', '2019-11-03 22:37:59', '2019-11-03 22:37:59');

-- --------------------------------------------------------

--
-- Table structure for table `ms_user`
--

CREATE TABLE `ms_user` (
  `usrpw_usr` varchar(20) NOT NULL,
  `paspw_usr` char(32) NOT NULL,
  `kdpgw_usr` char(3) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ms_user`
--

INSERT INTO `ms_user` (`usrpw_usr`, `paspw_usr`, `kdpgw_usr`, `create_at`, `update_at`) VALUES
('aant', '34465c4ee5148b8ed01980ff84cde957', 'AAN', '2017-06-28 22:13:25', '2017-06-29 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_advice`
--

CREATE TABLE `tb_advice` (
  `id_adv` int(11) NOT NULL,
  `idtsktpe_adv` int(11) NOT NULL,
  `nama_adv` varchar(200) NOT NULL,
  `tgl_adv` date NOT NULL,
  `sol_adv` varchar(40) NOT NULL,
  `tglsol_adv` date NOT NULL,
  `kdpgw_adv` char(3) NOT NULL,
  `type_adv` char(1) NOT NULL,
  `rate_adv` int(11) NOT NULL,
  `update_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_aset`
--

CREATE TABLE `tb_aset` (
  `kd_ast` varchar(7) DEFAULT NULL,
  `id_ast` int(11) NOT NULL,
  `idastpe_ast` int(11) NOT NULL,
  `nma_ast` varchar(24) DEFAULT NULL,
  `spec_ast` varchar(32) DEFAULT NULL,
  `tgl_ast` date DEFAULT NULL,
  `jml_ast` int(3) DEFAULT NULL,
  `price_ast` int(11) DEFAULT NULL,
  `ket_ast` varchar(50) NOT NULL,
  `idsup_ast` int(11) NOT NULL,
  `dep_ast` int(11) NOT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tb_bon`
--

CREATE TABLE `tb_bon` (
  `idbon_bon` int(11) NOT NULL,
  `kdpgw_bon` char(3) NOT NULL,
  `nilai_bon` double NOT NULL,
  `date_bon` date NOT NULL,
  `keter_bon` mediumtext NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_cekmasuk`
--

CREATE TABLE `tb_cekmasuk` (
  `id_cek` int(11) NOT NULL,
  `kdpgw_cek` char(3) NOT NULL,
  `ismsk_cek` enum('ya','tidak') NOT NULL,
  `tugas_cek` enum('kantor','luar') DEFAULT NULL,
  `jmmsk_cek` time NOT NULL,
  `jmklr_cek` time NOT NULL,
  `alasn_cek` text NOT NULL,
  `tnggl_cek` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_clientgroup`
--

CREATE TABLE `tb_clientgroup` (
  `id` int(11) NOT NULL,
  `name_group` varchar(100) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_clientgroup`
--

INSERT INTO `tb_clientgroup` (`id`, `name_group`, `create_at`, `update_at`) VALUES
(1, 'UMKM Database', '2018-08-14 06:44:21', '2018-08-21 08:38:56'),
(3, 'SMK Database', '2018-08-14 06:53:35', '2018-08-21 08:39:14'),
(4, 'SD Database', '2018-08-21 07:56:38', '2018-08-21 08:38:09'),
(5, 'SMP Database', '2018-08-21 08:34:37', '2018-08-21 08:37:54'),
(6, 'Uji Coba', '2018-08-23 07:17:24', '2018-08-23 07:17:24');

-- --------------------------------------------------------

--
-- Table structure for table `tb_invoice`
--

CREATE TABLE `tb_invoice` (
  `idinv_inv` int(11) NOT NULL,
  `idprj_inv` int(11) NOT NULL,
  `tnggl_inv` date NOT NULL,
  `price_inv` double NOT NULL,
  `stats_inv` char(1) NOT NULL DEFAULT 'U',
  `stdate_inv` date NOT NULL,
  `usrpw_inv` varchar(10) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_invoicedetail`
--

CREATE TABLE `tb_invoicedetail` (
  `iddtl` int(11) NOT NULL,
  `idinv_inv` int(11) NOT NULL,
  `name_inv` varchar(100) NOT NULL,
  `price_inv` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_logs`
--

CREATE TABLE `tb_logs` (
  `id_logs` int(11) NOT NULL,
  `id_user_logs` varchar(50) DEFAULT NULL,
  `ip_logs` varchar(20) NOT NULL,
  `browser_logs` varchar(50) NOT NULL,
  `os_logs` varchar(50) NOT NULL,
  `aktivitas_logs` text NOT NULL,
  `time_logs` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_logs`
--

INSERT INTO `tb_logs` (`id_logs`, `id_user_logs`, `ip_logs`, `browser_logs`, `os_logs`, `aktivitas_logs`, `time_logs`) VALUES
(1, '', '::1', 'Chrome', 'Mac OS X', 'Mencoba masuk ke Sistem dengan username <b>abclimadasar</b>', '2020-02-10 10:17:12'),
(2, 'aant', '::1', 'Chrome', 'Mac OS X', 'Berhasil Masuk ke Sistem', '2020-02-10 10:17:24'),
(3, 'aant', '::1', 'Chrome', 'Mac OS X', 'Berhasil Masuk ke Sistem', '2020-02-10 10:20:42');

-- --------------------------------------------------------

--
-- Table structure for table `tb_magang`
--

CREATE TABLE `tb_magang` (
  `id_mgg` int(10) NOT NULL,
  `nomor_magang` varchar(40) NOT NULL,
  `instansi` varchar(50) NOT NULL,
  `per_dari` date NOT NULL,
  `per_sampai` date NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_projectdeadhistory`
--

CREATE TABLE `tb_projectdeadhistory` (
  `idprotask_pdh` int(11) NOT NULL,
  `reason_pdh` text NOT NULL,
  `deadline_pdh` datetime NOT NULL,
  `create_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_projectrtask`
--

CREATE TABLE `tb_projectrtask` (
  `id_prortask` int(11) NOT NULL,
  `idtasktpe_prortask` int(11) NOT NULL,
  `idprj_prortask` int(11) NOT NULL,
  `nama_prortask` varchar(30) NOT NULL,
  `kdpgw_prortask` varchar(3) NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_projects`
--

CREATE TABLE `tb_projects` (
  `idprj_prj` int(11) NOT NULL,
  `idclt_prj` int(11) NOT NULL,
  `kdbrn_prj` char(3) NOT NULL,
  `peje_prj` varchar(3) NOT NULL,
  `marke_prj` char(3) NOT NULL,
  `name_prj` varchar(100) NOT NULL,
  `price_prj` double NOT NULL,
  `descr_prj` text NOT NULL,
  `pajak_prj` mediumint(9) NOT NULL,
  `stats_prj` char(1) NOT NULL DEFAULT 'W',
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_projectsdetail`
--

CREATE TABLE `tb_projectsdetail` (
  `idprd_prd` int(11) NOT NULL,
  `idprj_prd` int(11) NOT NULL,
  `idsrv_prd` mediumint(9) NOT NULL,
  `idsrd_prd` mediumint(9) NOT NULL COMMENT 'Paket Hosting, Araweb, dan Ekstensi Domain',
  `domin_prd` varchar(50) NOT NULL,
  `user_prd` varchar(50) NOT NULL,
  `pass_prd` varchar(50) NOT NULL,
  `date1_prd` date NOT NULL,
  `date9_prd` date NOT NULL,
  `keter_prd` text NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_projectsemployee`
--

CREATE TABLE `tb_projectsemployee` (
  `idprj_pje` int(11) NOT NULL,
  `kdpgw_pje` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_projecttask`
--

CREATE TABLE `tb_projecttask` (
  `id_protask` int(11) NOT NULL,
  `idtasktpe_protask` int(11) NOT NULL,
  `idprj_protask` int(11) NOT NULL,
  `nama_protask` varchar(30) NOT NULL,
  `deskripsi_protask` text NOT NULL,
  `tgldead_protask` datetime NOT NULL,
  `kdpgw_protask` varchar(3) NOT NULL,
  `status_protask` char(1) NOT NULL DEFAULT 'o',
  `done_protask` int(11) NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_prospect`
--

CREATE TABLE `tb_prospect` (
  `idprs_prs` int(11) NOT NULL,
  `idclt_prs` int(11) NOT NULL,
  `name_prs` varchar(100) NOT NULL,
  `scope_prs` text NOT NULL,
  `proposal_prs` text NOT NULL,
  `hargaawl_prs` double NOT NULL,
  `hargatwr_prs` double NOT NULL,
  `ketertwr_prs` text NOT NULL,
  `duedet_prs` date NOT NULL,
  `mrktg_prs` char(3) NOT NULL,
  `step1_prs` tinyint(1) NOT NULL,
  `step2_prs` tinyint(1) NOT NULL,
  `step3_prs` tinyint(1) NOT NULL,
  `step4_prs` tinyint(1) NOT NULL,
  `time1_prs` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `time2_prs` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time3_prs` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time4_prs` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status_prs` char(1) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_rekapabsensi`
--

CREATE TABLE `tb_rekapabsensi` (
  `id_rkp` int(11) NOT NULL,
  `kdpgw_rkp` varchar(4) NOT NULL,
  `age_rkp` double NOT NULL,
  `total_rkp` varchar(9) NOT NULL,
  `masuk_rkp` int(11) NOT NULL,
  `ijin_rkp` int(11) NOT NULL,
  `tgl_rkp` varchar(8) NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_routinetask`
--

CREATE TABLE `tb_routinetask` (
  `id_rtask` int(11) NOT NULL,
  `idprortask_rtask` int(11) NOT NULL,
  `idkpi_rtask` int(11) NOT NULL,
  `nama_rtask` varchar(50) NOT NULL,
  `ket_rtask` text NOT NULL,
  `day_rtask` char(1) NOT NULL,
  `week_rtask` char(1) NOT NULL,
  `delegate_rtask` varchar(5) NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_siswamagang`
--

CREATE TABLE `tb_siswamagang` (
  `id` int(11) NOT NULL,
  `idperiode` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `Keterangan` text NOT NULL,
  `nohp` varchar(12) NOT NULL,
  `status_magang` varchar(30) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_task`
--

CREATE TABLE `tb_task` (
  `id_task` int(11) NOT NULL,
  `ref_task` int(11) NOT NULL,
  `idprotask_task` int(11) NOT NULL,
  `idkpi_task` int(11) NOT NULL,
  `nama_task` varchar(200) NOT NULL,
  `deskripsi_tsk` text NOT NULL,
  `kendala_task` text NOT NULL,
  `link_task` varchar(255) NOT NULL,
  `tglplan_task` datetime NOT NULL,
  `tgldostart_task` datetime NOT NULL,
  `tgldoend_task` datetime NOT NULL,
  `ket_task` text NOT NULL,
  `delegate_task` varchar(5) NOT NULL,
  `writer_task` char(3) NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaction`
--

CREATE TABLE `tb_transaction` (
  `idtrx_trx` int(11) NOT NULL,
  `kdpos_trx` char(6) NOT NULL,
  `idrek_trx` mediumint(9) NOT NULL,
  `jenis_trx` char(2) NOT NULL,
  `refer_trx` int(11) NOT NULL,
  `notrx_trx` varchar(40) NOT NULL,
  `urain_trx` mediumtext NOT NULL,
  `nilai_trx` int(11) NOT NULL,
  `tnggl_trx` date NOT NULL,
  `usrpw_trx` varchar(20) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tr_clientgroup`
--

CREATE TABLE `tr_clientgroup` (
  `idgroup` int(11) NOT NULL,
  `idclient` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tr_clientgroup`
--

INSERT INTO `tr_clientgroup` (`idgroup`, `idclient`) VALUES
(4, 121),
(4, 122),
(4, 190),
(4, 209),
(4, 210),
(4, 196),
(4, 104),
(4, 103),
(4, 148),
(4, 149),
(4, 197),
(4, 229),
(4, 123),
(4, 124),
(4, 125),
(4, 126),
(4, 211),
(4, 212),
(4, 213),
(4, 214),
(4, 215),
(4, 216),
(4, 127),
(4, 128),
(4, 150),
(4, 151),
(4, 238),
(4, 106),
(4, 152),
(4, 217),
(4, 218),
(4, 219),
(4, 102),
(4, 115),
(4, 195),
(4, 186),
(4, 220),
(4, 221),
(4, 194),
(4, 205),
(4, 231),
(4, 223),
(4, 204),
(4, 239),
(4, 224),
(4, 225),
(4, 226),
(4, 114),
(4, 153),
(4, 154),
(4, 155),
(4, 156),
(4, 158),
(4, 157),
(4, 159),
(4, 160),
(4, 193),
(4, 129),
(4, 130),
(4, 109),
(4, 161),
(4, 162),
(4, 163),
(4, 131),
(4, 132),
(4, 133),
(4, 164),
(4, 111),
(4, 108),
(4, 110),
(4, 134),
(4, 135),
(4, 136),
(4, 137),
(4, 138),
(4, 139),
(4, 165),
(4, 166),
(4, 167),
(4, 168),
(4, 169),
(4, 199),
(4, 170),
(4, 171),
(4, 172),
(4, 173),
(4, 240),
(4, 107),
(4, 174),
(4, 175),
(4, 201),
(4, 192),
(4, 191),
(4, 112),
(4, 206),
(4, 202),
(4, 176),
(4, 177),
(4, 178),
(4, 179),
(4, 227),
(4, 189),
(4, 207),
(4, 203),
(4, 228),
(4, 200),
(4, 140),
(4, 141),
(4, 142),
(4, 101),
(4, 198),
(4, 241),
(4, 180),
(4, 181),
(4, 182),
(4, 183),
(4, 184),
(4, 185),
(4, 143),
(4, 144),
(4, 145),
(4, 146),
(4, 147),
(4, 105),
(4, 116),
(4, 117),
(4, 242),
(4, 243),
(4, 244),
(4, 245),
(4, 246),
(4, 247),
(4, 248),
(4, 249),
(4, 250),
(4, 251),
(4, 252),
(4, 253),
(4, 254),
(4, 255),
(4, 256),
(4, 233),
(4, 257),
(4, 258),
(4, 260),
(4, 259),
(4, 232),
(4, 261),
(4, 262),
(4, 263),
(4, 264),
(4, 265),
(4, 266),
(4, 267),
(4, 268),
(4, 269),
(4, 270),
(4, 271),
(4, 272),
(4, 273),
(4, 274),
(4, 275),
(4, 276),
(4, 277),
(4, 278),
(4, 279),
(4, 280),
(4, 281),
(4, 282),
(4, 283),
(4, 284),
(4, 285),
(4, 287),
(4, 286),
(4, 288),
(4, 289),
(4, 290),
(4, 291),
(4, 292),
(4, 293),
(4, 294),
(4, 295),
(4, 296),
(4, 299),
(4, 301),
(4, 303),
(4, 309),
(4, 312),
(4, 315),
(4, 318),
(4, 320),
(4, 322),
(4, 324),
(4, 326),
(4, 329),
(4, 328),
(4, 327),
(4, 325),
(4, 323),
(4, 113),
(4, 188),
(4, 319),
(4, 321),
(4, 317),
(4, 297),
(4, 187),
(4, 118),
(4, 119),
(4, 208),
(4, 120),
(5, 348),
(5, 353),
(5, 236),
(5, 82),
(5, 234),
(5, 87),
(5, 235),
(5, 95),
(5, 81),
(5, 305),
(5, 307),
(5, 92),
(5, 306),
(5, 308),
(5, 314),
(5, 316),
(5, 313),
(5, 91),
(5, 311),
(5, 310),
(5, 300),
(5, 97),
(5, 80),
(5, 85),
(5, 79),
(5, 84),
(5, 90),
(5, 237),
(5, 88),
(5, 89),
(5, 83),
(5, 86),
(5, 372),
(3, 298),
(3, 302),
(3, 94),
(3, 99),
(3, 100),
(3, 6),
(3, 381),
(1, 366),
(1, 58),
(1, 25),
(1, 421),
(1, 51),
(1, 356),
(1, 59),
(1, 53),
(1, 373),
(1, 341),
(1, 386),
(1, 63),
(1, 395),
(1, 412),
(1, 12),
(1, 73),
(1, 74),
(1, 385),
(1, 330),
(1, 402),
(1, 398),
(1, 69),
(1, 362),
(1, 343),
(1, 423),
(1, 422),
(1, 11),
(1, 378),
(1, 380),
(1, 44),
(1, 335),
(1, 340),
(1, 397),
(1, 68),
(1, 38),
(1, 76),
(1, 384),
(1, 66),
(1, 400),
(1, 56),
(1, 72),
(1, 70),
(1, 370),
(1, 67),
(1, 55),
(1, 57),
(1, 382),
(1, 62),
(1, 71),
(1, 64),
(1, 347),
(1, 65),
(1, 424),
(1, 375),
(1, 420),
(1, 415),
(1, 369),
(1, 404),
(1, 394),
(1, 54),
(1, 403),
(1, 417),
(1, 45),
(1, 355),
(1, 364),
(1, 61),
(1, 399),
(1, 52),
(1, 75),
(1, 391),
(1, 346),
(1, 367),
(1, 387),
(1, 388),
(1, 379),
(1, 389),
(1, 7),
(1, 363),
(1, 419),
(1, 406),
(1, 416),
(1, 414),
(1, 411),
(1, 410),
(1, 409),
(1, 408),
(1, 407),
(1, 413),
(1, 405),
(1, 390),
(1, 425),
(1, 392),
(1, 336),
(1, 377),
(1, 376),
(1, 393),
(1, 360),
(1, 401),
(1, 42),
(1, 47),
(1, 96),
(1, 344),
(1, 345),
(1, 349),
(1, 358),
(1, 359),
(1, 365),
(1, 4),
(1, 77),
(1, 60),
(1, 418),
(1, 40),
(1, 339),
(1, 371),
(1, 32),
(1, 357),
(1, 338),
(1, 383),
(1, 374),
(1, 396),
(6, 421);

-- --------------------------------------------------------

--
-- Table structure for table `tr_notify`
--

CREATE TABLE `tr_notify` (
  `idntf_ntf` int(11) NOT NULL,
  `tbref_ntf` varchar(30) NOT NULL,
  `idref_ntf` int(11) NOT NULL,
  `pgfrom_ntf` char(3) NOT NULL,
  `pgto_ntf` char(3) NOT NULL,
  `notif_ntf` text NOT NULL,
  `issee_ntf` tinyint(1) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_wa` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `panggilan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kantor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kota` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provinsi` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ms_administrasi`
--
ALTER TABLE `ms_administrasi`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `ms_asettype`
--
ALTER TABLE `ms_asettype`
  ADD PRIMARY KEY (`id_astpe`);

--
-- Indexes for table `ms_branch`
--
ALTER TABLE `ms_branch`
  ADD PRIMARY KEY (`kdbrn_brn`);

--
-- Indexes for table `ms_client`
--
ALTER TABLE `ms_client`
  ADD PRIMARY KEY (`idclt_clt`);

--
-- Indexes for table `ms_employee`
--
ALTER TABLE `ms_employee`
  ADD PRIMARY KEY (`kdpgw_pgw`);

--
-- Indexes for table `ms_kpi`
--
ALTER TABLE `ms_kpi`
  ADD PRIMARY KEY (`id_kpi`);

--
-- Indexes for table `ms_pos`
--
ALTER TABLE `ms_pos`
  ADD PRIMARY KEY (`kdpos_pos`);

--
-- Indexes for table `ms_rekening`
--
ALTER TABLE `ms_rekening`
  ADD PRIMARY KEY (`idrek_rek`);

--
-- Indexes for table `ms_services`
--
ALTER TABLE `ms_services`
  ADD PRIMARY KEY (`idsrv_srv`) USING BTREE;

--
-- Indexes for table `ms_servicesdetail`
--
ALTER TABLE `ms_servicesdetail`
  ADD PRIMARY KEY (`idsrd_srd`);

--
-- Indexes for table `ms_supplier`
--
ALTER TABLE `ms_supplier`
  ADD PRIMARY KEY (`idsup_sup`);

--
-- Indexes for table `ms_tasktype`
--
ALTER TABLE `ms_tasktype`
  ADD PRIMARY KEY (`id_tasktpe`);

--
-- Indexes for table `ms_user`
--
ALTER TABLE `ms_user`
  ADD UNIQUE KEY `username_usr` (`usrpw_usr`);

--
-- Indexes for table `tb_advice`
--
ALTER TABLE `tb_advice`
  ADD PRIMARY KEY (`id_adv`);

--
-- Indexes for table `tb_aset`
--
ALTER TABLE `tb_aset`
  ADD PRIMARY KEY (`id_ast`);

--
-- Indexes for table `tb_bon`
--
ALTER TABLE `tb_bon`
  ADD PRIMARY KEY (`idbon_bon`);

--
-- Indexes for table `tb_cekmasuk`
--
ALTER TABLE `tb_cekmasuk`
  ADD PRIMARY KEY (`id_cek`);

--
-- Indexes for table `tb_clientgroup`
--
ALTER TABLE `tb_clientgroup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_invoice`
--
ALTER TABLE `tb_invoice`
  ADD PRIMARY KEY (`idinv_inv`);

--
-- Indexes for table `tb_invoicedetail`
--
ALTER TABLE `tb_invoicedetail`
  ADD PRIMARY KEY (`iddtl`);

--
-- Indexes for table `tb_logs`
--
ALTER TABLE `tb_logs`
  ADD PRIMARY KEY (`id_logs`);

--
-- Indexes for table `tb_magang`
--
ALTER TABLE `tb_magang`
  ADD PRIMARY KEY (`id_mgg`);

--
-- Indexes for table `tb_projectrtask`
--
ALTER TABLE `tb_projectrtask`
  ADD PRIMARY KEY (`id_prortask`);

--
-- Indexes for table `tb_projects`
--
ALTER TABLE `tb_projects`
  ADD PRIMARY KEY (`idprj_prj`);

--
-- Indexes for table `tb_projectsdetail`
--
ALTER TABLE `tb_projectsdetail`
  ADD PRIMARY KEY (`idprd_prd`);

--
-- Indexes for table `tb_projecttask`
--
ALTER TABLE `tb_projecttask`
  ADD PRIMARY KEY (`id_protask`);

--
-- Indexes for table `tb_prospect`
--
ALTER TABLE `tb_prospect`
  ADD PRIMARY KEY (`idprs_prs`);

--
-- Indexes for table `tb_rekapabsensi`
--
ALTER TABLE `tb_rekapabsensi`
  ADD PRIMARY KEY (`id_rkp`);

--
-- Indexes for table `tb_routinetask`
--
ALTER TABLE `tb_routinetask`
  ADD PRIMARY KEY (`id_rtask`);

--
-- Indexes for table `tb_siswamagang`
--
ALTER TABLE `tb_siswamagang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_task`
--
ALTER TABLE `tb_task`
  ADD PRIMARY KEY (`id_task`);

--
-- Indexes for table `tr_notify`
--
ALTER TABLE `tr_notify`
  ADD PRIMARY KEY (`idntf_ntf`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ms_administrasi`
--
ALTER TABLE `ms_administrasi`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ms_asettype`
--
ALTER TABLE `ms_asettype`
  MODIFY `id_astpe` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ms_client`
--
ALTER TABLE `ms_client`
  MODIFY `idclt_clt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=516;

--
-- AUTO_INCREMENT for table `ms_kpi`
--
ALTER TABLE `ms_kpi`
  MODIFY `id_kpi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `ms_rekening`
--
ALTER TABLE `ms_rekening`
  MODIFY `idrek_rek` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ms_services`
--
ALTER TABLE `ms_services`
  MODIFY `idsrv_srv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `ms_servicesdetail`
--
ALTER TABLE `ms_servicesdetail`
  MODIFY `idsrd_srd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `ms_supplier`
--
ALTER TABLE `ms_supplier`
  MODIFY `idsup_sup` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ms_tasktype`
--
ALTER TABLE `ms_tasktype`
  MODIFY `id_tasktpe` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tb_advice`
--
ALTER TABLE `tb_advice`
  MODIFY `id_adv` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_aset`
--
ALTER TABLE `tb_aset`
  MODIFY `id_ast` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_bon`
--
ALTER TABLE `tb_bon`
  MODIFY `idbon_bon` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_cekmasuk`
--
ALTER TABLE `tb_cekmasuk`
  MODIFY `id_cek` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_clientgroup`
--
ALTER TABLE `tb_clientgroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_invoice`
--
ALTER TABLE `tb_invoice`
  MODIFY `idinv_inv` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_invoicedetail`
--
ALTER TABLE `tb_invoicedetail`
  MODIFY `iddtl` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_logs`
--
ALTER TABLE `tb_logs`
  MODIFY `id_logs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_magang`
--
ALTER TABLE `tb_magang`
  MODIFY `id_mgg` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_projectrtask`
--
ALTER TABLE `tb_projectrtask`
  MODIFY `id_prortask` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_projects`
--
ALTER TABLE `tb_projects`
  MODIFY `idprj_prj` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_projectsdetail`
--
ALTER TABLE `tb_projectsdetail`
  MODIFY `idprd_prd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_projecttask`
--
ALTER TABLE `tb_projecttask`
  MODIFY `id_protask` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_prospect`
--
ALTER TABLE `tb_prospect`
  MODIFY `idprs_prs` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_rekapabsensi`
--
ALTER TABLE `tb_rekapabsensi`
  MODIFY `id_rkp` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_routinetask`
--
ALTER TABLE `tb_routinetask`
  MODIFY `id_rtask` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_siswamagang`
--
ALTER TABLE `tb_siswamagang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_task`
--
ALTER TABLE `tb_task`
  MODIFY `id_task` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tr_notify`
--
ALTER TABLE `tr_notify`
  MODIFY `idntf_ntf` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
