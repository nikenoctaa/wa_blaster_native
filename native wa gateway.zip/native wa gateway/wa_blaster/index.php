<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <table width=100% border=0>
    <tr height=80>
    <td><img src=logo.png></td>
    <td><iframe name=sinkron scrolling=no frameborder=0 width=100% height=50 src=autosinkron2.php></iframe></td>
    </tr>
    </table>

    <table align="center" width=95% border=0>
    <tr>
        <td width=150 valign=top>
        <a class="p-3 btn btn-info" onclick="window.open('upload.php','frm')" role="button">Upload Excel</a>
        <br><br>
        <a class="p-3 btn btn-info" onclick="window.open('list.php','frm')" role="button">List Nomor</a>
        <br><br>
        <a class="p-3 btn btn-info" onclick="window.open('view_grub.php','frm')" role="button">View Grub</a>
        <br><br>
        <a class="p-3 btn btn-info" onclick="window.open('belum_dikirim.php','frm')" role="button">Belum Dikirim</a>
        <br><br>
        <a class="p-3 btn btn-info" onclick="window.open('antri_dikirim.php','frm')" role="button">Menunggu Antrian</a>
        <br><br>
        <a class="p-3 btn btn-info" onclick="window.open('sudah_dikirim.php','frm')" role="button">Sudah Terkirim</a>
        </td>
        <td>
        <iframe width=100% height=2000 src='sudah_dikirim.php' frameborder=0 name=frm></iframe>
        </td>
    </tr>
    </table> 
</body>
</html>