

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>

<?php
error_reporting(~E_NOTICE);
require_once "koneksi.php";
include('lib/paginator.class.2.php');
$pages = new Paginator;


$sql1 = "
	select * from data_wa_blaster order by id_msg desc
";
$result1 = mysqli_query($conn,$sql1);

$sql2 = "
	select count(*) JML from ($sql1) x
";
$result2 = mysqli_query($conn,$sql2);
$data2 = mysqli_fetch_array($result2,MYSQL_ASSOC);


$pages->items_total = $data2['JML'];
$pages->mid_range = 9; // Number of pages to display. Must be odd and > 3
$pages->paginate();

$batasan = str_replace("and",",", $pages->limit );

$sql = "
	$sql1 LIMIT $batasan
";
$result = mysqli_query($conn,$sql);

echo "<h2>List Data Nomor</h2>";
echo "<h5>Jika ingin mengirim pesan ke nomer dengan status SENT, maka bisa hapus SENT terlebih dahulu dengan menu edit</h5>";
echo "<table width=100% border=2 cellspacing=0 collpadding=2>";
echo "<tr align=center bgcolor=#CCCCCC>";
echo "<td>NO WA</td><td>STATUS</td><td>NAMA_KONTAK</td><td>NAMA_PERUSAHAAN</td><td>PANGGILAN (Bapak/Ibu/Kakak)</td><td>EMAIL</td><td>ALAMAT</td><td>KOTA</td><td>PROVINSI</td><td>DESKRIPSI_1</td><td>DESKRIPSI_2</td><td>NOTE</td><td>GRUB</td>";
echo "</tr>";
while ($data = mysqli_fetch_array($result,MYSQL_ASSOC)){
	$id_msg = $data['ID_MSG'];
    $no_wa = $data[NO_WA];
    $status = $data[STATUS];
	$format_wa = $data[FORMAT_WA];
	$nama_kontak = $data[NAMA_KONTAK];
	$nama_perusahaan = $data[NAMA_PERUSAHAAN];
	$panggilan = $data[PANGGILAN];
	$email = $data[EMAIL];
	$alamat = $data[ALAMAT];
	$kota = $data[KOTA];
	$provinsi = $data[PROVINSI];
	$deskripsi_1 = $data[DESKRIPSI_1];
	$deskripsi_2 = $data[DESKRIPSI_2];
	$note = $data[note];
	$id_grub = '';
	$result_alokasi = mysqli_query($conn,"SELECT * FROM alokasi_grub INNER JOIN grub_wa_blaster USING (ID_GRUB)");
	while ($data_alokasi = mysqli_fetch_array($result_alokasi,MYSQL_ASSOC)){
		if($id_msg==$data_alokasi[ID_MSG] && $id_grub == ''){
			$id_grub = $data_alokasi[NAMA_GRUB];
		}else if($id_msg==$data_alokasi[ID_MSG]){
			$id_grub = $id_grub.','.$data_alokasi[NAMA_GRUB];
		}
	}
	
	echo "<tr>";
	echo "<td><a href=hapus.php?ID_MSG=$id_msg onClick=\"return confirm('Yakin Akan Menghapus?')\">[x]</a> $no_wa</td><td>$status</td><td>$nama_kontak</td><td>$nama_perusahaan</td><td>$panggilan</td><td>$email</td><td>$alamat</td><td>$kota</td><td>$provinsi</td><td>$deskripsi_1</td><td>$deskripsi_2</td><td>$note</td><td>$id_grub</td>";
    echo "</tr>";
    echo "<td><a href='edit.php?id_msg=$data[ID_MSG]'>Edit</a> | <a href='delete.php?id_msg=$data[ID_MSG]'>Delete</a></td></tr>";
}
echo "</table><br>";


mysqli_free_result($result);
mysqli_free_result($result1);
mysqli_free_result($result2);
mysqli_close($conn);
?>
    <a class="btn btn-info" href="create.php" role="button">Create</a>
	
	<!--<h3>GROUP CONTACT</h3>
	<a class="btn btn-info" href="create_grub.php" role="button">Create Grub</a>-->
	<!--<a class="btn btn-warning" href="klient.php" role="button">Contact Client</a>
	<a class="btn btn-warning" href="prospek.php" role="button">Contact Prospect</a>
	<a class="btn btn-warning" href="sekolah.php" role="button">Contant Sekolah</a>-->
</body>
</html>