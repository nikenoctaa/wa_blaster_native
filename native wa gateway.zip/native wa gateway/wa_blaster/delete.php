<?php
// include database connection file
error_reporting(~E_NOTICE);
require_once "koneksi.php";
include('lib/paginator.class.2.php');
$pages = new Paginator;

// Get id from URL to delete that user
$id_msg = $_GET['id_msg'];

// Delete user row from table based on given id
$result = mysqli_query($conn, "DELETE FROM data_wa_blaster WHERE ID_MSG='$id_msg'");

$result2 = mysqli_query($conn, "DELETE FROM alokasi_grub WHERE ID_MSG='$id_msg'");

// After delete redirect to Home, so that latest user list will be displayed.
header("Location:list.php");


?>