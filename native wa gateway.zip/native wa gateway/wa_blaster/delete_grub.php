<?php
// include database connection file
error_reporting(~E_NOTICE);
require_once "koneksi.php";
include('lib/paginator.class.2.php');
$pages = new Paginator;

// Get id from URL to delete that user
$id_grub = $_GET['id_grub'];

// Delete user row from table based on given id
$result = mysqli_query($conn, "DELETE FROM grub_wa_blaster WHERE ID_GRUB='$id_grub'");

// After delete redirect to Home, so that latest user list will be displayed.
header("Location:view_grub.php");
?>