<?php
// include database connection file
error_reporting(~E_NOTICE);
include "koneksi.php";

// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{   
    $id = $_POST['id_grub'];
    $nama_grub = $_POST['NAMA_GRUB'];

    // update user data
    $result = mysqli_query($conn, "UPDATE grub_wa_blaster SET NAMA_GRUB='$nama_grub' WHERE ID_GRUB='$id'");

    // Redirect to homepage to display updated user in list
    header("Location: view_grub.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
include "koneksi.php";
$id = $_GET['id_grub'];
// Fetch user data based on id
$result = mysqli_query($conn, "SELECT * FROM grub_wa_blaster WHERE ID_GRUB='$id'");
while($user_data = mysqli_fetch_array($result))
{
    $nama_grub = $user_data['NAMA_GRUB'];
}

?>
<html>
<head>  
    <title>Edit Grub</title>
</head>

<body>
    <a href="view_grub.php">Home</a>
    <br/><br/>

    <form name="update_user" method="post" action="">
        <table border="0">
            <tr> 
                <td>NAMA_GRUB</td>
                <td><input type="text" name="NAMA_GRUB" value=<?php echo $nama_grub;?>></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id_grub" value=<?php echo $_GET['id_grub'];?>></td>
                <td><input type="submit" name="update" value="Update"></td> 
            </tr>
        </table>
    </form>
</body>
</html>