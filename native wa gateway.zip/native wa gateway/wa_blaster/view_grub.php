

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>

<?php
error_reporting(~E_NOTICE);
require_once "koneksi.php";
include('lib/paginator.class.2.php');
$pages = new Paginator;


$sql1 = "
	select * from grub_wa_blaster order by id_grub desc
";
$result1 = mysqli_query($conn,$sql1);

$sql2 = "
	select count(*) JML from ($sql1) x
";
$result2 = mysqli_query($conn,$sql2);
$data2 = mysqli_fetch_array($result2,MYSQL_ASSOC);


$pages->items_total = $data2['JML'];
$pages->mid_range = 9; // Number of pages to display. Must be odd and > 3
$pages->paginate();

$batasan = str_replace("and",",", $pages->limit );

$sql = "
	$sql1 LIMIT $batasan
";
$result = mysqli_query($conn,$sql);


echo "<h2>List Grub</h2>";
echo "<table width=100% border=2 cellspacing=0 collpadding=2>";
echo "<tr align=center bgcolor=#CCCCCC>";
echo "<td>NAMA_GRUB</td>";
echo "</tr>";
while ($data = mysqli_fetch_array($result,MYSQL_ASSOC)){
	$id_grub = $data['ID_GRUB'];
	$nama_grub = $data[NAMA_GRUB];
	
	echo "<tr>";
	echo "<td>$nama_grub</td>";
    echo "</tr>";
    echo "<td><a href='detail_grub.php?id_grub=$data[ID_GRUB]'>Detail</a> | <a href='send_grub.php?id_grub=$data[ID_GRUB]'>Send Message</a> | <a href='edit_grub.php?id_grub=$data[ID_GRUB]'>Edit</a> | <a href='delete_grub.php?id_grub=$data[ID_GRUB]'>Delete</a> | <a href='add_grub.php?id_grub=$data[ID_GRUB]'>Add</a></td></tr>";
}
echo "</table><br>";


mysqli_free_result($result);
mysqli_free_result($result1);
mysqli_free_result($result2);
mysqli_close($conn);
?>

	<a class="btn btn-info" href="create_grub.php" role="button">Create Grub</a>
</body>
</html>