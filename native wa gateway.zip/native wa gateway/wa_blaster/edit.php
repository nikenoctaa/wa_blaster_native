<?php
// include database connection file
error_reporting(~E_NOTICE);
include "koneksi.php";

// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{   
    $id = $_POST['id_msg'];

    $no_wa = $_POST['NO_WA'];
    $status = $_POST['STATUS'];
    $nama_kontak = $_POST['NAMA_KONTAK'];
    $nama_perusahaan = $_POST['NAMA_PERUSAHAAN'];
    $panggilan = $_POST['PANGGILAN'];
    $email = $_POST['EMAIL'];
    $alamat = $_POST['ALAMAT'];
    $kota = $_POST['KOTA'];
    $provinsi = $_POST['PROVINSI'];
    $deskripsi_1 = $_POST['DESKRIPSI_1'];
    $deskripsi_2 = $_POST['DESKRIPSI_2'];
    $note = $_POST['NOTE'];
    $id_grub = $_POST['ID_GRUB'];
    // update user data
    $result = mysqli_query($conn, "UPDATE data_wa_blaster SET NO_WA='$no_wa', STATUS='$status',NAMA_KONTAK='$nama_kontak',NAMA_PERUSAHAAN='$nama_perusahaan',PANGGILAN='$panggilan',EMAIL='$email',ALAMAT='$alamat',KOTA='$kota',PROVINSI='$provinsi',DESKRIPSI_1='$deskripsi_1',DESKRIPSI_2='$deskripsi_2',NOTE='$note',ID_GRUB='$id_grub' WHERE id_msg='$id'");

    // Redirect to homepage to display updated user in list
    header("Location: list.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
include "koneksi.php";
$id = $_GET['id_msg'];
// Fetch user data based on id
$result = mysqli_query($conn, "SELECT * FROM data_wa_blaster WHERE ID_MSG='$id'");
while($user_data = mysqli_fetch_array($result))
{
    $no_wa = $user_data['NO_WA'];
    $status = $user_data['STATUS'];
    $nama_kontak = $user_data['NAMA_KONTAK'];
    $nama_perusahaan = $user_data['NAMA_PERUSAHAAN'];
    $panggilan = $user_data['PANGGILAN'];
    $email = $user_data['EMAIL'];
    $alamat = $user_data['ALAMAT'];
    $kota = $user_data['KOTA'];
    $provinsi = $user_data['PROVINSI'];
    $deskripsi_1 = $user_data['DESKRIPSI_1'];
    $deskripsi_2 = $user_data['DESKRIPSI_2'];
    $note = $user_data['NOTE'];
    $id_grub = $user_data['ID_GRUB'];
}

?>
<html>
<head>  
    <title>Edit User Data</title>
</head>

<body>
    <a href="list.php">Home</a>
    <br/><br/>

    <form name="update_user" method="post" action="">
        <table border="0">
            <tr> 
                <td>NO_WA</td>
                <td><input type="text" name="NO_WA" value="<?php echo $no_wa;?>"></td>
            </tr>
            <tr> 
                <td>STATUS</td>
                <td><input type="text" name="STATUS" value="<?php echo $status;?>"></td>
            </tr>
            <tr> 
                <td>NAMA_KONTAK</td>
                <td><input type="text" name="NAMA_KONTAK" value="<?php echo $nama_kontak;?>"></td>
            </tr>
            <tr> 
                <td>NAMA_PERUSAHAAN</td>
                <td><input type="text" name="NAMA_PERUSAHAAN" value="<?php echo $nama_perusahaan;?>"></td>
            </tr>
            <tr> 
                <td>PANGGILAN (Bapak/Ibu/Kakak)</td>
                <td><input type="text" name="PANGGILAN" value="<?php echo $panggilan;?>"></td>
            </tr>
            <tr> 
                <td>EMAIL</td>
                <td><input type="text" name="EMAIL" value="<?php echo $email;?>"></td>
            </tr>
            <tr> 
                <td>ALAMAT</td>
                <td><input type="text" name="ALAMAT" value="<?php echo $alamat;?>"></td>
            </tr>
            <tr> 
                <td>KOTA</td>
                <td><input type="text" name="KOTA" value="<?php echo $kota;?>"></td>
            </tr>
            <tr> 
                <td>PROVINSI</td>
                <td><input type="text" name="PROVINSI" value="<?php echo $provinsi;?>"></td>
            </tr>
            <tr> 
                <td>DESKRIPSI_1</td>
                <td><input type="text" name="DESKRIPSI_1" value="<?php echo $deskripsi_1;?>"></td>
            </tr>
            <tr> 
                <td>DESKRIPSI_2</td>
                <td><input type="text" name="DESKRIPSI_2" value="<?php echo $deskripsi_2;?>"></td>
            </tr>
            <tr> 
                <td>NOTE</td>
                <td><input type="text" name="NOTE" value="<?php echo $note;?>"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id_msg" value=<?php echo $_GET['id_msg'];?>></td>
                <td><input type="submit" name="update" value="Update"></td> 
            </tr>
        </table>
    </form>
</body>
</html>