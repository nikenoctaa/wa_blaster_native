

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>

<?php
error_reporting(~E_NOTICE);
require_once "koneksi.php";
include('lib/paginator.class.2.php');
$pages = new Paginator;

$sql1 = "SELECT DISTINCT ID_MSG FROM alokasi_grub WHERE NOT EXISTS(SELECT * FROM alokasi_grub AS coba WHERE coba.ID_MSG = alokasi_grub.ID_MSG AND coba.ID_GRUB = '" . $_GET['id_grub'] . "')";
$result1 = mysqli_query($conn,$sql1);
echo "<h2>List Data Nomor Belum Masuk Grub</h2>";
echo "<form action='' method='post' name='form1'>";
echo "<table width=100% border=2 cellspacing=0 collpadding=2>";
echo "<tr align=center bgcolor=#CCCCCC>";
echo "<td>NO WA</td><td>STATUS</td><td>NAMA_KONTAK</td><td>NAMA_PERUSAHAAN</td><td>PANGGILAN (Bapak/Ibu/Kakak)</td><td>EMAIL</td><td>ALAMAT</td><td>KOTA</td><td>PROVINSI</td><td>DESKRIPSI_1</td><td>DESKRIPSI_2</td><td>NOTE</td><td>GRUB</td>";
echo "</tr>";
if ($result1->num_rows > 0) {
    while($row = $result1->fetch_assoc()) {
        $id = $row["ID_MSG"];
        $sql2 = "SELECT * FROM data_wa_blaster WHERE ID_MSG='$id'";
        $result2 = mysqli_query($conn,$sql2);
        if($result2->num_rows > 0){
            while($row2 = $result2->fetch_assoc()){
                echo "<tr>";
                echo "<td><a href=hapus.php?ID_MSG=$id onClick=\"return confirm('Yakin Akan Menghapus?')\">[x]</a> " . $row2['NO_WA'] . "</td><td>" . $row2['STATUS'] . "</td><td>" . $row2['NAMA_KONTAK'] . "</td><td>" . $row2['NAMA_PERUSAHAAN'] . "</td><td>" . $row2['PANGGILAN'] . "</td><td>" . $row2['EMAIL'] . "</td><td>" . $row2['ALAMAT'] . "</td><td>" . $row2['KOTA'] . "</td><td>" . $row2['PROVINSI'] . "</td><td>" . $row2['DESKRIPSI_1'] . "</td><td>" . $row2['DESKRIPSI_2'] . "</td><td>" . $row2['NOTE'] . "</td><td>" . $row2['ID_GRUB'] . "</td>";
                echo "</tr>";
                echo "<td><input type='checkbox' name='ID_MSG[]' value='$id'></td></tr>";
            } 
        }else{
            echo "gagal";
        }
        // echo $id . '<br>';
    }
} else {
    echo "0 results";
}
	


echo "</table><br>";
echo "<button class='btn btn-info' type='submit' name='Submit' value='Add'>Add</button>";
echo "</form>";
if(isset($_POST['Submit'])) {
    if(!empty($_POST['ID_MSG'])){
        foreach($_POST['ID_MSG'] as $selected){
            
            $sql = mysqli_query($conn, "INSERT INTO alokasi_grub(id_msg,id_grub) VALUES('$selected','$_GET[id_grub]')");
            $sql1 = mysqli_query($conn, "UPDATE data_wa_blaster SET STAT = '1' WHERE STAT = '0'");

        }
    }
    // if($_GET['ID_GRUB'] != 0){
    //     foreach ($_POST['ID_GRUB'] as $value){
    //         $sqli = mysqli_query($conn,"UPDATE data_wa_blaster set STAT ='1' where ID_GRUB = '$value'"); 
    //      }
    // }
}

?>
    <!-- <a class="btn btn-info" href="create.php" role="button">Create</a> -->
	
	<!--<h3>GROUP CONTACT</h3>
	<a class="btn btn-info" href="create_grub.php" role="button">Create Grub</a>-->
	<!--<a class="btn btn-warning" href="klient.php" role="button">Contact Client</a>
	<a class="btn btn-warning" href="prospek.php" role="button">Contact Prospect</a>
	<a class="btn btn-warning" href="sekolah.php" role="button">Contant Sekolah</a>-->
</body>
</html>