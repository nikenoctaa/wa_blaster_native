

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>

<?php
error_reporting(~E_NOTICE);
require_once "koneksi.php";
include('lib/paginator.class.2.php');
$pages = new Paginator;


$sql1 = "
	select * from data_wa_blaster order by id_msg desc
";
$result1 = mysqli_query($conn,$sql1);

$sql2 = "
	select count(*) JML from ($sql1) x
";
$result2 = mysqli_query($conn,$sql2);
$data2 = mysqli_fetch_array($result2,MYSQL_ASSOC);


$pages->items_total = $data2['JML'];
$pages->mid_range = 9; // Number of pages to display. Must be odd and > 3
$pages->paginate();

$batasan = str_replace("and",",", $pages->limit );

$sql = "
	$sql1 LIMIT $batasan
";
$result = mysqli_query($conn,$sql);

echo "<h2>Send Email</h2>";
echo "<table width=100% border=2 cellspacing=0 collpadding=2>";
echo "<tr align=center bgcolor=#CCCCCC>";
echo "<td>NO WA</td><td>STATUS</td><td>NAMA_KONTAK</td><td>NAMA_PERUSAHAAN</td><td>PANGGILAN (Bapak/Ibu/Kakak)</td><td>EMAIL</td><td>ALAMAT</td><td>KOTA</td><td>PROVINSI</td><td>DESKRIPSI_1</td><td>DESKRIPSI_2</td><td>NOTE</td>";
echo "</tr>";
while ($data = mysqli_fetch_array($result,MYSQL_ASSOC)){
	$id_msg = $data['ID_MSG'];
    $no_wa = $data[NO_WA];
    $status = $data[STATUS];
	$format_wa = $data[FORMAT_WA];
	$nama_kontak = $data[NAMA_KONTAK];
	$nama_perusahaan = $data[NAMA_PERUSAHAAN];
	$panggilan = $data[PANGGILAN];
	$email = $data[EMAIL];
	$alamat = $data[ALAMAT];
	$kota = $data[KOTA];
	$provinsi = $data[PROVINSI];
	$deskripsi_1 = $data[DESKRIPSI_1];
	$deskripsi_2 = $data[DESKRIPSI_2];
	$note = $data[note];
	
	echo "<tr>";
	echo "<td><a href=hapus.php?ID_MSG=$id_msg onClick=\"return confirm('Yakin Akan Menghapus?')\">[x]</a> $no_wa</td><td>$status</td><td>$nama_kontak</td><td>$nama_perusahaan</td><td>$panggilan</td><td>$email</td><td>$alamat</td><td>$kota</td><td>$provinsi</td><td>$deskripsi_1</td><td>$deskripsi_2</td><td>$note</td>";
    echo "</tr>";
    echo "<td><a href='edit.php?id_msg=$data[ID_MSG]'>Edit</a> | <a href='delete.php?id_msg=$data[ID_MSG]'>Delete</a></td></tr>";
}
echo "</table><br>";


mysqli_free_result($result);
mysqli_free_result($result1);
mysqli_free_result($result2);
mysqli_close($conn);

/*---------------------------------------------------------------------------------------------------------------------*/

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Include librari phpmailer
include('phpmailer/Exception.php');
include('phpmailer/PHPMailer.php');
include('phpmailer/SMTP.php');
$email_pengirim = 'nikenlarasatioctaviani@gmail.com'; // Isikan dengan email pengirim
$nama_pengirim = 'Niken L Octaviani'; // Isikan dengan nama pengirim
$email_penerima = $email; // Ambil email penerima dari inputan form
$subjek = $nama_kontak; // Ambil subjek dari inputan form
$pesan = $format_wa; // Ambil pesan dari inputan form
//$attachment = $_FILES['attachment']['name']; // Ambil nama file yang di upload
$mail = new PHPMailer;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Username = 'nikenlarasatioctaviani@gmail.com'; // Email Pengirim
$mail->Password = '14101998'; // Isikan dengan Password email pengirim
$mail->Port = 465;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'ssl';
// $mail->SMTPDebug = 2; // Aktifkan untuk melakukan debugging
$mail->setFrom('nikenlarasatioctaviani@gmail.com', 'Niken L Octaviani');
$mail->addAddress($email, '');
$mail->isHTML(true); // Aktifkan jika isi emailnya berupa html
// Load file content.php
ob_start();
include "content.php";
$content = ob_get_contents(); // Ambil isi file content.php dan masukan ke variabel $content
ob_end_clean();
//$mail->Subject = $subjek;
$mail->Body = $format_wa;
//$mail->AddEmbeddedImage('image/logo.png', 'logo_mynotescode', 'logo.png'); // Aktifkan jika ingin menampilkan gambar dalam email

echo "<h3>Status Email</h3>";
if(empty($attachment)){ // Jika tanpa attachment
    $send = $mail->send();
    if($send){ // Jika Email berhasil dikirim
        echo "<h5>Email berhasil dikirim</h5><br /><a href='list.php'>Kembali ke Form</a>";
    }else{ // Jika Email gagal dikirim
        echo "<h5>Email gagal dikirim</h5><br /><a href='list.php'>Kembali ke Form</a>";
        // echo '<h1>ERROR<br /><small>Error while sending email: '.$mail->getError().'</small></h1>'; // Aktifkan untuk mengetahui error message
    }
}/*else{ // Jika dengan attachment
    $tmp = $_FILES['attachment']['tmp_name'];
    $size = $_FILES['attachment']['size'];
    if($size <= 25000000){ // Jika ukuran file <= 25 MB (25.000.000 bytes)
        $mail->addAttachment($tmp, $attachment); // Add file yang akan di kirim
        $send = $mail->send();
        if($send){ // Jika Email berhasil dikirim
            echo "<h1>Email berhasil dikirim</h1><br /><a href='index.php'>Kembali ke Form</a>";
        }else{ // Jika Email gagal dikirim
            echo "<h1>Email gagal dikirim</h1><br /><a href='index.php'>Kembali ke Form</a>";
            // echo '<h1>ERROR<br /><small>Error while sending email: '.$mail->getError().'</small></h1>'; // Aktifkan untuk mengetahui error message
        }
    }else{ // Jika Ukuran file lebih dari 25 MB
        echo "<h1>Ukuran file attachment maksimal 25 MB</h1><br /><a href='index.php'>Kembali ke Form</a>";
    }
}*/

?>
</body>
</html>