<html>
<head>
    <title>Add Grub</title>
</head>

<body>
    <a href="view_grub.php">Go to Home</a>
    <br/><br/>

    <form action="" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td>NAMA_GRUB</td>
                <td><input type="text" name="NAMA_GRUB"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
        </table>
    </form>

    <?php

    // Check If form submitted, insert form data into users table.
    if(isset($_POST['Submit'])) {
        $nama_grub = $_POST['NAMA_GRUB'];

        // include database connection file
        include_once("koneksi.php");

        // Insert user data into table
        $result = mysqli_query($conn, "INSERT INTO grub_wa_blaster(NAMA_GRUB) VALUES ('$nama_grub')");
        echo "INSERT INTO grub_wa_blaster(NAMA_GRUB) VALUES ('$nama_grub')";

        // Show message when user added
        echo "User added successfully. <a href='view_grub.php'>View Grub</a>";
    }
    ?>
</body>
</html>
