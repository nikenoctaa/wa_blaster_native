<html>
<head>
    <title>Add Users</title>
</head>

<body>
    <a href="list.php">Go to Home</a>
    <br/><br/>

    <form action="" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td>NO_WA</td>
                <td><input type="text" name="NO_WA"></td>
            </tr>
            <tr> 
                <td>NAMA_KONTAK</td>
                <td><input type="text" name="NAMA_KONTAK"></td>
            </tr>
            <tr> 
                <td>NAMA_PERUSAHAAN</td>
                <td><input type="text" name="NAMA_PERUSAHAAN"></td>
            </tr>
            <tr> 
                <td>PANGGILAN</td>
                <td><input type="text" name="PANGGILAN"></td>
            </tr>
            <tr> 
                <td>EMAIL</td>
                <td><input type="text" name="EMAIL"></td>
            </tr>
            <tr> 
                <td>ALAMAT</td>
                <td><input type="text" name="ALAMAT"></td>
            </tr>
            <tr> 
                <td>KOTA</td>
                <td><input type="text" name="KOTA"></td>
            </tr>
            <tr>
                <td>PROVINSI</td>
                <td><input type="text" name="PROVINSI"></td>
            </tr>
            <tr> 
                <td>DESKRIPSI_1</td>
                <td><input type="text" name="DESKRIPSI_1"></td>
            </tr>
            <tr> 
                <td>DESKRIPSI_2</td>
                <td><input type="text" name="DESKRIPSI_2"></td>
            </tr>
            <tr> 
                <td>NOTE</td>
                <td><input type="text" name="NOTE"></td>
            </tr>
            <tr> 
                <td>GRUB</td>
                    <?php 
                        include 'koneksi.php';
                        $result = mysqli_query($conn, "SELECT * FROM grub_wa_blaster");
                        while($user_data = mysqli_fetch_array($result)){
                     ?>
                    <td>
                        <input type="checkbox" name="ID_GRUB[]" value="<?=$user_data['ID_GRUB']?>">
                        <?= $user_data['NAMA_GRUB'] ?>
                    </td>
                    <?php
                            }
                    ?>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
        </table>
    </form>

    <?php

    // Check If form submitted, insert form data into users table.
    if(isset($_POST['Submit'])) {
        $no_wa = $_POST['NO_WA'];
        $nama_kontak = $_POST['NAMA_KONTAK'];
        $nama_perusahaan = $_POST['NAMA_PERUSAHAAN'];
        $panggilan = $_POST['PANGGILAN'];
        $email = $_POST['EMAIL'];
        $alamat = $_POST['ALAMAT'];
        $kota = $_POST['KOTA'];
        $provinsi = $_POST['PROVINSI'];
        $deskripsi_1 = $_POST['DESKRIPSI_1'];
        $deskripsi_2 = $_POST['DESKRIPSI_2'];
        $note = $_POST['NOTE'];

        // $grub = implode (',', $_POST['ID_GRUB']);

        // $jumlah = count($_POST['ID_GRUB']); //menghitung jumlah value yang di centang
        // for($i=0; $i<$jumlah; $i++){
        //         echo $_POST['ID_GRUB'][$i]."-";
        // }
        

        // include database connection file
        // $jumlah = count($_POST['ID_GRUB']); //menghitung jumlah value yang di centang
        // for($i=0; $i<$jumlah; $i++){
        //         echo $_POST['ID_GRUB'][$i]."-";
        // }
        // //END CODE 1
        // echo "<hr>";
        // //CODE 2
        // $value = (count($_POST['ID_GRUB']) > 0) ? implode('-', $_POST['ID_GRUB']) : ""; 
        // echo "<br>$value";

        

        //$for_query="";
        // if(!empty($_POST['ID_GRUB'])){
            // foreach($_POST['ID_GRUB'] as $id){
            //     $for_query.=$id.",";
            // }
            // $for_query = substr($for_query,0,-2);
            $for_query="";
            if(empty($_POST['ID_GRUB'])){
                echo "Grub Belum Dipilih</br>";
            }
            else{
                $for_query = implode(",", $_POST['ID_GRUB']);               
            }
            
        // }
        
        include_once("koneksi.php");

        // Insert user data into table
        $result = "INSERT INTO data_wa_blaster(NO_WA,NAMA_KONTAK,NAMA_PERUSAHAAN,PANGGILAN,EMAIL,ALAMAT,KOTA,PROVINSI,DESKRIPSI_1,DESKRIPSI_2,NOTE,ID_GRUB) VALUES('$no_wa','$nama_kontak','$nama_perusahaan','$panggilan','$email','$alamat','$kota','$provinsi','$deskripsi_1','$deskripsi_2','$note','".$for_query."')";
        //echo "INSERT INTO data_wa_blaster(NO_WA,NAMA_KONTAK,NAMA_PERUSAHAAN,PANGGILAN,EMAIL,ALAMAT,KOTA,PROVINSI,DESKRIPSI_1,DESKRIPSI_2,NOTE) VALUES('$no_wa','$nama_kontak','$nama_perusahaan','$panggilan','$email','$alamat','$kota','$provinsi','$deskripsi_1','$deskripsi_2','$note')";

        if ($conn->query($result) === TRUE) {
            $last_id = $conn->insert_id;
        }

        if(!empty($_POST['ID_GRUB'])){
            foreach($_POST['ID_GRUB'] as $selected){
                $sql = mysqli_query($conn, "INSERT INTO alokasi_grub(id_msg,id_grub) VALUES('$last_id','$selected')");
            }
        }


        // Show message when user added
        echo "User added successfully. <a href='list.php'>View Users</a>";
    }
?>
</body>
</html>


