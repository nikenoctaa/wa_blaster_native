@extends('layouts.template')
@section('title','user_form')

@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
    <title>USER FORM</title>
</head>
<body>
    <div class="container">
        {{-- alert nampilin  checking error --}}
        @if ($errors->any())
        <div class="alert alert-primary" role="alert">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
        @endif
    <form action="{{url('register/user-form')}}" method="POST">
    {{csrf_field()}}
    <input type="hidden" name="_method" value="POST">
        <div class="form-group">
            <label for="exampleInputName">Nama</label>
            <input type="text" class="form-control" id="exampleInputName" name="nama">
        </div>
        <div class="form-row">
            <div class="col">
                <label for="exampleInputNo_Wa">Nomor WA</label>
                <input type="text" class="form-control" name="no_wa">
            </div>
            <div class="col">
                <label for="exampleInputEmail">E-Mail</label>
                <input type="text" class="form-control" name="email">
            </div>
        </div>
        <div class="form-group">
            <label for="exampleInputPanggilan">Panggilan</label>
            <input type="text" class="form-control" id="exampleInputPanggilan" placeholder="Bapak/Ibu/Kakak" name="panggilan">
        </div>
        <div class="form-group">
            <label for="exampleInputKantor">Asal Instansi / Kantor</label>
            <input type="text" class="form-control" id="exampleInputKantor" name="kantor">
        </div>
        <div class="form-group">
            <label for="exampleInputAlamat">Alamat Asal</label>
            <input type="text" class="form-control" id="exampleInputAlamat" name="alamat">
        </div>
        <div class="form-group">
            <label for="exampleInputKota">Kota</label>
            <input type="text" class="form-control" id="exampleInputKota" name="kota">
        </div>
        <div class="form-group">
            <label for="exampleInputProvinsi">Provinsi</label>
            <input type="text" class="form-control" id="exampleInputProvinsi" name="provinsi">
        </div>
    </form>
</body>
</html>
@endsection
