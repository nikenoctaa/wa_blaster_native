<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\UserForm;

class PublicController extends Controller
{
    public function createUserForm(Request $request){
        $request->validate([
            'nama' => 'required|min:5|max:255',
            'no_wa' => 'required|min:5|max:20',
            'email' => 'required|min:3|max:100',
            'panggilan' => 'required|min:3|max:20',
            'kantor' => 'required|min:3|max:255',
            'alamat' => 'required|min:3|max:255',
            'kota' => 'required|min:3|max:100',
            'provinsi' => 'required|min:3|max:100'
        ]);

        //session storing data
        $user_form = new UserForm;
        $user_form->nama = $request->nama;
        $user_form->no_wa = $request->no_wa;
        $user_form->email = $request->email;
        $user_form->panggilan = $request->panggilan;
        $user_form->kantor = $request->kantor;
        $user_form->alamat = $request->alamat;
        $user_form->kota = $request->kota;
        $user_form->provinsi = $request->provinsi;
        if($user_form->save()){
            return redirect(url('view-user-form'));
        }
    }

    public function showUserForm(){
        return view('user_form');
    }
}
