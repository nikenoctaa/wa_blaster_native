<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserForm extends Model
{
     /**
     * The primary key associated with the table.
     *
     * @var string
     */
    //protected $primaryKey = 'flight_id';->deklarasi primary key kalau misal idnya bukan id
    //public $incrementing = false; -> public $incrementing = false;
    //kalau misal ndak mau dipake (timestamps / apapun itu dibuat false <sama kaya auto increment)

}
