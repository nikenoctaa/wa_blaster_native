-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2020 at 07:11 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wa_blaster`
--

-- --------------------------------------------------------

--
-- Table structure for table `alokasi_grub`
--

CREATE TABLE `alokasi_grub` (
  `ID_ALOKASI` int(255) NOT NULL,
  `ID_MSG` bigint(255) NOT NULL,
  `ID_GRUB` int(255) NOT NULL,
  `STATUS` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alokasi_grub`
--

INSERT INTO `alokasi_grub` (`ID_ALOKASI`, `ID_MSG`, `ID_GRUB`, `STATUS`) VALUES
(92, 2147483752, 1, 0),
(93, 2147483752, 4, 0),
(94, 2147483752, 3, 0),
(96, 2147483760, 1, 0),
(97, 2147483760, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `data_wa`
--

CREATE TABLE `data_wa` (
  `ID_MSG` bigint(255) NOT NULL,
  `NO_WA` varchar(300) NOT NULL DEFAULT '',
  `FORMAT_WA` varchar(900) DEFAULT NULL,
  `ISI_WA` varchar(900) DEFAULT NULL,
  `TGL_INPUT` datetime DEFAULT NULL,
  `TGL_KIRIM` datetime DEFAULT NULL,
  `STATUS` varchar(100) DEFAULT NULL,
  `VAR_1` varchar(300) DEFAULT NULL,
  `VAR_2` varchar(300) DEFAULT NULL,
  `VAR_3` varchar(300) DEFAULT NULL,
  `VAR_4` varchar(300) DEFAULT NULL,
  `VAR_5` varchar(300) DEFAULT NULL,
  `VAR_6` varchar(300) DEFAULT NULL,
  `VAR_7` varchar(300) DEFAULT NULL,
  `VAR_8` varchar(300) DEFAULT NULL,
  `VAR_9` varchar(300) DEFAULT NULL,
  `VAR_10` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_wa`
--

INSERT INTO `data_wa` (`ID_MSG`, `NO_WA`, `FORMAT_WA`, `ISI_WA`, `TGL_INPUT`, `TGL_KIRIM`, `STATUS`, `VAR_1`, `VAR_2`, `VAR_3`, `VAR_4`, `VAR_5`, `VAR_6`, `VAR_7`, `VAR_8`, `VAR_9`, `VAR_10`) VALUES
(2147483696, '+6283842696390', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? ', 'Selamat Pagi HESTI, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari Kendal? ', '2020-01-30 13:18:41', '2020-01-31 11:37:02', '', 'HESTI', 'Kendal', '', '', '', '', 'Klient', '', '', ''),
(2147483697, '+6282313367724', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi DIKA, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari Semarang? Terima Kasih', '2020-01-30 13:18:41', '2020-01-31 09:40:07', 'SENT', 'DIKA', 'Semarang', '', '', '', '', '', '', '', ''),
(2147483699, '+6282111888445', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi DIMAS, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari Jepara? Terima Kasih', '2020-01-30 13:18:41', '2020-01-31 09:40:10', 'SENT', 'DIMAS', 'Jepara', '', '', '', '', '', '', '', ''),
(2147483702, '+6285747747725', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi AAN, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari SMT? Terima Kasih', NULL, '2020-01-31 09:40:12', 'SENT', 'AAN', 'SMT', '', '', '', '', '', '', '', ''),
(2147483703, '+62895322423176', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi SOFI, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari Texmaco? Terima Kasih', NULL, '2020-01-31 09:40:14', 'SENT', 'SOFI', 'Texmaco', '', '', '', '', '', '', '', ''),
(2147483704, '+6285339426574', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi ARIPIN, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari Udinus? Terima Kasih', NULL, '2020-01-31 09:40:15', 'SENT', 'ARIPIN', 'Udinus', '', '', '', '', '', '', '', ''),
(2147483705, '+6282120162498', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi IMAH, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari SMT? Terima Kasih', NULL, '2020-01-31 09:40:16', 'SENT', 'IMAH', 'SMT', '', '', '', '', '', '', '', ''),
(2147483706, '+6283867378782', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi DEA, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari SMK Kendal? Terima Kasih', NULL, '2020-01-31 09:40:19', 'SENT', 'DEA', 'SMK Kendal', '', '', '', '', '', '', '', ''),
(2147483707, '+6289507181647', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi ELA, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari SMK Kendal? Terima Kasih', NULL, '2020-01-31 09:40:20', 'SENT', 'ELA', 'SMK Kendal', '', '', '', '', '', '', '', ''),
(2147483708, '+6285600815378', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi AMIR, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari Texmaco? Terima Kasih', NULL, '2020-01-31 09:40:21', 'SENT', 'AMIR', 'Texmaco', '', '', '', '', '', '', '', ''),
(2147483709, '+6287700551716', 'Selamat Pagi [VAR_1], ini percobaan wa blaster dari SMT, apakah benar anda berasal dari [VAR_2]? Terima Kasih', 'Selamat Pagi ROBI, ini percobaan wa blaster dari SMT, apakah benar anda berasal dari SMT? Terima Kasih', NULL, '2020-01-31 09:40:23', 'SENT', 'ROBI', 'SMT', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `data_wa_blaster`
--

CREATE TABLE `data_wa_blaster` (
  `ID_MSG` bigint(255) NOT NULL,
  `NO_WA` varchar(300) NOT NULL DEFAULT '',
  `FORMAT_WA` varchar(900) DEFAULT NULL,
  `ISI_WA` varchar(900) DEFAULT NULL,
  `TGL_INPUT` datetime DEFAULT NULL,
  `TGL_KIRIM` datetime DEFAULT NULL,
  `STATUS` varchar(100) DEFAULT NULL,
  `NAMA_KONTAK` varchar(300) DEFAULT NULL,
  `NAMA_PERUSAHAAN` varchar(300) DEFAULT NULL,
  `PANGGILAN` varchar(300) DEFAULT NULL,
  `EMAIL` varchar(300) DEFAULT NULL,
  `ALAMAT` varchar(900) DEFAULT NULL,
  `KOTA` varchar(300) DEFAULT NULL,
  `PROVINSI` varchar(300) DEFAULT NULL,
  `DESKRIPSI_1` varchar(300) DEFAULT NULL,
  `DESKRIPSI_2` varchar(300) DEFAULT NULL,
  `NOTE` varchar(900) DEFAULT NULL,
  `ID_GRUB` varchar(100) NOT NULL,
  `STAT` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_wa_blaster`
--

INSERT INTO `data_wa_blaster` (`ID_MSG`, `NO_WA`, `FORMAT_WA`, `ISI_WA`, `TGL_INPUT`, `TGL_KIRIM`, `STATUS`, `NAMA_KONTAK`, `NAMA_PERUSAHAAN`, `PANGGILAN`, `EMAIL`, `ALAMAT`, `KOTA`, `PROVINSI`, `DESKRIPSI_1`, `DESKRIPSI_2`, `NOTE`, `ID_GRUB`, `STAT`) VALUES
(2147483752, '+6282111888445', 'Selamat Pagi [NAMA_KONTAK], test wa blaster ya', 'Selamat Pagi Dimas Arif Prasetya, test wa blaster ya', NULL, '2020-02-06 07:06:27', 'SENT', 'Dimas Arif Prasetya', 'Widya Informasi Indonesia', 'Bapak', 'd.masprasetya@gmail.com', 'Desa Kriyan, Kalinyamatan', 'Jepara', 'Jawa Tengah', '', '', '', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `grub_wa_blaster`
--

CREATE TABLE `grub_wa_blaster` (
  `ID_GRUB` int(225) NOT NULL,
  `NAMA_GRUB` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grub_wa_blaster`
--

INSERT INTO `grub_wa_blaster` (`ID_GRUB`, `NAMA_GRUB`) VALUES
(1, 'klient'),
(3, 'sekolah'),
(4, 'prospek');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alokasi_grub`
--
ALTER TABLE `alokasi_grub`
  ADD PRIMARY KEY (`ID_ALOKASI`);

--
-- Indexes for table `data_wa`
--
ALTER TABLE `data_wa`
  ADD PRIMARY KEY (`ID_MSG`);

--
-- Indexes for table `data_wa_blaster`
--
ALTER TABLE `data_wa_blaster`
  ADD PRIMARY KEY (`ID_MSG`);

--
-- Indexes for table `grub_wa_blaster`
--
ALTER TABLE `grub_wa_blaster`
  ADD PRIMARY KEY (`ID_GRUB`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alokasi_grub`
--
ALTER TABLE `alokasi_grub`
  MODIFY `ID_ALOKASI` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `data_wa`
--
ALTER TABLE `data_wa`
  MODIFY `ID_MSG` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483710;

--
-- AUTO_INCREMENT for table `data_wa_blaster`
--
ALTER TABLE `data_wa_blaster`
  MODIFY `ID_MSG` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483753;

--
-- AUTO_INCREMENT for table `grub_wa_blaster`
--
ALTER TABLE `grub_wa_blaster`
  MODIFY `ID_GRUB` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
